<b><span style="font-size: 24px;">Clustering Assignment</span></b>

<b>Problem Statement:</b>
Develop an unsupervised learning technique to cluster the dataset given into 'n' distinct clusters.

Also, to identify the most important features and their corresponding values that contribute significantly to the grouping of data points within these clusters.

The dataset shared is related breast cancer cases which contains targeted sequencing data of 1,980 primary breast cancer samples. 
The dataset consists of 1903 data points, each described by 693 features. These incluse numeric as well as non numeric features.

<b>Note:</b>Given the high number of features,the dataset at hand has <span style="color: red;">high dimensionality </span>.

<b><span style="font-size: 20px;"> Objective: </span></b>

1. <b>Clustering:</b> Implement an unsupervised learning algorithm to partition the data points into 'n' clusters. You should select an appropriate clustering algorithm based on the characteristics of the dataset and the problem requirements.
2. <b>Feature Importance:</b> Identify the most important features that influence the formation of clusters. Determine the relevance and significance of each feature in grouping data points together. 
3. <b>Feature Values:</b> Determine the specific values or ranges of values for the identified important features that are associated with each cluster. In other words, find the feature-value combinations that differentiate one cluster from another.

<span style="font-size: 16px;">Since we have understood the problem statement here, we follow the below steps to solve the problem </span>

<b><span style="font-size: 20px;">The Steps involved to solve this assignment are as follows:</span></b>

1. Importing all the required python libraries
2. Loading the dataset and filling missing values,encoding to make it suitable for further operations
3. Principal Component Analysis to reduce dimensionality
4. Performing different clustering algorithms and checking important features and feature values as applicable
5. Comparing different algorithm outcomes and conclusion

<b><span style="font-size:20px"> Importing Python Libraries</span></b>


```python
# Importing all important python libraries
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import sklearn as sklearn
from sklearn.decomposition import PCA
```

<b><span style="font-size:20px"> Loading Dataset </span></b>


```python
# Importing the dataset
breast_cancer=r'C:\Users\HP\Desktop\arogyaAI\METABRIC_RNA_Mutation.csv'  
```


```python
# I needed to convert below columns to string so that I could read the csv file loaded above
dtypes = {678: 'str', 688: 'str', 690: 'str', 692: 'str'}

df=pd.read_csv(breast_cancer,dtype=dtypes)

```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>patient_id</th>
      <th>age_at_diagnosis</th>
      <th>type_of_breast_surgery</th>
      <th>cancer_type</th>
      <th>cancer_type_detailed</th>
      <th>cellularity</th>
      <th>chemotherapy</th>
      <th>pam50_+_claudin-low_subtype</th>
      <th>cohort</th>
      <th>er_status_measured_by_ihc</th>
      <th>...</th>
      <th>mtap_mut</th>
      <th>ppp2cb_mut</th>
      <th>smarcd1_mut</th>
      <th>nras_mut</th>
      <th>ndfip1_mut</th>
      <th>hras_mut</th>
      <th>prps2_mut</th>
      <th>smarcb1_mut</th>
      <th>stmn2_mut</th>
      <th>siah1_mut</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>75.65</td>
      <td>MASTECTOMY</td>
      <td>Breast Cancer</td>
      <td>Breast Invasive Ductal Carcinoma</td>
      <td>NaN</td>
      <td>0</td>
      <td>claudin-low</td>
      <td>1</td>
      <td>Positve</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>43.19</td>
      <td>BREAST CONSERVING</td>
      <td>Breast Cancer</td>
      <td>Breast Invasive Ductal Carcinoma</td>
      <td>High</td>
      <td>0</td>
      <td>LumA</td>
      <td>1</td>
      <td>Positve</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5</td>
      <td>48.87</td>
      <td>MASTECTOMY</td>
      <td>Breast Cancer</td>
      <td>Breast Invasive Ductal Carcinoma</td>
      <td>High</td>
      <td>1</td>
      <td>LumB</td>
      <td>1</td>
      <td>Positve</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>6</td>
      <td>47.68</td>
      <td>MASTECTOMY</td>
      <td>Breast Cancer</td>
      <td>Breast Mixed Ductal and Lobular Carcinoma</td>
      <td>Moderate</td>
      <td>1</td>
      <td>LumB</td>
      <td>1</td>
      <td>Positve</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>8</td>
      <td>76.97</td>
      <td>MASTECTOMY</td>
      <td>Breast Cancer</td>
      <td>Breast Mixed Ductal and Lobular Carcinoma</td>
      <td>High</td>
      <td>1</td>
      <td>LumB</td>
      <td>1</td>
      <td>Positve</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 693 columns</p>
</div>




```python
pd.set_option('display.max_rows', None)
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1904 entries, 0 to 1903
    Columns: 693 entries, patient_id to siah1_mut
    dtypes: float64(496), int64(7), object(190)
    memory usage: 10.1+ MB
    

<b><span style="font-size:20px"> Dropping unnecessary features and Treating Missing Values </span></b>


```python
df=df.drop('patient_id',axis=1)
```

<span style="color:red">Since patient_id is not needed in our analysis, we will drop that columns.</span>

Given the <b>number of features are 693 and number of rows are 1903 </b>, the dataset at hand has <b>high dimensionality</b>.

To reduce this I will perform <span style="color:blue">Principal Component Analysis</span>. 
For the same,first I will need to <span style="color:blue">treat the null values and to convert all features into numeric values</span>. Then I will be <span style="color:blue">standardizing my dataset</span> and plot the cumulative explained variance and look for an <span style="color:blue"> "elbow point" </span> where adding more components does not significantly increase the explained variance.
Once this process is done, I will be creating PC's for further analysis.


```python
# Finding null values
pd.set_option('display.max_rows', None)
df.isnull().sum().sort_values(ascending=False)
```




    tumor_stage                       501
    3-gene_classifier_subtype         204
    primary_tumor_laterality          106
    neoplasm_histologic_grade          72
    cellularity                        54
    mutation_count                     45
    er_status_measured_by_ihc          30
    type_of_breast_surgery             22
    tumor_size                         20
    oncotree_code                      15
    cancer_type_detailed               15
    tumor_other_histologic_subtype     15
    death_from_cancer                   1
    akr1c4                              0
    akt3                                0
    ar                                  0
    bche                                0
    cdk8                                0
    akr1c3                              0
    cdkn2c                              0
    cyp11b2                             0
    cyb5a                               0
    cyp11a1                             0
    akr1c1                              0
    cyp17a1                             0
    cyp19a1                             0
    cyp21a2                             0
    cyp3a43                             0
    cyp3a5                              0
    cyp3a7                              0
    ddc                                 0
    hes6                                0
    akr1c2                              0
    age_at_diagnosis                    0
    ackr3                               0
    tbl1xr1                             0
    smarcc2                             0
    smarcd1                             0
    spaca1                              0
    stab2                               0
    stmn2                               0
    syne1                               0
    taf1                                0
    taf4b                               0
    tg                                  0
    zfp36l1                             0
    thada                               0
    thsd7a                              0
    ttyh1                               0
    ubr5                                0
    ush2a                               0
    hsd17b10                            0
    usp9x                               0
    utrn                                0
    hsd17b1                             0
    hsd17b4                             0
    hsd17b11                            0
    rdh5                                0
    serpini1                            0
    shbg                                0
    slc29a1                             0
    sox9                                0
    spry2                               0
    srd5a1                              0
    srd5a2                              0
    srd5a3                              0
    st7                                 0
    star                                0
    tnk2                                0
    tulp4                               0
    ugt2b15                             0
    ugt2b17                             0
    ugt2b7                              0
    pik3ca_mut                          0
    tp53_mut                            0
    sdc4                                0
    ran                                 0
    hsd17b12                            0
    prkd1                               0
    hsd17b13                            0
    hsd17b14                            0
    hsd17b2                             0
    hsd17b3                             0
    smarcb1                             0
    hsd17b6                             0
    hsd17b7                             0
    hsd17b8                             0
    hsd3b1                              0
    hsd3b2                              0
    hsd3b7                              0
    mecom                               0
    met                                 0
    ncoa2                               0
    nrip1                               0
    pik3r3                              0
    prkci                               0
    smarcc1                             0
    setdb1                              0
    sik2                                0
    kdm3a                               0
    frmd3                               0
    gh1                                 0
    gldc                                0
    gpr32                               0
    gps2                                0
    hdac9                               0
    herc2                               0
    hist1h2bc                           0
    kdm6a                               0
    sik1                                0
    klrg1                               0
    l1cam                               0
    lama2                               0
    lamb3                               0
    large1                              0
    ldlrap1                             0
    lifr                                0
    lipi                                0
    foxp1                               0
    flt3                                0
    fancd2                              0
    fanca                               0
    birc6                               0
    cacna2d3                            0
    ccnd3                               0
    chd1                                0
    clk3                                0
    clrn2                               0
    col12a1                             0
    col22a1                             0
    col6a3                              0
    ctcf                                0
    ctnna1                              0
    ctnna3                              0
    dnah11                              0
    dnah2                               0
    dnah5                               0
    dtwd2                               0
    fam20c                              0
    magea8                              0
    map3k10                             0
    map3k13                             0
    prkce                               0
    prkcz                               0
    prkg1                               0
    prps2                               0
    prr16                               0
    ptpn22                              0
    ptprm                               0
    rasgef1b                            0
    rpgr                                0
    ryr2                                0
    sbno1                               0
    setd1a                              0
    setd2                               0
    ahnak2_mut                          0
    sf3b1                               0
    sgcd                                0
    shank2                              0
    siah1                               0
    prkcq                               0
    prkacg                              0
    men1                                0
    ppp2r2a                             0
    mtap                                0
    muc16                               0
    myo1a                               0
    myo3a                               0
    ncoa3                               0
    nek1                                0
    nf2                                 0
    npnt                                0
    nr2f1                               0
    nr3c1                               0
    nras                                0
    nrg3                                0
    nt5e                                0
    or6a2                               0
    palld                               0
    pbrm1                               0
    ppp2cb                              0
    muc16_mut                           0
    dnah11_mut                          0
    kmt2c_mut                           0
    or6a2_mut                           0
    sik2_mut                            0
    ptpn22_mut                          0
    brip1_mut                           0
    flt3_mut                            0
    nrg3_mut                            0
    fbxw7_mut                           0
    ttyh1_mut                           0
    taf4b_mut                           0
    map3k13_mut                         0
    setdb1_mut                          0
    hdac9_mut                           0
    prkacg_mut                          0
    rpgr_mut                            0
    large1_mut                          0
    foxp1_mut                           0
    clk3_mut                            0
    prkcz_mut                           0
    lipi_mut                            0
    stk11_mut                           0
    men1_mut                            0
    gps2_mut                            0
    cdkn1b_mut                          0
    arid5b_mut                          0
    egfr_mut                            0
    map3k10_mut                         0
    smarcc2_mut                         0
    erbb4_mut                           0
    npnt_mut                            0
    nek1_mut                            0
    agmo_mut                            0
    zfp36l1_mut                         0
    smad4_mut                           0
    sik1_mut                            0
    casp8_mut                           0
    prkcq_mut                           0
    smarcc1_mut                         0
    palld_mut                           0
    dcaf4l2_mut                         0
    bcas3_mut                           0
    ppp2r2a_mut                         0
    prkce_mut                           0
    gh1_mut                             0
    tbl1xr1_mut                         0
    smad2_mut                           0
    sgcd_mut                            0
    spaca1_mut                          0
    rasgef1b_mut                        0
    hist1h2bc_mut                       0
    nr2f1_mut                           0
    klrg1_mut                           0
    mbl2_mut                            0
    mtap_mut                            0
    ppp2cb_mut                          0
    smarcd1_mut                         0
    nras_mut                            0
    ndfip1_mut                          0
    hras_mut                            0
    prps2_mut                           0
    smarcb1_mut                         0
    stmn2_mut                           0
    frmd3_mut                           0
    prkg1_mut                           0
    gpr32_mut                           0
    nr3c1_mut                           0
    kras_mut                            0
    nf2_mut                             0
    chek2_mut                           0
    ldlrap1_mut                         0
    clrn2_mut                           0
    acvrl1_mut                          0
    agtr2_mut                           0
    cdkn2a_mut                          0
    ctnna1_mut                          0
    magea8_mut                          0
    prr16_mut                           0
    dtwd2_mut                           0
    akt2_mut                            0
    braf_mut                            0
    foxo1_mut                           0
    nt5e_mut                            0
    ccnd3_mut                           0
    fam20c_mut                          0
    jak1_mut                            0
    syne1_mut                           0
    ncor1_mut                           0
    cbfb_mut                            0
    ncor2_mut                           0
    col12a1_mut                         0
    col22a1_mut                         0
    pten_mut                            0
    akt1_mut                            0
    atr_mut                             0
    thada_mut                           0
    stab2_mut                           0
    chd1_mut                            0
    myh9_mut                            0
    runx1_mut                           0
    nf1_mut                             0
    map2k4_mut                          0
    ros1_mut                            0
    lamb3_mut                           0
    arid1b_mut                          0
    erbb2_mut                           0
    notch1_mut                          0
    lama2_mut                           0
    arid1a_mut                          0
    col6a3_mut                          0
    gata3_mut                           0
    map3k1_mut                          0
    ahnak_mut                           0
    bap1                                0
    cdh1_mut                            0
    dnah2_mut                           0
    kmt2d_mut                           0
    ush2a_mut                           0
    ryr2_mut                            0
    dnah5_mut                           0
    herc2_mut                           0
    pde4dip_mut                         0
    akap9_mut                           0
    tg_mut                              0
    birc6_mut                           0
    utrn_mut                            0
    tbx3_mut                            0
    sf3b1_mut                           0
    shank2_mut                          0
    ep300_mut                           0
    taf1_mut                            0
    ctnna3_mut                          0
    brca1_mut                           0
    ptprm_mut                           0
    foxo3_mut                           0
    usp28_mut                           0
    gldc_mut                            0
    brca2_mut                           0
    cacna2d3_mut                        0
    arid2_mut                           0
    aff2_mut                            0
    lifr_mut                            0
    sbno1_mut                           0
    kdm3a_mut                           0
    ncoa3_mut                           0
    bap1_mut                            0
    l1cam_mut                           0
    pbrm1_mut                           0
    kdm6a_mut                           0
    fancd2_mut                          0
    ptprd_mut                           0
    asxl1_mut                           0
    usp9x_mut                           0
    setd2_mut                           0
    setd1a_mut                          0
    thsd7a_mut                          0
    afdn_mut                            0
    erbb3_mut                           0
    rb1_mut                             0
    myo1a_mut                           0
    alk_mut                             0
    fanca_mut                           0
    adgra2_mut                          0
    ubr5_mut                            0
    pik3r1_mut                          0
    myo3a_mut                           0
    asxl2_mut                           0
    apc_mut                             0
    ctcf_mut                            0
    bcas3                               0
    akap9                               0
    asxl2                               0
    rbpj                                0
    notch2                              0
    notch3                              0
    nrarp                               0
    numb                                0
    numbl                               0
    psen1                               0
    psen2                               0
    psenen                              0
    rbpjl                               0
    dll4                                0
    rfng                                0
    snw1                                0
    spen                                0
    hes2                                0
    hes4                                0
    hes7                                0
    hey1                                0
    hey2                                0
    notch1                              0
    ncstn                               0
    ncor2                               0
    maml3                               0
    dtx2                                0
    dtx3                                0
    dtx4                                0
    ep300                               0
    fbxw7                               0
    hdac1                               0
    hdac2                               0
    hes1                                0
    hes5                                0
    heyl                                0
    itch                                0
    jag1                                0
    jag2                                0
    kdm5a                               0
    lfng                                0
    maml1                               0
    maml2                               0
    acvr1                               0
    acvr1b                              0
    acvr1c                              0
    bmp7                                0
    bmpr1b                              0
    bmpr2                               0
    braf                                0
    casp10                              0
    casp3                               0
    casp6                               0
    casp7                               0
    casp8                               0
    casp9                               0
    chek1                               0
    csf1                                0
    csf1r                               0
    cxcl8                               0
    cxcr1                               0
    cxcr2                               0
    dab2                                0
    diras3                              0
    bmpr1a                              0
    bmp6                                0
    acvr2a                              0
    bmp5                                0
    acvr2b                              0
    acvrl1                              0
    akt1                                0
    akt1s1                              0
    akt2                                0
    apaf1                               0
    arl11                               0
    atr                                 0
    aurka                               0
    bad                                 0
    bcl2                                0
    bcl2l1                              0
    bmp10                               0
    bmp15                               0
    bmp2                                0
    bmp3                                0
    bmp4                                0
    dtx1                                0
    dll3                                0
    dph1                                0
    msh2                                0
    atm                                 0
    cdh1                                0
    chek2                               0
    nbn                                 0
    nf1                                 0
    stk11                               0
    bard1                               0
    mlh1                                0
    msh6                                0
    dll1                                0
    pms2                                0
    epcam                               0
    rad51c                              0
    rad51d                              0
    rad50                               0
    rb1                                 0
    rbl1                                0
    rbl2                                0
    tp53                                0
    pten                                0
    palb2                               0
    brca2                               0
    cancer_type                         0
    chemotherapy                        0
    pam50_+_claudin-low_subtype         0
    cohort                              0
    er_status                           0
    her2_status_measured_by_snp6        0
    her2_status                         0
    hormone_therapy                     0
    inferred_menopausal_state           0
    integrative_cluster                 0
    lymph_nodes_examined_positive       0
    nottingham_prognostic_index         0
    overall_survival_months             0
    overall_survival                    0
    pr_status                           0
    radio_therapy                       0
    brca1                               0
    ccna1                               0
    ccnb1                               0
    cdk1                                0
    src                                 0
    jak2                                0
    stat1                               0
    stat2                               0
    stat3                               0
    stat5a                              0
    stat5b                              0
    mdm2                                0
    tp53bp1                             0
    adam10                              0
    adam17                              0
    aph1a                               0
    aph1b                               0
    arrdc1                              0
    cir1                                0
    ctbp1                               0
    ctbp2                               0
    cul1                                0
    jak1                                0
    e2f8                                0
    ccne1                               0
    e2f7                                0
    cdk2                                0
    cdc25a                              0
    ccnd1                               0
    cdk4                                0
    cdk6                                0
    ccnd2                               0
    cdkn2a                              0
    cdkn2b                              0
    myc                                 0
    cdkn1a                              0
    cdkn1b                              0
    e2f1                                0
    e2f2                                0
    e2f3                                0
    e2f4                                0
    e2f5                                0
    e2f6                                0
    dlec1                               0
    egfr                                0
    asxl1                               0
    tgfbr2                              0
    smad9                               0
    sptbn1                              0
    terc                                0
    tert                                0
    tgfb1                               0
    tgfb2                               0
    tgfb3                               0
    tgfbr1                              0
    tgfbr3                              0
    pik3r2                              0
    tsc1                                0
    tsc2                                0
    vegfa                               0
    vegfb                               0
    wfdc2                               0
    wwox                                0
    zfyve9                              0
    arid1a                              0
    smad7                               0
    smad6                               0
    smad5                               0
    smad4                               0
    ptk2                                0
    rab25                               0
    rad51                               0
    raf1                                0
    rassf1                              0
    rheb                                0
    rictor                              0
    rps6                                0
    rps6ka1                             0
    rps6ka2                             0
    rps6kb1                             0
    rps6kb2                             0
    rptor                               0
    slc19a1                             0
    smad1                               0
    smad2                               0
    smad3                               0
    arid1b                              0
    cbfb                                0
    gata3                               0
    map4                                0
    nr1i2                               0
    slco1b3                             0
    tubb1                               0
    tubb4a                              0
    tubb4b                              0
    twist1                              0
    adgra2                              0
    afdn                                0
    aff2                                0
    agmo                                0
    agtr2                               0
    ahnak                               0
    ahnak2                              0
    alk                                 0
    apc                                 0
    arid2                               0
    arid5b                              0
    mapt                                0
    map2                                0
    kmt2c                               0
    fn1                                 0
    kmt2d                               0
    myh9                                0
    ncor1                               0
    pde4dip                             0
    ptprd                               0
    ros1                                0
    runx1                               0
    tbx3                                0
    abcb1                               0
    abcb11                              0
    abcc1                               0
    abcc10                              0
    bbc3                                0
    bmf                                 0
    cyp2c8                              0
    cyp3a4                              0
    fgf2                                0
    plagl1                              0
    pik3r1                              0
    eif4e                               0
    kras                                0
    inha                                0
    inhba                               0
    inhbc                               0
    itgav                               0
    itgb3                               0
    izumo1r                             0
    kdr                                 0
    kit                                 0
    map2k1                              0
    pik3ca                              0
    map2k2                              0
    map2k3                              0
    map2k4                              0
    map2k5                              0
    map3k1                              0
    map3k3                              0
    map3k4                              0
    map3k5                              0
    igf1r                               0
    igf1                                0
    hras                                0
    hla-g                               0
    eif4ebp1                            0
    eif5a2                              0
    erbb2                               0
    erbb3                               0
    erbb4                               0
    fas                                 0
    fgf1                                0
    fgfr1                               0
    folr1                               0
    folr2                               0
    folr3                               0
    foxo1                               0
    foxo3                               0
    gdf11                               0
    gdf2                                0
    gsk3b                               0
    hif1a                               0
    mapk1                               0
    mapk12                              0
    mapk14                              0
    mmp23b                              0
    mmp25                               0
    mmp26                               0
    mmp27                               0
    mmp28                               0
    mmp3                                0
    mmp7                                0
    mmp9                                0
    mtor                                0
    nfkb1                               0
    nfkb2                               0
    opcml                               0
    pdgfa                               0
    pdgfb                               0
    pdgfra                              0
    pdgfrb                              0
    pdpk1                               0
    peg3                                0
    mmp24                               0
    mmp21                               0
    mapk3                               0
    mmp2                                0
    mapk4                               0
    mapk6                               0
    mapk7                               0
    mapk8                               0
    mapk9                               0
    mdc1                                0
    mlst8                               0
    mmp1                                0
    mmp10                               0
    mmp11                               0
    mmp12                               0
    mmp13                               0
    mmp14                               0
    mmp15                               0
    mmp16                               0
    mmp17                               0
    mmp19                               0
    siah1_mut                           0
    dtype: int64





<span style=font-size:18px>We see in the above code that 13 features have null values among the 692 different variables.</span>

* tumor_stage                   -    501
* 3-gene_classifier_subtype     -    204
* primary_tumor_laterality      -    106

<span style="color:red">These features have respectively very high number of missing values (>5%), Tumor_stage being the variable with highest missing values (25% approx). We will create a separate category for the missing values in this case.<span style="color:red">


```python
# Creating functions to replace missing values

def fix_missing_fillna(df, col):
    ''' This function takes a data frame as input 
    replaces the missing values of a particular column with the value from the previous row
    '''
    df[col] = df[col].fillna('Missing') 
    
    
def fill_missing_mean(df,col):
    '''Filling the missing values with mean'''
    df[col]=df[col].fillna(df[col].mean())

    
def fill_missing_mode(df,col):
    '''Filling missing values with mode'''
    
    df[col]=df[col].fillna(df[col].mode().iloc[0])    

```


```python
# Filling the three features with very high number of missing values
fix_missing_fillna(df,'tumor_stage')
fix_missing_fillna(df,'3-gene_classifier_subtype')
fix_missing_fillna(df,'primary_tumor_laterality')
```


```python
#For other features with missing values,finding their dtype to decide on missing values accordingly 

col_names_missing_values=['neoplasm_histologic_grade','cellularity','mutation_count','er_status_measured_by_ihc',
           'type_of_breast_surgery','tumor_size','oncotree_code','cancer_type_detailed','tumor_other_histologic_subtype',
           'death_from_cancer']
           
col=df[col_names_missing_values].dtypes
           
print(col)           
```

    neoplasm_histologic_grade         float64
    cellularity                        object
    mutation_count                    float64
    er_status_measured_by_ihc          object
    type_of_breast_surgery             object
    tumor_size                        float64
    oncotree_code                      object
    cancer_type_detailed               object
    tumor_other_histologic_subtype     object
    death_from_cancer                  object
    dtype: object
    


```python
df[col_names_missing_values].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>neoplasm_histologic_grade</th>
      <th>cellularity</th>
      <th>mutation_count</th>
      <th>er_status_measured_by_ihc</th>
      <th>type_of_breast_surgery</th>
      <th>tumor_size</th>
      <th>oncotree_code</th>
      <th>cancer_type_detailed</th>
      <th>tumor_other_histologic_subtype</th>
      <th>death_from_cancer</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Positve</td>
      <td>MASTECTOMY</td>
      <td>22.0</td>
      <td>IDC</td>
      <td>Breast Invasive Ductal Carcinoma</td>
      <td>Ductal/NST</td>
      <td>Living</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3.0</td>
      <td>High</td>
      <td>2.0</td>
      <td>Positve</td>
      <td>BREAST CONSERVING</td>
      <td>10.0</td>
      <td>IDC</td>
      <td>Breast Invasive Ductal Carcinoma</td>
      <td>Ductal/NST</td>
      <td>Living</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2.0</td>
      <td>High</td>
      <td>2.0</td>
      <td>Positve</td>
      <td>MASTECTOMY</td>
      <td>15.0</td>
      <td>IDC</td>
      <td>Breast Invasive Ductal Carcinoma</td>
      <td>Ductal/NST</td>
      <td>Died of Disease</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2.0</td>
      <td>Moderate</td>
      <td>1.0</td>
      <td>Positve</td>
      <td>MASTECTOMY</td>
      <td>25.0</td>
      <td>MDLC</td>
      <td>Breast Mixed Ductal and Lobular Carcinoma</td>
      <td>Mixed</td>
      <td>Living</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3.0</td>
      <td>High</td>
      <td>2.0</td>
      <td>Positve</td>
      <td>MASTECTOMY</td>
      <td>40.0</td>
      <td>MDLC</td>
      <td>Breast Mixed Ductal and Lobular Carcinoma</td>
      <td>Mixed</td>
      <td>Died of Disease</td>
    </tr>
  </tbody>
</table>
</div>



For the categorial features above (dtype: Object) There are 3 columns with numeric values and rest have non-numeric values.
When checked for distinct values above we find,
neoplasm_histologic_grade take only three values (1,2,3) while mutation_count and tumor_size can take multiple values from a range of possible outcomes. thus, we will replace the missing values in the former with mode and in the latter 2 with mean values. for the non numeric terms, we will replace the missing values with mode.

<span style="color:red;">Note: to find unique values for a column, we use <span style="color:blue;">"col_name.unique()"</span> </span>


```python
fill_missing_mean(df,'mutation_count')
fill_missing_mean(df,'tumor_size')

col_1=['cellularity','neoplasm_histologic_grade','er_status_measured_by_ihc',
           'type_of_breast_surgery','oncotree_code','cancer_type_detailed','tumor_other_histologic_subtype',
           'death_from_cancer']

fill_missing_mode(df,col_1)
```


```python
# rechecking if there are any null values left 
df.isnull().sum().sort_values(ascending=False)
```




    age_at_diagnosis                  0
    bche                              0
    zfp36l1                           0
    ackr3                             0
    akr1c1                            0
    akr1c2                            0
    akr1c3                            0
    akr1c4                            0
    akt3                              0
    ar                                0
    cdk8                              0
    usp9x                             0
    cdkn2c                            0
    cyb5a                             0
    cyp11a1                           0
    cyp11b2                           0
    cyp17a1                           0
    cyp19a1                           0
    cyp21a2                           0
    cyp3a43                           0
    utrn                              0
    ush2a                             0
    sgcd                              0
    stab2                             0
    siah1                             0
    sik1                              0
    sik2                              0
    smarcb1                           0
    smarcc1                           0
    smarcc2                           0
    smarcd1                           0
    spaca1                            0
    stmn2                             0
    ubr5                              0
    syne1                             0
    taf1                              0
    taf4b                             0
    tbl1xr1                           0
    tg                                0
    thada                             0
    thsd7a                            0
    ttyh1                             0
    cyp3a5                            0
    cyp3a7                            0
    ddc                               0
    spry2                             0
    prkd1                             0
    ran                               0
    rdh5                              0
    sdc4                              0
    serpini1                          0
    shbg                              0
    slc29a1                           0
    sox9                              0
    srd5a1                            0
    hes6                              0
    srd5a2                            0
    srd5a3                            0
    st7                               0
    star                              0
    tnk2                              0
    tulp4                             0
    ugt2b15                           0
    ugt2b17                           0
    prkci                             0
    pik3r3                            0
    nrip1                             0
    ncoa2                             0
    hsd17b1                           0
    hsd17b10                          0
    hsd17b11                          0
    hsd17b12                          0
    hsd17b13                          0
    hsd17b14                          0
    hsd17b2                           0
    hsd17b3                           0
    hsd17b4                           0
    hsd17b6                           0
    hsd17b7                           0
    hsd17b8                           0
    hsd3b1                            0
    hsd3b2                            0
    hsd3b7                            0
    mecom                             0
    met                               0
    shank2                            0
    sf3b1                             0
    type_of_breast_surgery            0
    gldc                              0
    dtwd2                             0
    fam20c                            0
    fanca                             0
    fancd2                            0
    flt3                              0
    foxp1                             0
    frmd3                             0
    gh1                               0
    gpr32                             0
    dnah2                             0
    gps2                              0
    hdac9                             0
    herc2                             0
    hist1h2bc                         0
    kdm3a                             0
    kdm6a                             0
    klrg1                             0
    l1cam                             0
    dnah5                             0
    dnah11                            0
    setdb1                            0
    cacna2d3                          0
    apc                               0
    arid2                             0
    arid5b                            0
    asxl1                             0
    asxl2                             0
    bap1                              0
    bcas3                             0
    birc6                             0
    ccnd3                             0
    ctnna3                            0
    chd1                              0
    clk3                              0
    clrn2                             0
    col12a1                           0
    col22a1                           0
    col6a3                            0
    ctcf                              0
    ctnna1                            0
    lama2                             0
    lamb3                             0
    large1                            0
    prps2                             0
    pbrm1                             0
    ppp2cb                            0
    ppp2r2a                           0
    prkacg                            0
    prkce                             0
    prkcq                             0
    prkcz                             0
    prkg1                             0
    prr16                             0
    ldlrap1                           0
    ptpn22                            0
    ptprm                             0
    rasgef1b                          0
    rpgr                              0
    ryr2                              0
    sbno1                             0
    setd1a                            0
    setd2                             0
    palld                             0
    or6a2                             0
    nt5e                              0
    nrg3                              0
    lifr                              0
    lipi                              0
    magea8                            0
    map3k10                           0
    map3k13                           0
    men1                              0
    mtap                              0
    muc16                             0
    myo1a                             0
    myo3a                             0
    ncoa3                             0
    nek1                              0
    nf2                               0
    npnt                              0
    nr2f1                             0
    nr3c1                             0
    nras                              0
    ugt2b7                            0
    pik3ca_mut                        0
    tp53_mut                          0
    taf4b_mut                         0
    stk11_mut                         0
    sik2_mut                          0
    ptpn22_mut                        0
    brip1_mut                         0
    flt3_mut                          0
    nrg3_mut                          0
    fbxw7_mut                         0
    ttyh1_mut                         0
    or6a2_mut                         0
    gps2_mut                          0
    map3k13_mut                       0
    hdac9_mut                         0
    prkacg_mut                        0
    rpgr_mut                          0
    large1_mut                        0
    foxp1_mut                         0
    clk3_mut                          0
    prkcz_mut                         0
    men1_mut                          0
    cdkn1b_mut                        0
    muc16_mut                         0
    nek1_mut                          0
    setdb1_mut                        0
    fam20c_mut                        0
    arid5b_mut                        0
    egfr_mut                          0
    map3k10_mut                       0
    smarcc2_mut                       0
    erbb4_mut                         0
    npnt_mut                          0
    agmo_mut                          0
    bcas3_mut                         0
    zfp36l1_mut                       0
    smad4_mut                         0
    sik1_mut                          0
    casp8_mut                         0
    prkcq_mut                         0
    smarcc1_mut                       0
    palld_mut                         0
    dcaf4l2_mut                       0
    lipi_mut                          0
    ppp2r2a_mut                       0
    prkce_mut                         0
    mbl2_mut                          0
    frmd3_mut                         0
    smad2_mut                         0
    sgcd_mut                          0
    spaca1_mut                        0
    rasgef1b_mut                      0
    hist1h2bc_mut                     0
    nr2f1_mut                         0
    klrg1_mut                         0
    mtap_mut                          0
    gh1_mut                           0
    ppp2cb_mut                        0
    smarcd1_mut                       0
    nras_mut                          0
    ndfip1_mut                        0
    hras_mut                          0
    prps2_mut                         0
    smarcb1_mut                       0
    stmn2_mut                         0
    tbl1xr1_mut                       0
    prkg1_mut                         0
    nr3c1_mut                         0
    ccnd3_mut                         0
    gpr32_mut                         0
    kras_mut                          0
    nf2_mut                           0
    chek2_mut                         0
    ldlrap1_mut                       0
    clrn2_mut                         0
    acvrl1_mut                        0
    agtr2_mut                         0
    cdkn2a_mut                        0
    ctnna1_mut                        0
    magea8_mut                        0
    prr16_mut                         0
    dtwd2_mut                         0
    akt2_mut                          0
    braf_mut                          0
    foxo1_mut                         0
    nt5e_mut                          0
    jak1_mut                          0
    chd1_mut                          0
    pbrm1_mut                         0
    akt1_mut                          0
    arid1a_mut                        0
    lama2_mut                         0
    notch1_mut                        0
    cbfb_mut                          0
    ncor2_mut                         0
    col12a1_mut                       0
    col22a1_mut                       0
    pten_mut                          0
    atr_mut                           0
    arid1b_mut                        0
    thada_mut                         0
    ncor1_mut                         0
    stab2_mut                         0
    myh9_mut                          0
    runx1_mut                         0
    nf1_mut                           0
    map2k4_mut                        0
    ros1_mut                          0
    col6a3_mut                        0
    tbx3_mut                          0
    utrn_mut                          0
    birc6_mut                         0
    ahnak2_mut                        0
    kmt2c_mut                         0
    syne1_mut                         0
    gata3_mut                         0
    map3k1_mut                        0
    ahnak_mut                         0
    dnah11_mut                        0
    cdh1_mut                          0
    dnah2_mut                         0
    kmt2d_mut                         0
    ush2a_mut                         0
    ryr2_mut                          0
    dnah5_mut                         0
    herc2_mut                         0
    pde4dip_mut                       0
    akap9_mut                         0
    tg_mut                            0
    lamb3_mut                         0
    erbb2_mut                         0
    l1cam_mut                         0
    gldc_mut                          0
    fancd2_mut                        0
    taf1_mut                          0
    kdm6a_mut                         0
    ctnna3_mut                        0
    brca1_mut                         0
    ptprm_mut                         0
    foxo3_mut                         0
    usp28_mut                         0
    brca2_mut                         0
    sf3b1_mut                         0
    cacna2d3_mut                      0
    arid2_mut                         0
    aff2_mut                          0
    lifr_mut                          0
    sbno1_mut                         0
    kdm3a_mut                         0
    ncoa3_mut                         0
    bap1_mut                          0
    asxl1_mut                         0
    ctcf_mut                          0
    apc_mut                           0
    asxl2_mut                         0
    shank2_mut                        0
    ep300_mut                         0
    ptprd_mut                         0
    usp9x_mut                         0
    setd2_mut                         0
    setd1a_mut                        0
    thsd7a_mut                        0
    afdn_mut                          0
    erbb3_mut                         0
    rb1_mut                           0
    myo1a_mut                         0
    alk_mut                           0
    fanca_mut                         0
    adgra2_mut                        0
    ubr5_mut                          0
    pik3r1_mut                        0
    myo3a_mut                         0
    alk                               0
    akap9                             0
    ahnak2                            0
    ncstn                             0
    jag1                              0
    jag2                              0
    kdm5a                             0
    lfng                              0
    maml1                             0
    maml2                             0
    maml3                             0
    ncor2                             0
    notch1                            0
    heyl                              0
    notch2                            0
    notch3                            0
    nrarp                             0
    numb                              0
    numbl                             0
    psen1                             0
    psen2                             0
    psenen                            0
    itch                              0
    hes5                              0
    chek1                             0
    dll3                              0
    aph1a                             0
    aph1b                             0
    arrdc1                            0
    cir1                              0
    ctbp1                             0
    ctbp2                             0
    cul1                              0
    dll1                              0
    dll4                              0
    hes1                              0
    dtx1                              0
    dtx2                              0
    dtx3                              0
    dtx4                              0
    ep300                             0
    fbxw7                             0
    hdac1                             0
    hdac2                             0
    rbpj                              0
    rbpjl                             0
    rfng                              0
    bmp7                              0
    bcl2l1                            0
    bmp10                             0
    bmp15                             0
    bmp2                              0
    bmp3                              0
    bmp4                              0
    bmp5                              0
    bmp6                              0
    bmpr1a                            0
    snw1                              0
    bmpr1b                            0
    bmpr2                             0
    braf                              0
    casp10                            0
    casp3                             0
    casp6                             0
    casp7                             0
    casp8                             0
    bcl2                              0
    bad                               0
    aurka                             0
    atr                               0
    spen                              0
    hes2                              0
    hes4                              0
    hes7                              0
    hey1                              0
    hey2                              0
    acvr1                             0
    acvr1b                            0
    acvr1c                            0
    acvr2a                            0
    acvr2b                            0
    acvrl1                            0
    akt1                              0
    akt1s1                            0
    akt2                              0
    apaf1                             0
    arl11                             0
    adam17                            0
    adam10                            0
    tp53bp1                           0
    brca2                             0
    overall_survival                  0
    pr_status                         0
    radio_therapy                     0
    3-gene_classifier_subtype         0
    tumor_size                        0
    tumor_stage                       0
    death_from_cancer                 0
    brca1                             0
    palb2                             0
    mlh1                              0
    pten                              0
    tp53                              0
    atm                               0
    cdh1                              0
    chek2                             0
    nbn                               0
    nf1                               0
    stk11                             0
    overall_survival_months           0
    oncotree_code                     0
    nottingham_prognostic_index       0
    mutation_count                    0
    cancer_type                       0
    cancer_type_detailed              0
    cellularity                       0
    chemotherapy                      0
    pam50_+_claudin-low_subtype       0
    cohort                            0
    er_status_measured_by_ihc         0
    er_status                         0
    neoplasm_histologic_grade         0
    her2_status_measured_by_snp6      0
    her2_status                       0
    tumor_other_histologic_subtype    0
    hormone_therapy                   0
    inferred_menopausal_state         0
    integrative_cluster               0
    primary_tumor_laterality          0
    lymph_nodes_examined_positive     0
    bard1                             0
    msh2                              0
    mdm2                              0
    e2f7                              0
    cdkn1a                            0
    cdkn1b                            0
    e2f1                              0
    e2f2                              0
    e2f3                              0
    e2f4                              0
    e2f5                              0
    e2f6                              0
    e2f8                              0
    msh6                              0
    src                               0
    jak1                              0
    jak2                              0
    stat1                             0
    stat2                             0
    stat3                             0
    stat5a                            0
    stat5b                            0
    myc                               0
    cdkn2b                            0
    cdkn2a                            0
    ccnd2                             0
    pms2                              0
    epcam                             0
    rad51c                            0
    rad51d                            0
    rad50                             0
    rb1                               0
    rbl1                              0
    rbl2                              0
    ccna1                             0
    ccnb1                             0
    cdk1                              0
    ccne1                             0
    cdk2                              0
    cdc25a                            0
    ccnd1                             0
    cdk4                              0
    cdk6                              0
    casp9                             0
    csf1                              0
    ahnak                             0
    sptbn1                            0
    smad1                             0
    smad2                             0
    smad3                             0
    smad4                             0
    smad5                             0
    smad6                             0
    smad7                             0
    smad9                             0
    terc                              0
    rptor                             0
    tert                              0
    tgfb1                             0
    tgfb2                             0
    tgfb3                             0
    tgfbr1                            0
    tgfbr2                            0
    tgfbr3                            0
    tsc1                              0
    slc19a1                           0
    rps6kb2                           0
    csf1r                             0
    ptk2                              0
    pdgfra                            0
    pdgfrb                            0
    pdpk1                             0
    peg3                              0
    pik3ca                            0
    pik3r1                            0
    pik3r2                            0
    plagl1                            0
    rab25                             0
    rps6kb1                           0
    rad51                             0
    raf1                              0
    rassf1                            0
    rheb                              0
    rictor                            0
    rps6                              0
    rps6ka1                           0
    rps6ka2                           0
    tsc2                              0
    vegfa                             0
    vegfb                             0
    slco1b3                           0
    cyp2c8                            0
    cyp3a4                            0
    fgf2                              0
    fn1                               0
    map2                              0
    map4                              0
    mapt                              0
    nr1i2                             0
    tubb1                             0
    wfdc2                             0
    tubb4a                            0
    tubb4b                            0
    twist1                            0
    adgra2                            0
    afdn                              0
    aff2                              0
    agmo                              0
    agtr2                             0
    bmf                               0
    bbc3                              0
    abcc10                            0
    abcc1                             0
    wwox                              0
    zfyve9                            0
    arid1a                            0
    arid1b                            0
    cbfb                              0
    gata3                             0
    kmt2c                             0
    kmt2d                             0
    myh9                              0
    ncor1                             0
    pde4dip                           0
    ptprd                             0
    ros1                              0
    runx1                             0
    tbx3                              0
    abcb1                             0
    abcb11                            0
    pdgfb                             0
    pdgfa                             0
    opcml                             0
    igf1r                             0
    foxo3                             0
    gdf11                             0
    gdf2                              0
    gsk3b                             0
    hif1a                             0
    hla-g                             0
    hras                              0
    igf1                              0
    inha                              0
    map2k2                            0
    inhba                             0
    inhbc                             0
    itgav                             0
    itgb3                             0
    izumo1r                           0
    kdr                               0
    kit                               0
    kras                              0
    foxo1                             0
    folr3                             0
    folr2                             0
    folr1                             0
    cxcl8                             0
    cxcr1                             0
    cxcr2                             0
    dab2                              0
    diras3                            0
    dlec1                             0
    dph1                              0
    egfr                              0
    eif4e                             0
    eif4ebp1                          0
    eif5a2                            0
    erbb2                             0
    erbb3                             0
    erbb4                             0
    fas                               0
    fgf1                              0
    fgfr1                             0
    map2k1                            0
    map2k3                            0
    nfkb2                             0
    mmp24                             0
    mmp14                             0
    mmp15                             0
    mmp16                             0
    mmp17                             0
    mmp19                             0
    mmp2                              0
    mmp21                             0
    mmp23b                            0
    mmp25                             0
    map2k4                            0
    mmp26                             0
    mmp27                             0
    mmp28                             0
    mmp3                              0
    mmp7                              0
    mmp9                              0
    mtor                              0
    nfkb1                             0
    mmp13                             0
    mmp12                             0
    mmp11                             0
    mmp10                             0
    map2k5                            0
    map3k1                            0
    map3k3                            0
    map3k4                            0
    map3k5                            0
    mapk1                             0
    mapk12                            0
    mapk14                            0
    mapk3                             0
    mapk4                             0
    mapk6                             0
    mapk7                             0
    mapk8                             0
    mapk9                             0
    mdc1                              0
    mlst8                             0
    mmp1                              0
    siah1_mut                         0
    dtype: int64



Now I have filled all the missing values.

Proceeding to the next step in my analysis, I will convert all the variables in the correct datatype which will help me in analysing further. 
To convert all the categorial variables into numeric, I will decide the technique based on the data_type. 

<b><span style="font-size:20px"> Data Transforming</span></b>


```python
#checking the list of all columns with non numeric values

cat_cols=df.select_dtypes(object).columns

df[cat_cols].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>type_of_breast_surgery</th>
      <th>cancer_type</th>
      <th>cancer_type_detailed</th>
      <th>cellularity</th>
      <th>pam50_+_claudin-low_subtype</th>
      <th>er_status_measured_by_ihc</th>
      <th>er_status</th>
      <th>her2_status_measured_by_snp6</th>
      <th>her2_status</th>
      <th>tumor_other_histologic_subtype</th>
      <th>...</th>
      <th>mtap_mut</th>
      <th>ppp2cb_mut</th>
      <th>smarcd1_mut</th>
      <th>nras_mut</th>
      <th>ndfip1_mut</th>
      <th>hras_mut</th>
      <th>prps2_mut</th>
      <th>smarcb1_mut</th>
      <th>stmn2_mut</th>
      <th>siah1_mut</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>MASTECTOMY</td>
      <td>Breast Cancer</td>
      <td>Breast Invasive Ductal Carcinoma</td>
      <td>High</td>
      <td>claudin-low</td>
      <td>Positve</td>
      <td>Positive</td>
      <td>NEUTRAL</td>
      <td>Negative</td>
      <td>Ductal/NST</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BREAST CONSERVING</td>
      <td>Breast Cancer</td>
      <td>Breast Invasive Ductal Carcinoma</td>
      <td>High</td>
      <td>LumA</td>
      <td>Positve</td>
      <td>Positive</td>
      <td>NEUTRAL</td>
      <td>Negative</td>
      <td>Ductal/NST</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>MASTECTOMY</td>
      <td>Breast Cancer</td>
      <td>Breast Invasive Ductal Carcinoma</td>
      <td>High</td>
      <td>LumB</td>
      <td>Positve</td>
      <td>Positive</td>
      <td>NEUTRAL</td>
      <td>Negative</td>
      <td>Ductal/NST</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>MASTECTOMY</td>
      <td>Breast Cancer</td>
      <td>Breast Mixed Ductal and Lobular Carcinoma</td>
      <td>Moderate</td>
      <td>LumB</td>
      <td>Positve</td>
      <td>Positive</td>
      <td>NEUTRAL</td>
      <td>Negative</td>
      <td>Mixed</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>MASTECTOMY</td>
      <td>Breast Cancer</td>
      <td>Breast Mixed Ductal and Lobular Carcinoma</td>
      <td>High</td>
      <td>LumB</td>
      <td>Positve</td>
      <td>Positive</td>
      <td>NEUTRAL</td>
      <td>Negative</td>
      <td>Mixed</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 191 columns</p>
</div>




```python
'''Given the size of my dataset, it will be better to check the unique values in each column and 
then decide on the encoding technique accorgingly'''

# loop for columns and find distinct values

distinct_values = {}
for column in df[cat_cols]:
    unique_values = df[column].unique()
    
    distinct_values[column] = {'values': unique_values, 'length': len(unique_values)}
    
# Print distinct values and their lengths

for column, info in sorted(distinct_values.items(), key=lambda x: x[1]['length']):
    print(f"Column '{column}' : {info['length']} : {info['values']}")
    
```

    Column 'type_of_breast_surgery' : 2 : ['MASTECTOMY' 'BREAST CONSERVING']
    Column 'cancer_type' : 2 : ['Breast Cancer' 'Breast Sarcoma']
    Column 'er_status_measured_by_ihc' : 2 : ['Positve' 'Negative']
    Column 'er_status' : 2 : ['Positive' 'Negative']
    Column 'her2_status' : 2 : ['Negative' 'Positive']
    Column 'inferred_menopausal_state' : 2 : ['Post' 'Pre']
    Column 'pr_status' : 2 : ['Negative' 'Positive']
    Column 'siah1_mut' : 2 : ['0' 'T249A']
    Column 'cellularity' : 3 : ['High' 'Moderate' 'Low']
    Column 'primary_tumor_laterality' : 3 : ['Right' 'Left' 'Missing']
    Column 'death_from_cancer' : 3 : ['Living' 'Died of Disease' 'Died of Other Causes']
    Column 'hras_mut' : 3 : ['0' 'Q61R' 'N86T']
    Column 'prps2_mut' : 3 : ['0' 'G255R' 'I159F']
    Column 'smarcb1_mut' : 3 : ['0' 'D159N' 'I28L']
    Column 'stmn2_mut' : 3 : ['0' 'N145K' 'R156H']
    Column 'her2_status_measured_by_snp6' : 4 : ['NEUTRAL' 'LOSS' 'GAIN' 'UNDEF']
    Column 'nras_mut' : 4 : ['0' 'G12S' 'T124A' 'D108N']
    Column 'ndfip1_mut' : 4 : ['0' 'N68S' 'X51_splice' 'A50T']
    Column '3-gene_classifier_subtype' : 5 : ['ER-/HER2-' 'ER+/HER2- High Prolif' 'Missing' 'ER+/HER2- Low Prolif'
     'HER2+']
    Column 'hist1h2bc_mut' : 5 : ['0' 'G27S' 'A18T' 'S7C' 'I55M']
    Column 'mbl2_mut' : 5 : ['0' 'K132*' 'S85F' 'A17S' 'A120T A120E']
    Column 'mtap_mut' : 5 : ['0' 'I255L' 'A247S' 'A213S' 'I138M']
    Column 'ppp2cb_mut' : 5 : ['0' 'R254Q' 'I224S' 'G128V' 'R110C']
    Column 'smarcd1_mut' : 5 : ['0' 'N84S' 'M366T' 'L434M' 'P78R']
    Column 'cancer_type_detailed' : 6 : ['Breast Invasive Ductal Carcinoma'
     'Breast Mixed Ductal and Lobular Carcinoma'
     'Breast Invasive Lobular Carcinoma'
     'Breast Invasive Mixed Mucinous Carcinoma' 'Breast'
     'Metaplastic Breast Cancer']
    Column 'oncotree_code' : 6 : ['IDC' 'MDLC' 'ILC' 'IMMC' 'BREAST' 'MBC']
    Column 'tumor_stage' : 6 : [2.0 1.0 4.0 3.0 'Missing' 0.0]
    Column 'agtr2_mut' : 6 : ['0' 'P271L' 'F272L' 'V23M' 'G113V' 'F134L']
    Column 'nr2f1_mut' : 6 : ['0' 'R225C' 'T329M' 'D91E' 'Q43del' 'L251Q']
    Column 'klrg1_mut' : 6 : ['0' 'C75F' 'X186_splice' 'C176Y' 'N84K' 'S31P']
    Column 'pam50_+_claudin-low_subtype' : 7 : ['claudin-low' 'LumA' 'LumB' 'Her2' 'Normal' 'Basal' 'NC']
    Column 'smad2_mut' : 7 : ['0' 'E150K' 'S2L' 'L261F' 'D59H' 'H198D' 'K19E']
    Column 'sgcd_mut' : 7 : ['0' 'T251M' 'R32Q' 'G276R' 'A168E' 'V264I' 'Y27C']
    Column 'tumor_other_histologic_subtype' : 8 : ['Ductal/NST' 'Mixed' 'Lobular' 'Tubular/ cribriform' 'Mucinous'
     'Medullary' 'Other' 'Metaplastic']
    Column 'kras_mut' : 8 : ['0' 'G12S' 'R167T' 'G12C' 'G12V' 'A59T' 'G12A' 'G12D']
    Column 'spaca1_mut' : 8 : ['0' 'S256C' 'A42S' 'V199I' 'Q156K' 'S130N' 'C230*' 'E50G']
    Column 'rasgef1b_mut' : 8 : ['0' 'V418A' 'S343G' 'R140Q' 'X2_splice' 'R353H' 'H396Y' 'E78K']
    Column 'magea8_mut' : 9 : ['0' 'L139F' 'A68V' 'E114K' 'K11Q' 'A264V' 'L213F' 'R279T' 'I164N']
    Column 'prkg1_mut' : 9 : ['0' 'S396L' 'V362A' 'R483Q' 'E227Q' 'E328K' 'T192A' 'A337V' 'A341T']
    Column 'tbl1xr1_mut' : 9 : ['0' 'C175W' 'D190Y' 'S326N' 'K379Hfs*27' 'S119N' 'X68_splice' 'D369Y'
     'X256_splice']
    Column 'frmd3_mut' : 9 : ['0' 'S183L' 'T565P T565K' 'P89A' 'E474Q' 'R21Gfs*12' 'T124=' 'E581D'
     'R364H']
    Column 'ldlrap1_mut' : 10 : ['0' 'A284T' 'V271I' 'D303N' 'N138S' 'I108V' 'A69T' 'R151W' 'R196H'
     'P201R']
    Column 'cdkn2a_mut' : 10 : ['0' 'S12*' 'H83Y' 'R80*' 'R22Q' 'L113V' 'Y44Tfs*9' 'V115E' 'E119K R138K'
     'G23V']
    Column 'akt2_mut' : 10 : ['0' 'G159C' 'Q391H' 'E43D' 'R170W' 'R269Q' 'H469Y' 'D416N' 'R253W'
     'W80delinsCRDPTPLSYAACSG']
    Column 'nt5e_mut' : 10 : ['0' 'A567T' 'A5T' 'I173V' 'Q153E' 'E293Q' 'P318T' 'G453=' 'E196K'
     'D111Mfs*17']
    Column 'ccnd3_mut' : 10 : ['0' 'P17S' 'I208T' 'Q260*' 'E122G' 'S169F' 'R33G' 'Q25E' 'T184N' 'R87L']
    Column 'nr3c1_mut' : 10 : ['0' 'S269R' 'Q74R' 'T504S' 'E730K' 'L78P' 'F29L' 'Y545C' 'E362K' 'Y30H']
    Column 'integrative_cluster' : 11 : ['4ER+' '3' '9' '7' '4ER-' '5' '8' '10' '1' '2' '6']
    Column 'gpr32_mut' : 11 : ['0' 'D88G' 'S32F' 'G110R' 'W107C' 'A230E' 'S174A' 'S309N S310C' 'N30S'
     'R180Q' 'V249I']
    Column 'clrn2_mut' : 11 : ['0' 'A144T' 'H199L' 'K7N' 'A207V' 'R67Q' 'E222K' 'I124N' 'C69Y' 'E183K'
     'A95T']
    Column 'acvrl1_mut' : 11 : ['0' 'R200W' 'I417F' 'C51*' 'D360N' 'V442L' 'G114A' 'G283S' 'R28W' 'R57Q'
     'C51Y']
    Column 'dtwd2_mut' : 11 : ['0' 'R31W' 'A42V' 'R263H' 'R246C' 'A15T' 'R109H' 'P67R' 'R195*' 'L269P'
     'Y152H']
    Column 'braf_mut' : 11 : ['0' 'V600E' 'E695Q' 'F346L' 'Q386L' 'A320T' 'Q94E' 'S110F' 'D143G'
     'I379Mfs*3' 'K338E']
    Column 'foxo1_mut' : 11 : ['0' 'T397A' 'V347M' 'S155F' 'S322G' 'T627S' 'H220N' 'P395S' 'A48T' 'A61V'
     'D611E']
    Column 'or6a2_mut' : 12 : ['0' 'T41N' 'V302I' 'M149Ifs*62' 'R144Q' 'R266Q' 'R239C' 'T41N C114Y'
     'P320T' 'R298C' 'V37A' 'Y257S']
    Column 'lipi_mut' : 12 : ['0' 'D301Y' 'S156G' 'V98I' 'T304I' 'T222M' 'V366G' 'T287R' 'Q20H' 'R297H'
     'Q275*' 'P111L']
    Column 'ctnna1_mut' : 12 : ['0' 'D114H' 'X101_splice' 'Q887*' 'A885V' 'P462L' 'D904A' 'R300C' 'R586C'
     'R126Q' 'A224T' 'K733*']
    Column 'prr16_mut' : 12 : ['0' 'E28*' 'N156K' 'N273S' 'P125H' 'T294M' 'P276S' 'L51R' 'L117P' 'P250L'
     'A182T' 'N100I']
    Column 'akt1_mut' : 13 : ['0' 'E17K' 'E94K' 'D323G' 'L52R' 'Q79_W80insSGPGPTPSSSAACR' 'W80R'
     'L235=' 'G303S' 'Q79K' 'M446I' 'R174C' 'M227T']
    Column 'ppp2r2a_mut' : 13 : ['0' 'D406E' 'R303G' 'N386S' 'R298Q' 'R142S' 'E83Rfs*3' 'Y305Lfs*23'
     'S15Lfs*3' 'I183V' 'H326L' 'Q57E' 'T373I']
    Column 'gh1_mut' : 13 : ['0' 'K96E' 'L150Q' 'A2T' 'Q110E' 'E65D' 'Y190H' 'A39T' 'G157D' 'A43T'
     'E82D' 'D179N' 'A131T']
    Column 'nf2_mut' : 13 : ['0' 'E393K' 'Q125Dfs*6' 'R198*' 'A416V' 'E564del' 'H116R' 'R411H' 'A142D'
     'V589M' 'V435L' 'T480M' 'R353T']
    Column 'chek2_mut' : 13 : ['0' 'G259Wfs*13' 'W97*' 'K197E' 'D77N' 'W485*' 'I364T' 'R346H' 'N105K'
     'E239K' 'T389A' 'Y123C' 'F310V']
    Column 'prkcz_mut' : 14 : ['0' 'R137H' 'R49C' 'E590K' 'R137S' 'R84C' 'G118E' 'E207K' 'D524N' 'L402P'
     'A142V' 'G425R' 'G248V' 'R117Q']
    Column 'prkce_mut' : 14 : ['0' 'E341K' 'D505N' 'K301R' 'Y584H' 'D431H' 'R282H' 'K457N' 'I51M'
     'V160I' 'E80K' 'D541E' 'R236Q' 'R148K']
    Column 'large1_mut' : 15 : ['0' 'R577S' 'E63K' 'D441N' 'R450H' 'R414P' 'D584N' 'V40A' 'S57Lfs*175'
     'E35K' 'T631M' 'D470H' 'Q722E' 'E466Q' 'D250V']
    Column 'clk3_mut' : 15 : ['0' 'R241W' 'E514Q' 'R420K' 'E221K' 'Y205C' 'D372H' 'L623R' 'E137Gfs*17'
     'C266Y' 'E456del' 'E492K' 'R261H' 'P185S' 'F376L']
    Column 'fbxw7_mut' : 16 : ['0' 'E30K' 'K343Qfs*33' 'E192A' 'L457F' 'S86L' 'E102D' 'R13*' 'T144R'
     'Y291C' 'K189Sfs*66' 'R430K' 'R465C' 'R479Q' 'V514I' 'G517R']
    Column 'gps2_mut' : 17 : ['0' 'X133_splice' 'X32_splice' 'H196D' 'H196Pfs*11' 'X268_splice'
     'Q224Afs*36' 'V293Efs*?' 'G182Afs*163' 'X68_splice' 'A187V' 'Q226*'
     'M153Ifs*192' 'T239Rfs*105' 'Q224*' 'V122Cfs*27' 'S61*']
    Column 'taf4b_mut' : 17 : ['0' 'R147S' 'T369N' 'S165C' 'V208I' 'K769N' 'R848W' 'T444I' 'D615A'
     'N539I' 'S449L' 'L579V' 'P212S' 'A407V' 'R834S' 'V382F' 'E613D']
    Column 'prkacg_mut' : 17 : ['0' 'V124M' 'R271L' 'C200R' 'P244H' 'V192L' 'A207V' 'A4V' 'K296R' 'A6D'
     'R337W' 'P238S' 'D42V' 'F130Y' 'A154D' 'F186L' 'M129T']
    Column 'rpgr_mut' : 17 : ['0' 'T265Rfs*36' 'Q227E' 'R409C' 'A372S' 'Y547F' 'E139K' 'R449Q' 'T383A'
     'G113V' 'A83T' 'R413G' 'G325R' 'T51=' 'D158N' 'V49I' 'T574M']
    Column 'foxp1_mut' : 17 : ['0' 'S122I' 'Q73Pfs*7' 'E4Rfs*38' 'Y147S' 'W534* T535P' 'T390S' 'L640R'
     'Q157*' 'S37T' 'S290N' 'R503*' 'Q208*' 'E538K' 'A54T' 'Q182*' 'P382=']
    Column 'ttyh1_mut' : 18 : ['0' 'V218L' 'E149K' 'A34V' 'R382W' 'G86R' 'R442C' 'V209A' 'L322V' 'A172T'
     'I62F' 'M249I' 'I136T' 'R73Q' 'P196S' 'R177W' 'A179S' 'C72G']
    Column 'ptpn22_mut' : 19 : ['0' 'T109N' 'R70W' 'S520C' 'I404V' 'A606S' 'I19T' 'I348Sfs*14' 'R748G'
     'D197V' 'Y471N' 'S782L' 'X761_splice' 'X712_splice' 'E72K' 'G524A'
     'X66_splice' 'P768S' 'F706del']
    Column 'flt3_mut' : 19 : ['0' 'M737I' 'Y696C' 'P888S' 'C695Tfs*70' 'S976R' 'H732D' 'Q771P' 'K263E'
     'P738R' 'L198F' 'E716K' 'K663R' 'S337C' 'S993T' 'P116R' 'I542M' 'T167A'
     'G282V']
    Column 'map3k13_mut' : 19 : ['0' 'Q426*' 'E431G' 'L241H' 'A247G' 'D662E' 'Q625E' 'S694L' 'R914H'
     'V751E' 'R837L' 'Q5E' 'S901L' 'R478Q' 'I194M D601N' 'F120I' 'R880C'
     'L925V' 'H15D']
    Column 'hdac9_mut' : 19 : ['0' 'I837M' 'P706S' 'X263_splice' 'R442H' 'R679Q' 'D807E' 'P282T'
     'S1005T' 'R667*' 'L985R' 'V647I' 'P296S' 'R947H' 'A636T' 'S273A S276T'
     'T426A' 'A584V' 'L878F']
    Column 'dcaf4l2_mut' : 20 : ['0' 'G395S' 'P364T' 'A40T' 'S199C' 'C255Y' 'H198Q' 'H137Y' 'S199C P26L'
     'R76C' 'E325Q' 'S393P' 'R254H' 'S67P' 'R125W' 'E324K' 'L253Q' 'R44C'
     'P6L' 'E2K']
    Column 'cdkn1b_mut' : 20 : ['0' 'K47Sfs*24' 'A28Qfs*95' 'S125*' 'H48Rfs*17 A55G' 'Q147Efs*2'
     'E86* D63H' 'P137L' 'K73N' 'Q65H' 'L130delinsFGGPKD*S' 'S138Afs*5' 'Q65*'
     'Q77*' 'V174I' 'C148Y' 'X159_splice' 'P92S' 'P179Qfs*46' '*199Yext*60']
    Column 'sik2_mut' : 20 : ['0' 'N395K' 'P223S' 'A732T' 'R437Q' 'R113W' 'S554G' 'P185L' 'Q603R'
     'Q319H' 'S845del' 'Q668K' 'Q800*' 'S762delinsFSAGPTVQP' 'I79V' 'A854T'
     'A633V' 'P832del' 'Q866*' 'L675R']
    Column 'nrg3_mut' : 20 : ['0' 'R670L' 'E282Q' 'S238F' 'G24_A30del' 'A18T' 'L419F' 'S120C S238F'
     'H171Y' 'A704V' 'C298R' 'S254F' 'E514K V679I' 'R562Q' 'S105Y' 'G214E'
     'A230S' 'E417D' 'R562Q E51V' 'A142S']
    Column 'bcas3_mut' : 21 : ['0' 'R516W' 'P519L' 'Q252E' 'H374Y' 'E325K' 'L517F' 'R454L' 'D337E'
     'V44M' 'A583S' 'I615V' 'P911L' 'A552V' 'V818L' 'L692=' 'P565S' 'V809I'
     'E855K' 'A349V' 'M447R']
    Column 'men1_mut' : 21 : ['0' 'N194Mfs*35' 'S492A' 'E364del' 'E196K' 'V101I' 'D70Tfs*49' 'P79S'
     'D423H' 'R108G L48V' 'P545S R394P' 'G230R' 'R612C' 'S122*' 'R223W' 'S38F'
     'I353M' 'E397*' 'D177Y M283I' 'E371Kfs*2' 'E397K']
    Column 'brip1_mut' : 21 : ['0' 'M1?' 'D546G' 'N851Y S682C' 'E412Q' 'T997Rfs*61' 'C219R' 'X31_splice'
     'Q227E' 'K242N G859E R261K K234N M273I' 'T232I' 'H213R' 'F934S' 'P785L'
     'L573V' 'V894I' 'H804R' 'I610V' 'H835Q' 'W1217*' 'I780L']
    Column 'smad4_mut' : 22 : ['0' 'S223delinsKSACQYTGGQPC' 'X142_splice' 'Q366*' 'X302_splice' 'D351G'
     'A319GS*VLVFHCLL*NGCSX' 'L47P' 'H92Y' 'Q245*' 'H405Y' 'Q224* A406V'
     'T222I' 'M331Nfs*11' 'R97H' 'D493H' 'X83_splice' 'W524C' 'R38Efs*7'
     'K340_S343del' 'R135*' 'G386V']
    Column 'casp8_mut' : 22 : ['0' 'R233P' 'R68Q' 'E126V' 'I144M' 'D15N' 'F61Lfs*10' 'E376D' 'C309Y'
     'T341N' 'X184_splice' 'I238T' 'V150I' 'G155V' 'S186R' 'D18H' 'Q97*'
     'X1_splice' 'N198=' 'I144T' 'I38M' 'G342V']
    Column 'prkcq_mut' : 22 : ['0' 'V394A' 'L304S' 'V157I' 'V79M' 'E296Q' 'M230Nfs*39' 'D61H' 'R703W'
     'I73T' 'P650L' 'L280H' 'L142F' 'X503_splice' 'P336L' 'A521V' 'E137D'
     'G138A' 'Q192R' 'W56L' 'X482_splice' 'C20G']
    Column 'smarcc1_mut' : 22 : ['0' 'A744G' 'X409_splice' 'E908Q' 'E721G' 'L611V' 'D250G' 'Y683C' 'D802E'
     'Q298R A521V' 'Q364E' 'R299Q' 'E591Q' 'X216_splice' 'R491*' 'A579D'
     'D851N' 'A985G' 'T375I' 'V710M' 'T337A' 'A560S']
    Column 'palld_mut' : 22 : ['0' 'S777L' 'P566R' 'V1038A' 'G381*' 'D1040N' 'P268L' 'R341H' 'Q1009H'
     'S595R' 'T850N' 'R143H' 'R689H' 'V1074M' 'S279T' 'R908H' 'N23D' 'R1049H'
     'R138Q' 'S286G' 'R663G' 'E705K']
    Column 'stk11_mut' : 22 : ['0' 'K312Nfs*14' 'R86*' 'S59Lfs*103' 'V143M' 'K62M' 'R147C' 'M125Nfs*40'
     'D53Gfs*110' 'H306Y' 'S216F' 'T328Ifs*32' 'N380S' 'X6_splice' 'G187C'
     'S307G' 'A205P' 'H345R' 'A420S' 'A316G' 'V243Sfs*44' 'N119D']
    Column 'sf3b1_mut' : 23 : ['0' 'K700E' 'D894N' 'K741E' 'G742D' 'R238H' 'G751V' 'A263V' 'L1141R'
     'I58V' 'K700Gfs*30 Q699Hfs*16' 'Y765H' 'V352I' 'R132H' 'E180K' 'K666E'
     'S851C' 'A899V' 'R1259Q' 'N626H' 'K666T' 'W658S' 'R425*']
    Column 'npnt_mut' : 23 : ['0' 'S264L' 'T490M' 'T311N' 'K459N' 'G449=' 'T275A' 'T546N' 'S562A'
     'P328_P329insT' 'G353R' 'M476R' 'S227C' 'R565H' 'R63Q' 'V374I' 'N273H'
     'D202N' 'A174T' 'I325V' 'N73D' 'K241E' 'A229T']
    Column 'agmo_mut' : 23 : ['0' 'K245N' 'E54Q' 'D112G' 'Q31R' 'R17C' 'L240del' 'T339Sfs*12' 'M134I'
     'X226_splice' 'I205V' 'R405*' 'T339I' 'I242del' 'L412P' 'F400C' 'F89L'
     'R405Q' 'P411L' 'X42_splice' 'G15R' 'I426V' 'L313V']
    Column 'sik1_mut' : 23 : ['0' 'P635R' 'E456K' 'P698R' 'A288S' 'A518P I489V' 'A676P' 'A191T' 'R385Q'
     'G624S' 'A676T' 'S135L' 'V317M' 'A294V' 'V434M' 'S545L' 'T231M' 'S547T'
     'V260A' 'C774G' 'A354S' 'P679Q' 'A513G']
    Column 'jak1_mut' : 24 : ['0' 'S914I' 'G307S' 'F692L' 'I39M' 'R873C' 'V694Sfs*15' 'C763Y' 'V658F'
     'X663_splice G600R' 'P517L' 'S43L' 'D660N' 'S383G' 'S407F' 'R108W'
     'D947=' 'H303Qfs*17' 'E864K' 'F482Y' 'V1017G' 'E730K' 'P761H' 'F40L']
    Column 'usp28_mut' : 25 : ['0' 'D60H' 'Q219*' 'L872V' 'P723A' 'K420*' 'Q35R' 'A83S' 'F232S' 'A564V'
     'V63L' 'I177T' 'R396K' 'E848*' 'D158H' 'E410Vfs*40' 'T710A' 'A868V'
     'N384S' 'Y717F' 'D969Y' 'A270T' 'R938W' 'X722_splice Y914Kfs*53 M23I'
     'E658=']
    Column 'fam20c_mut' : 25 : ['0' 'A128S' 'A398S' 'G153D' 'S100T' 'E427K' 'E306K' 'G127S' 'R530Q'
     'A26P' 'V570L' 'Y539S' 'R414H' 'Q289R' 'T290M' 'D573N' 'T472M' 'V569M'
     'A583V' 'R10G' 'R481T' 'L102I' 'A417=' 'V326I' 'L494V']
    Column 'smarcc2_mut' : 25 : ['0' 'R578C' 'S745F' 'P231A' 'N173D' 'A18V' 'H501R' 'V3A' 'E222Q K196N'
     'M615I' 'V834A' 'L339V' 'W205*' 'I818V' 'R760W' 'S321L' 'R108L' 'P1043A'
     'R268C' 'P1089S' 'E250K' 'I1108V' 'R776Q' 'A1002D' 'P1145A']
    Column 'nek1_mut' : 25 : ['0' 'R467T' 'G763E' 'E640*' 'E1123K' 'S1169G' 'D1180N' 'V685M' 'L898W'
     'E893G' 'R161Q' 'K278R' 'M670I' 'A1014V' 'E360D' 'E994Q' 'S863L' 'R232C'
     'I939_Q942delinsK' 'H1018Y' 'D651E' 'P318S' 'R714C' 'G764D' 'S687N']
    Column 'zfp36l1_mut' : 25 : ['0' 'C34Gfs*42' 'S59Qfs*16' 'G270R' 'V55Kfs*26' 'X19_splice' 'L13F'
     'H63Tfs*17' 'H139Qfs*9' 'M23Nfs*5' 'D37Gfs*38' 'H177Q' 'K61Qfs*14'
     'P171Afs*10' 'L68Pfs*7' 'E156Gfs*25' 'G270E' 'I329_F330del' 'G20Vfs*60'
     'S70T' 'L185Rfs*8' 'S318Ffs*45' 'G33Rfs*48' 'K152Qfs*29' 'C34Lfs*41']
    Column 'chd1_mut' : 26 : ['0' 'T292I' 'G1397S' 'R1094K' 'D1388H' 'E1146Q' 'H1554R' 'R1708W'
     'V456_L457insYVE*E**EWALSCSSS K458Rfs*4' 'V96I' 'G1097E' 'S966A' 'V263A'
     'S158F' 'E65Q' 'W149R' 'D1164V' 'S28*' 'D1368G' 'D302N' 'R1586H' 'E246*'
     'E223del' 'F277Lfs*43' 'Y1553C' 'R1586C']
    Column 'egfr_mut' : 26 : ['0' 'R671C' 'D1014N' 'E519G' 'W1157*' 'A859V' 'H773D' 'A439V' 'R962G'
     'T488S' 'E513K' 'R334L' 'S511Y' 'R527W' 'R836C' 'H988R' 'W880*' 'K713T'
     'E257K' 'V592I' 'R98Q' 'H145R' 'V674I' 'P20S' 'R705S' 'A127T']
    Column 'map3k10_mut' : 26 : ['0' 'T918P' 'A782_P840del' 'R221Q' 'L799_E800del' 'E3K' 'L518=' 'A884V'
     'R575Efs*4' 'R850H' 'V20F' 'S478F' 'T491I' 'E547K' 'G6E' 'D733Y' 'R276H'
     'V521M' 'V274I' 'R557Q' 'I360F' 'V106L' 'R569Q' 'R512W' 'P778_P781del'
     'R356Q']
    Column 'pbrm1_mut' : 27 : ['0' 'E1318K' 'S652A' 'V978I' 'Y470C' 'N1262S' 'F1051L' 'S1618Afs*29'
     'A1098S' 'P1583S' 'V964I' 'S1621P' 'R1185*' 'Q793*' 'H599Q' 'N716S'
     'P808L V1083L' 'R332H' 'K1378R' 'S941L' 'G166V G166R' 'X856_splice'
     'V1086A' 'T737Sfs*31 Y738Dfs*8' 'R341H' 'R332P' 'S711G']
    Column 'erbb4_mut' : 27 : ['0' 'T443I' 'R78W' 'Q941*' 'S853Y' 'A158E' 'Y268C' 'E1280K' 'E1010V'
     'L521V' 'G758A' 'A685D E82K' 'Q1026*' 'R106H' 'E542K' 'I792F' 'D813N'
     'D1156G' 'R525H' 'R938S' 'E869K' 'G1143A' 'A90S' 'I381V' 'S184L' 'M1?'
     'I353T']
    Column 'kdm3a_mut' : 28 : ['0' 'X10_splice' 'P118S' 'G336=' 'I150V' 'V260A' 'R555H' 'R262H' 'Y1255H'
     'H338Y' 'R1219T' 'I625T' 'L576delinsFTI' 'T773I' 'T161R' 'T868M' 'R107Q'
     'P1031T' 'C496Y' 'P841L' 'S347F' 'K779T' 'K545Nfs*42' 'R659*' 'V35L'
     'G252V' 'E355K' 'A1103G']
    Column 'ncoa3_mut' : 28 : ['0' 'R1163Q' 'R1074Sfs*6 H504Lfs*27' 'G435R' 'T1166N' 'R317H' 'R36Q'
     'Q565*' 'R907*' 'I873S' 'I556V' 'M938V' 'Q1320P' 'Y852C' 'G1341C' 'I713K'
     'Q779P' 'I296T' 'N325D' 'P499S' 'Y998C' 'N283D' 'N1333S' 'R487H' 'R251C'
     'M391V' 'M1210I' 'N672S']
    Column 'arid5b_mut' : 28 : ['0' 'R335S' 'A569V' 'T565A' 'D661Y' 'M744T' 'I444M K551R' 'R956W'
     'L78I V129M P404Q' 'A1046P' 'P1170T' 'E519K' 'N867S' 'L555F' 'S1047F'
     'E406K' 'E527K' 'H980Q' 'R748Q' 'M619T' 'K49E' 'E765D' 'V280I' 'P487H'
     'D636N' 'A1172P' 'H821R' 'P543S']
    Column 'sbno1_mut' : 29 : ['0' 'V1346L' 'V191I' 'S768P' 'R813*' 'S1326G' 'R571Q' 'L527F' 'R813Q'
     'A1018T' 'E306*' 'N834_S839del' 'P1351L' 'V61L' 'A1393T' 'R131C' 'P871A'
     'D321N' 'D732N' 'R569K' 'V392A' 'V1115G' 'A239T' 'R1336Q' 'D738H' 'M525V'
     'I520V' 'D696H' 'R983T']
    Column 'setdb1_mut' : 29 : ['0' 'R1194H' 'E696K' 'N1266S' 'L1278H' 'R1165Q' 'P672L' 'E696*'
     'X527_splice' 'P567S' 'M791V' 'A1024T' 'R1048*' 'R1074C' 'D1132H'
     'S1081I' 'P1192Hfs*127' 'N762D' 'P496S' 'I1037V' 'F995C' 'P950R' 'N988S'
     'I1037M' 'S1124L' 'D607N' 'D1044H' 'R1086Q' 'G1016E']
    Column 'cacna2d3_mut' : 30 : ['0' 'R388*' 'Q249R' 'D876N' 'G84D' 'D592N' 'T853A' 'A1070V' 'R836K'
     'R810W' 'N347S' 'N910K' 'E544K' 'I335_G336del' 'R440W' 'R205G' 'T874='
     'E681G' 'R1042C' 'W950C' 'I340V' 'V110G' 'P225=' 'G226=' 'A817V'
     'G722_V723insR' 'A698T' 'Q446R' 'M892V' 'T872A']
    Column 'aff2_mut' : 30 : ['0' 'S381*' 'R870C' 'S224C' 'R599W' 'H366R' 'R927H' 'G935V' 'E53Q'
     'Q295*' 'P178S' 'S753R' 'E501K' 'P892S' 'I309T' 'A1197T' 'V417M' 'A245T'
     'S374Y' 'E433K' 'A979P' 'A979T' 'V1253A' 'L1034I' 'P791L' 'T975P'
     'R1238S' 'T574M' 'T444A' 'V169A']
    Column 'gldc_mut' : 31 : ['0' 'D43G' 'L120V' 'I989T' 'M394V' 'S951Y' 'L716H' 'G854V' 'A64T' 'I717V'
     'R212K' 'T269M' 'M663I' 'T642M' 'Y858S' 'X112_splice' 'S547C D793N'
     'Q587*' 'D712E' 'E909D' 'G48R Q285H' 'N193S' 'M840V' 'I834T'
     'X820_splice' 'C1000R' 'G771E' 'A624T' 'R941T I710F' 'V233A' 'F463L']
    Column 'bap1_mut' : 31 : ['0' 'R717Q' 'E566K' 'X137_splice' 'R56C' 'Y33*' 'S623Rfs*14' 'Q372E'
     'R699P' 'A321V' 'P222T' 'G307Rfs*87' 'K120E' 'N102I' 'R264T' 'P555T'
     'X220_splice' 'V354I' 'R699W' 'V447I' 'C649Y' 'S105I' 'D404E'
     'E602V K601E' 'L49R' 'G422R' 'P293L' 'V24G' 'K331E' 'R179W' 'K651del']
    Column 'l1cam_mut' : 31 : ['0' 'R241C' 'N433K' 'E1120K' 'R937C' 'L818V' 'R558G' 'R311C' 'D206E'
     'P160T' 'D972H' 'V592M' 'R976Q' 'R554C' 'Q929L A1237V' 'A906T' 'G919S'
     'E315K' 'A1237V' 'A1101G' 'E705K' 'A123T' 'S1181=' 'M1012T' 'K56T'
     'M400V' 'R834W' 'W635Gfs*58' 'T50R' 'C57F' 'M187R']
    Column 'lifr_mut' : 32 : ['0' 'I220N' 'H228R' 'S151C' 'G967E' 'I925V' 'A813S' 'P288S' 'E342K'
     'D816Wfs*50' 'M1005I' 'P1045S' 'F255Sfs*3' 'T318A' 'P983R' 'S446*'
     'T152A' 'I1016V' 'M2V' 'R384T E386K' 'D1074G' 'D249V' 'I509T' 'R167H'
     'E921Q' 'R178C' 'N960D' 'S893R' 'H105R' 'A930S' 'D334G' 'M672Yfs*12']
    Column 'brca2_mut' : 33 : ['0' 'K68T' 'D1911N' 'S2133*' 'C3069Lfs*5' 'E1120V' 'D3378V' 'T3310Nfs*17'
     'A737V' 'V741L' 'R2973C' 'H2455R' 'K280*' 'S231R' 'D3378N' 'L2654Ffs*3'
     'V2166L' 'S3366Mfs*2 V3365_S3366insELY' 'E1581Q' 'K1875N' 'G4V' 'C670W'
     'F506L' 'E2844K' 'N319S' 'Y3098*' 'I1583T' 'V2687I' 'S1115Lfs*4' 'Q3066*'
     'A3205V A3205P' 'E1514K' 'D806N']
    Column 'arid2_mut' : 34 : ['0' 'E427*' 'N577S' 'V1172I' 'T653I' 'T986I' 'P914S' 'X527_splice'
     'R542P A1438P' 'M364_R366del' 'V190I' 'W237*' 'Q694H' 'Q651P'
     'W1636Cfs*65' 'T1422I' 'P1594A' 'E420Kfs*13' 'S748G' 'L354V' 'P1356L'
     'P1073S' 'D444=' 'S184L' 'L1815V' 'G1110E' 'K119Q' 'K1627N' 'S1045L'
     'T1522S' 'T1208P' 'N1295S' 'S1279G' 'G1209A']
    Column 'ptprm_mut' : 35 : ['0' 'P64L' 'G1119V' 'H988Y' 'T1160I' 'A879T' 'A672T' 'A1208V' 'Y273C'
     'K90N' 'R1191Q' 'I647V' 'M809I' 'V1006=' 'T437A' 'T1181K' 'N602S' 'P727L'
     'T811M' 'A291T' 'D527N' 'R430Q' 'S778R' 'A1401T' 'E275D' 'G723*' 'D1236N'
     'R699K' 'D1015V' 'F753S' 'T890A' 'R138H' 'G79E' 'S951T' 'R1201Q']
    Column 'foxo3_mut' : 36 : ['0' 'A499Gfs*16' 'A140Rfs*26 L127_L133del' 'T228Nfs*12' 'D340A' 'G618E'
     'M493Dfs*22' 'N159Tfs*7' 'P112S' 'F309Lfs*7 S311Hfs*4' 'Q128L' 'D490E'
     'R211W' 'Q130*' 'W186Cfs*10' 'S505P' 'P10L' 'E23K' 'S215* S297L' 'A352T'
     'W157*' 'T433M' 'X208_splice' 'R444H' 'I170F' 'W206L' 'T582S'
     'R310Afs*36' 'G111E' 'S619Afs*36' 'S26C' 'A543S' 'G406Dfs*35' 'A98T'
     'S173F' 'R266H']
    Column 'erbb2_mut' : 37 : ['0' 'V842I' 'T479M' 'E770_A771insGIRD' 'R929W' 'D769Y' 'L755S' 'V777L'
     'S310F E139Sfs*11' 'S609C' 'L755_T759del' 'P122L' 'A1039T' 'Y64F' 'P523S'
     'R288Q' 'R203P' 'D873G' 'R47C' 'D808E' 'X408_splice' 'P232S'
     'V777L T862A' 'P579L' 'V777L G727A' 'V842I L755S P416T' 'D277H' 'D639E'
     'V1128I' 'R34W' 'S609F' 'L869R' 'I767M' 'I435L' 'S310F' 'G778_S779insLPS'
     'R897G']
    Column 'ctnna3_mut' : 37 : ['0' 'Q260H' 'V551I' 'I859F' 'P265L' 'R374C' 'Q269*' 'R750W' 'R535H'
     'E770*' 'K179E' 'M824I' 'D531H' 'G793E' 'M710K' 'G561E' 'C225F'
     'R484H S637F' 'G793E I880T' 'K863R' 'A130P' 'A255V' 'L858F' 'T240A'
     'Q17*' 'G793E M435V I411V' 'G793E P116L' 'M435V I411V' 'R484C' 'R378H'
     'E634K' 'A508D' 'V144A' 'A689V' 'C222F' 'T867M' 'V385A']
    Column 'brca1_mut' : 37 : ['0' 'S1551C' 'E914K' 'D420G' 'R1737T' 'V1654Cfs*4' 'Y1127H' 'W372R'
     'I216S' 'S153R' 'X1760_splice' 'G1087E' 'C305S' 'L1439F' 'T150Pfs*13'
     'I946V' 'E1494Kfs*11' 'M1827L' 'E143K' 'R613K' 'X1453_splice'
     'E880Rfs*13' 'S1266T' 'D560Efs*6' 'E1836K' 'E391K' 'E1287K' 'S282*'
     'I171M' 'D1692N' 'V452A' 'X1663_splice' 'L502Sfs*2' 'K1667Qfs*11'
     'Q202Kfs*32' 'R1074T' 'F709Sfs*29']
    Column 'erbb3_mut' : 39 : ['0' 'G325R' 'G284R' 'E928G' 'M60K' 'K314E' 'P306R' 'E745K' 'R970*'
     'R247Q' 'R490H' 'V104L' 'R1040Q' 'P554L' 'V586M' 'T906S' 'M677I' 'G908R'
     'P514Rfs*10 P514Hfs*18' 'K742R' 'R453H E1018Q' 'E1317K' 'D297Y' 'T355I'
     'Y464H' 'Q865H' 'R1080H' 'T355I E928G' 'G513D' 'A1030T' 'G324R' 'N222S'
     'S717L' 'S1207N' 'R135H' 'A1131T G113R' 'D951H' 'E910A' 'E1291*']
    Column 'kdm6a_mut' : 39 : ['0' 'T726M' 'Q1133*' 'S582*' 'P524R' 'A822V' 'R1351*' 'L1177P'
     'R380Efs*59' 'W1258*' 'A1399T' 'I598V' 'V1225F' 'N448D' 'N444S' 'N777K'
     'X641_splice' 'G284S' 'L73Dfs*12 G74Rfs*11 L72Afs*10' 'M1136I' 'S531P'
     'D160H' 'R481C' 'Q247E' 'P1327A' 'X1335_splice' 'S573F' 'D812H' 'L915S'
     'C1234G' 'Q555E' 'K933N' 'A694T' 'N902S' 'X207_splice' 'T1131Qfs*6'
     'M1270T' 'I1267K' 'T741A']
    Column 'myo3a_mut' : 40 : ['0' 'E660D' 'M941L' 'N1503S' 'Y838F' 'R1378G' 'I1060V'
     'R1150Ifs*7 A1093T' 'I51N' 'R1052*' 'R1325C' 'X1092_splice' 'K1348R'
     'P1272S' 'H1096Y' 'R515*' 'M894I' 'T925M' 'M941T' 'S335F' 'K962N' 'H442N'
     'P548L' 'E1421Q' 'M493I' 'I1294V' 'R1495*' 'I610V' 'R1610Q' 'T1245I'
     'R1052Q' 'K1058Q' 'S403G' 'Y743C' 'R1548L' 'E1566A' 'R1590S' 'V1113I'
     'G535D' 'E280K']
    Column 'taf1_mut' : 40 : ['0' 'R928C' 'S439F' 'X1584_splice' 'N47S' 'S1508Y' 'R749H' 'R1030C'
     'R869H' 'E1183K' 'G33C' 'V1362A' 'S1045G' 'Q1116*' 'E1606K' 'K1235N'
     'E340K' 'P981L' 'V863M' 'Q271E' 'R1196H' 'K424R' 'P751A' 'I311=' 'C280S'
     'R1257C' 'G89W' 'H1371R' 'E507K' 'L1243I' 'S1870C' 'R877T' 'Q669H'
     'Q276L' 'C946_L947del' 'D1096H' 'V1704I' 'K832T' 'M691I' 'E141Gfs*3']
    Column 'myo1a_mut' : 41 : ['0' 'R1029H' 'A859P' 'G674D' 'R619Q' 'R643W' 'V516M' 'Q95H' 'E1009del'
     'N1010K' 'F70L' 'D521H' 'R152H' 'S1026G' 'R654W' 'A344T' 'R31C' 'K966E'
     'I41T' 'V943Gfs*12' 'R360* R504H' 'V189M' 'R760*' 'S947I' 'P75R' 'E978*'
     'R654Q' 'E102K' 'Y340C' 'E266G' 'R492H' 'L700P' 'I254T' 'Y420F' 'R360Q'
     'X366_splice' 'K132T' 'N155S' 'R985Q' 'E959=' 'K26N']
    Column 'pik3r1_mut' : 41 : ['0' 'K567_L570del' 'V357E' 'D464_R465delinsE' 'P85S' 'N711S'
     'X580_splice' 'V181I' 'T239M' 'K575Dfs*26' 'G665S' 'R649Pfs*5'
     'R577_Q579del' 'I571_L573del' 'K567_I571delinsN' 'N564D'
     'X580_splice M582Dfs*20' 'S204N' 'G376E' 'X582_splice'
     'Q579Hfs*3 L581Vfs*19' 'I133M' 'Q579Lfs*21' 'W335Gfs*5 R409Q' 'G321S'
     'S229L' 'Y6Tfs*25' 'D560delinsGQTYEQH*TN' 'V172M' 'R534P' 'L149V'
     'Y580_M582del' 'M525Ifs*7' 'F398_E411del' 'D168G'
     'R358Tfs*16 N564_T576del' 'A658P' 'L570_L581del' 'Y452_N453del'
     'K567_L570del R562Lfs*2' 'L573P']
    Column 'ctcf_mut' : 41 : ['0' 'Y25Rfs*36' 'Q72*' 'Y226C' 'R448Q' 'C271F' 'H316L' 'F228S' 'H284Q'
     'E64Nfs*10' 'G375E' 'E87*' 'K23N' 'D618Qfs*14' 'S354F' 'G403R M103V'
     'E176*' 'Y25*' 'X613_splice' 'R377H' 'H288Y' 'F379L' 'H284Y' 'D621N'
     'H546Y' 'Q267Hfs*9 F266Lfs*3' 'X256_splice' 'H373D' 'Q486*' 'H541P'
     'Q676R' 'E145Rfs*7' 'Q486P' 'H517L' 'X362_splice' 'D67E' 'E64*' 'V686D'
     'K344E' 'C557R' 'H288D']
    Column 'asxl1_mut' : 41 : ['0' 'K353N' 'Q575E' 'L1304V' 'M341I P581S' 'V807I' 'F548Kfs*11' 'K1261R'
     'P229T' 'A1320V' 'A158P' 'T130A' 'H1008L' 'D1032A' 'T854Afs*6' 'S1028L'
     'A54S' 'E480K' 'S1237F' 'D1242N' 'W1356*' 'K2R' 'R1224T' 'A316V' 'H1390Y'
     'R596W' 'K9del' 'R734S' 'T638I' 'S871L' 'M242V' 'P229L' 'S1281P' 'S1223C'
     'C687R' 'V393A' 'I552V' 'P1324Lfs*126' 'D741V' 'P1106L' 'P808H']
    Column 'fancd2_mut' : 41 : ['0' 'G1396D' 'F635L' 'L345F' 'P962S' 'T290I' 'E369Q' 'X905_splice'
     'L630P' 'K156E' 'P1311L' 'H209R' 'P727L' 'R1299C' 'T942M' 'K723Nfs*22'
     'L1186= S996I' 'S934C' 'K571N' 'V297I' 'K770R' 'X330_splice' 'S373L'
     'W1268*' 'D1286Y' 'E369Q S409L' 'P759L' 'N1083S' 'Y1267Tfs*15' 'I935L'
     'W792C' 'Y534C' 'R1370T' 'F1001L' 'N44S' 'X723_splice' 'S10P' 'V958M'
     'G1000E' 'M1238L' 'X471_splice']
    Column 'fanca_mut' : 42 : ['0' 'S1226*' 'S505A' 'I983F' 'E440G' 'I1291V' 'R163H' 'G1123R' 'R39K'
     'R1144W' 'R212G' 'E1050Q' 'S426G' 'K608= E552K' 'R714Q' 'I525L'
     'G1426Efs*13' 'Q1366R' 'P799S' 'C422Y' 'L1339Sfs*24' 'S113L' 'N1118D'
     'A1443P' 'Q153* E1420K' 'E886D' 'R1425H' 'S890N' 'F954Y' 'D1429N' 'R951Q'
     'T126R' 'D79Y' 'A152G' 'E1023D' 'H292Q' 'M1024V' 'D252N' 'R163C' 'P805S'
     'V677M' 'D598E']
    Column 'asxl2_mut' : 42 : ['0' 'S218Lfs*26' 'S1319R' 'V1277A' 'E1234K' 'P886S' 'S235Ffs*10' 'V238E'
     'V901I' 'Q592*' 'Q1385E' 'L194R' 'T979M' 'D1179N' 'R1075W' 'E351D'
     'G608E' 'R1403H' 'T12P' 'R810I' 'D298N' 'R1435W' 'E330K' 'G1324E' 'A684T'
     'Q1385*' 'R357*' 'S600L' 'T943A' 'S924P' 'A169=' 'T931S' 'K1160E' 'M438V'
     'Q1011E' 'G79E' 'X85_splice' 'T1186A' 'S253C' 'R252K' 'R357Q' 'M412V']
    Column 'adgra2_mut' : 43 : ['0' 'V614M' 'E312K' 'I522T' 'E325*' 'Q832R' 'G764V' 'Q468*' 'T683I'
     'P953L' 'L934F' 'S1334N' 'R593H' 'R362H' 'H1170Efs*4' 'L155Sfs*7' 'R369Q'
     'Y929C' 'G723D' 'A1275D' 'V772L' 'S726L' 'R600K' 'R999Q' 'Q378E'
     'S1116Lfs*150' 'C1196Y' 'R799H' 'R100C' 'G1308R' 'C1196Y R362H'
     'C1196Y L944V' 'S1276G' 'T1315I' 'P395L' 'R564K' 'P1115T' 'G705A' 'E863Q'
     'T397P' 'R143W' 'T314M' 'T122A']
    Column 'alk_mut' : 44 : ['0' 'V1185A' 'E1568K' 'S252_S260del' 'E1400D' 'T855M' 'R1181C' 'E1406Q'
     'C1097Y' 'P32L' 'L38P' 'E1434K' 'F921Gfs*16' 'E467K' 'P671L' 'G1054S'
     'V417L' 'G5R' 'P1215=' 'V349I' 'E859K' 'D626H' 'M435I' 'N1175S' 'W176*'
     'M378I' 'X472_splice' 'A3_I4insKQCKRPPPAGWEP' 'E1409D' 'E949K' 'Y276H'
     'L9P' 'Y1092C' 'V775L' 'G902A' 'T1087P' 'A876T' 'T1307P' 'P117R' 'R395H'
     'K575N' 'T1597A' 'L44R' 'Q1617*']
    Column 'apc_mut' : 44 : ['0' 'L180F' 'E1831* A1731P' 'K1821Q' 'R1146H' 'S2461L' 'R876Q' 'N1716S'
     'E1573* R1790T K1745N' 'S42C' 'T828I' 'K1739R' 'N1761T T1655A' 'A1598S'
     'A1358V' 'R2371T' 'P1467S' 'D1186Y' 'H255R' 'V452I' 'R2326*'
     'S1044L R1589C' 'R71C' 'E911Q' 'R2613K' 'E1157Q D539N R1336T' 'E2184K'
     'Q223H' 'M438T' 'T1947A' 'R88W' 'G2190V' 'G1203V' 'P2649S' 'V1605M'
     'R2228G' 'R348*' 'S2697L' 'S787N' 'S624T' 'K1245M' 'R2166Q' 'H250R'
     'R2714H']
    Column 'afdn_mut' : 45 : ['0' 'E954*' 'G457A' 'P974R' 'E1816Tfs*4' 'N901K' 'P574L' 'L990F' 'M670V'
     'R213*' 'S63Lfs*7' 'R1271H' 'R559Sfs*6' 'H764Afs*29' 'Q1308*' 'R1596H'
     'Q342Sfs*2' 'I540T' 'R511Dfs*7' 'Q1447*' 'E1130Q' 'E1818D' 'S1325F'
     'R1409W' 'R710Q' 'D310N' 'R1634C' 'A134V' 'R1612_Q1613insA' 'M1530I'
     'L967*' 'X551_splice' 'E1648*' 'X408_splice' 'Q1775*' 'C841_H842del'
     'R369S' 'Q679H' 'S1393F' 'S633P' 'A493S' 'R777Sfs*24' 'A1268S' 'R224*'
     'S753G']
    Column 'ubr5_mut' : 45 : ['0' 'X1142_splice' 'X1191_splice' 'V871E' 'S1641R' 'R946H' 'R1379W'
     'Q463*' 'F1436Lfs*4' 'R1899*' 'L2144V' 'A1046Rfs*49' 'V766E' 'V2127M'
     'R1417C' 'R1854H' 'P1035T' 'L2004F' 'S913G' 'D752Y' 'S753C' 'L120V'
     'L773F' 'A2524T' 'M1911T' 'T1400A' 'N2319S' 'V8I' 'R1900H' 'P640L'
     'K2320R' 'D16E' 'A1738S' 'P1518S' 'F1278V' 'R1898=' 'E2121A' 'D2592N'
     'D2361=' 'S2011C' 'R813Q' 'A404V' 'P1020R' 'T1065A' 'K1818R']
    Column 'setd1a_mut' : 46 : ['0' 'F1572Y' 'P707S' 'T213M' 'K1567R P392S' 'R1610W' 'V1321M' 'Y743C'
     'E1066V R1288P' 'S1013L' 'P609H' 'A1346V' 'K1569Q' 'S341F' 'T1529M'
     'P707T' 'N477S' 'D582Y' 'D1429N' 'S1048L' 'R1227Q' 'E202K' 'S301L'
     'T599M' 'R936H' 'E1364K' 'G206D' 'P607L' 'S479R' 'P1183A' 'T1122M'
     'P925T' 'A1326T' 'S765L R1390Q' 'E1007K' 'D1022N' 'S1283L' 'R1358P'
     'R1230W' 'D363N' 'G147A' 'R419Q' 'D1384N' 'S268F' 'P600L' 'S48N']
    Column 'rb1_mut' : 48 : ['0' 'E287=' 'K417Sfs*9' 'D697N' 'R828T' 'L607V' 'X701_splice' 'S182Ifs*3'
     'X840_splice' 'F426Lfs*31' 'K130Nfs*6' 'I124Rfs*6' 'I557F' 'N593Kfs*7'
     'M113I' 'X240_splice' 'K791Gfs*12 E72Q' 'D224N' 'D578Y' 'G310E' 'Y91C'
     'I196T' 'E559Afs*8' 'R73Sfs*36' 'D571N' 'T377S' 'X474_splice' 'T118S'
     'R251*' 'L797*' 'E204Gfs*8' 'V222Pfs*2' 'R876S' 'S249*' 'A160T'
     'X654_splice' 'X830_splice' 'G449Vfs*10' 'T241I' 'A490T' 'V754del'
     'P29del' 'M605I' 'R552Sfs*54' 'E268*' 'D604G' 'V128A' 'E53*']
    Column 'usp9x_mut' : 50 : ['0' 'M1478I' 'I1404Lfs*24' 'Q2436*' 'Q605Ffs*7' 'Y1953C' 'H1116R'
     'G1481A' 'S2521C' 'P44L' 'R1368Sfs*2' 'A1809Nfs*5' 'M1926I' 'Q676E'
     'N2295S' 'D122G' 'C2075Y' 'S588I P2399A' 'D2497N Q1194*' 'G1890E'
     'E1764K' 'I1467L D718Efs*16' 'D667G' 'X2325_splice' 'Q640H'
     'I126M I1239S' 'C1286*' 'A944T' 'P1105S' 'R146=' 'P2267S' 'Q1980P'
     'G2423R' 'C918G' 'L1869F' 'L1321*' 'P1484S' 'V1473I' 'I1519R' 'S1209*'
     'Q32H' 'E1856K' 'R1366K' 'V2529M' 'T327Kfs*7' 'V654L' 'S593T' 'N2095D'
     'G938S' 'H610Y']
    Column 'thsd7a_mut' : 50 : ['0' 'E672Q' 'E1282K' 'S1034L' 'T642P' 'R617T' 'N472Tfs*6' 'R448S' 'A629V'
     'C772F' 'S1522G' 'T511S' 'R1589W' 'W124R' 'P1137L' 'D166G' 'H96R'
     'S1169P' 'T720M' 'G674R' 'G335E' 'P1193S' 'Q476P' 'P1089S' 'C1158Y'
     'A662T' 'R436H Q444H' 'R269Q' 'Q460H' 'P703H' 'D779G' 'D1514N' 'V380A'
     'G64D' 'N743S' 'G731S' 'E725A' 'G149R' 'E327D' 'G322A' 'T452M' 'L766F'
     'V419A' 'T642P S1105N' 'A669V' 'X608_splice' 'F238L' 'A16V' 'R1115Q'
     'D1147V K333E']
    Column 'lamb3_mut' : 51 : ['0' 'K628N' 'Q880H' 'I516V' 'D547N' 'A590V' 'R747S' 'R552H' 'N944S'
     'L839V' 'R1135W' 'R574H' 'S1107T' 'R988Q' 'G254S' 'P304L' 'E403K' 'R366W'
     'R593W' 'P520T' 'M1141T' 'C796Y' 'R598C' 'G525A' 'V145A' 'E883K' 'G561R'
     'R1023W' 'R598H' 'A237T' 'A729S' 'P679L' 'R539Q T872N' 'R218K' 'A607T'
     'A596V' 'R878C' 'R556H' 'S719G' 'R258H' 'R972*' 'L1134R' 'S236T' 'R593Q'
     'R183C' 'M194I' 'R889W' 'R746W' 'R840Q' 'R144Q' 'R367H']
    Column 'arid1b_mut' : 51 : ['0' 'K1741N' 'E1815K' 'R2199H' 'G2207S' 'S497T' 'I1589M' 'D1728del'
     'S1222I' 'N734S' 'G1019S' 'P2171L' 'W1059C' 'G223del' 'M900I' 'V2106I'
     'E1147*' 'P488L' 'G1437S' 'A767T' 'S41F' 'Q1134*' 'E1988Q' 'A1757V'
     'R1832H' 'P787A' 'I560T' 'P1563L' 'E1049G' 'E1736K' 'L768F' 'D1914E'
     'E652D' 'R927Vfs*10' 'R1455C' 'I1776V' 'A9T' 'Q1315H' 'N138S' 'T1529M'
     'H98R' 'Q2127Kfs*5' 'A2137T' 'P1476L' 'P753L' 'S946Tfs*9' 'G1882E'
     'Q1342L' 'R1521C' 'G748S' 'I1406V']
    Column 'map2k4_mut' : 52 : ['0' 'S83*' 'W291*' 'R110*' 'I200T' 'E141Rfs*16' 'S184L' 'R304*' 'H227D'
     'R334Sfs*19' 'N234S' 'X297_splice' 'Q69*' 'T318Rfs*3' 'Y160Ifs*14'
     'S257F' 'K244Sfs*32' 'R132Efs*20' 'R228K' 'S257T' 'D197Gfs*46'
     'S292Kfs*8' 'X73_splice' 'X272_splice' 'Y113*' 'R281*' 'X363_splice'
     'G252*' 'P392L' 'I258Yfs*10' 'E221Kfs*3' 'W175*' 'X347_splice' 'R134W'
     'Q316*' 'X212_splice' 'F185Lfs*12' 'D285Y' 'X229_splice' 'G106Efs*22'
     'F48Lfs*14' 'L254P' 'X362_splice' 'Y160*' 'S339N' 'L219V'
     'X211_splice A374V' 'S280L' 'X211_splice' 'P277R' 'A3_P4insCLLYT' 'D186G']
    Column 'ep300_mut' : 52 : ['0' 'Y638C' 'P930L' 'S815C' 'X587_splice' 'G663V' 'Y751C' 'L2393V'
     'M2015I' 'T1775A T1868M' 'M289I' 'T132S' 'R1599C' 'P691R' 'M1959I'
     'Q341*' 'Q912R' '*2415Yext*30' 'N1575S' 'T845S' 'Q895R' 'E1011Q' 'M506I'
     'S2309P' 'L1600F' 'R728Q' 'E1536Q' 'P691L' 'R504W' 'G752A' 'N1126S'
     'M1942R' 'E1011K' 'A877V' 'G750D' 'P2176S' 'G2198R' 'Q2369K' 'M2170V'
     'P250R' 'R1821*' 'P802L' 'S35A' 'K1542E' 'T1533del' 'H735Q' 'I1185V'
     'G787S' 'T2045A' 'H2172Q' 'S384*' 'G269C']
    Column 'ptprd_mut' : 52 : ['0' 'R1178G' 'P519A' 'D1262N' 'S387L' 'N1673K' 'D1017N' 'G567W' 'P1530L'
     'P53T' 'T1738N' 'G1825S' 'D1353H' 'V917I' 'D201G' 'S623Y' 'S218Y' 'T998K'
     'I1260V' 'A1518T' 'L840F' 'Y751F' 'R1730Q' 'A1391T' 'R1396L'
     'V1694I P792A' 'V892I' 'A1885T' 'F1436S' 'I913V' 'T978A' 'R28Q' 'G567A'
     'E1135K' 'G920R' 'S405T' 'R733C' 'V973F' 'R1674H' 'R1151H' 'F1024S'
     'R174H' 'G1719W' 'E1639D' 'I1192V' 'E644K' 'P845S' 'N837I' 'H1195R'
     'L11delinsRF' 'D848Y' 'I951V']
    Column 'setd2_mut' : 52 : ['0' 'E397K' 'H1603R' 'Q1825H' 'H1629Y' 'L883F' 'S2080Pfs*67' 'P2393T'
     'A1617Nfs*14' 'F88Y' 'V2229G' 'R1523P' 'E1234G' 'T444M' 'Q1667*' 'S1925P'
     'R2490W' 'T2372R' 'Q1548*' 'I874T' 'R400*' 'N1684S' 'E282del' 'E1518K'
     'H1100P' 'S512* P2420A' 'P534H' 'F1626Sfs*2' 'E670K' 'T1897P' 'S681C'
     'D1342H' 'E1432G' 'D995E' 'P2057S' 'Q2174R' 'S1658*' 'I929Nfs*6' 'L600V'
     'V2233A' 'Q2290L' 'S1572=' 'D799N' 'R1523C' 'D1345V' 'Q1344R' 'S557A'
     'G287R' 'M1009T' 'C805Y' 'S112L' 'A197V']
    Column 'ros1_mut' : 53 : ['0' 'T931I' 'P2182S P2183L' 'Q911*' 'S1463R' 'R2042Q' 'F1123I' 'P937='
     'Y382H' 'Q291P' 'G1839C' 'Y419H' 'V1142I' 'G549D E290Q' 'X1285_splice'
     'Y91C' 'R2039H' 'R2126W D1450G' 'L1209*' 'R448H' 'D1988V' 'Q1091E'
     'E271K' 'R2126Q' 'C1329F' 'T1782P' 'A1443G' 'D2247V' 'A1043T' 'M1436I'
     'T2207A' 'T722M' 'G2282D' 'S79L' 'H989R' 'Q966E' 'S398*' 'G1962E'
     'T1525S' 'D331N' 'R863Hfs*25 R863Sfs*20' 'N2220I' 'Q520*' 'K945N'
     'K1026M F942L' 'N507D' 'A1907T' 'R1592G' 'R1942W' 'X1040_splice' 'N1322K'
     'L848W' 'N1211T']
    Column 'shank2_mut' : 54 : ['0' 'F104L' 'A1187V' 'K1425E' 'G194R' 'N1091Y' 'S1132F S1135F' 'G231R'
     'E407Q' 'R219H' 'E506D' 'A1350T' 'R425W' 'Y140*' 'A1261P' 'A1276T'
     'D172N' 'I193V' 'H270Y' 'Y622*' 'T162=' 'X391_splice' 'R1293G' 'S20Y'
     'P1207L' 'Q929R' 'P200A' 'V147M' 'P428L' 'K917N' 'D1186H' 'T237A' 'E287K'
     'A189S' 'E675D R574T' 'R27Q' 'V1229I' 'R73Q' 'G299R' 'R64C' 'A416V'
     'E987K' 'A34T' 'E312Q' 'D1057G' 'R111H' 'R1118Q' 'A1202T'
     'D1194N D1043H D963Y M960I E900Q D1149H D1082N E731K D642N G705V' 'A279G'
     'R3H' 'E198= R38Q' 'T446M' 'P535T']
    Column 'runx1_mut' : 64 : ['0' 'G100C' 'G278E' 'N233Kfs*340' 'X178_splice' 'L402R' 'S238Efs*335'
     'M240I' 'I315Hfs*258 P398Afs*175' 'S73F' 'R178Nfs*6 R135Pfs*15' 'C405Y'
     'L134R' 'A280Rfs*294' 'R174Pfs*12 L117Pfs*16' 'Q308Cfs*255'
     'R142Kfs*44 T219Hfs*15' 'P30L' 'T230Lfs*54' 'M25K' 'L85Q' 'R174*'
     'A122Gfs*4' 'H179Tfs*7' 'R12C' 'N126Efs*7' 'S292Nfs*277 P420Rfs*147'
     'A28Vfs*84 V105Gfs*6' 'D133_F136del' 'X242_splice' 'R206Afs*28'
     'Q308Pfs*260' 'Q235Rfs*49 P236Rfs*47' 'X143_splice' 'E196G'
     'A107_N109del' 'G282S' 'R80L' 'L71Pfs*40' 'I264Sfs*308' 'X296_splice'
     'Q186*' 'Q186Pfs*15' 'V137Cfs*49' 'A129Cfs*4' 'F326Dfs*242' 'R139G'
     'R178Kfs*8' 'L226Pfs*9' 'Q186H' 'P86L' 'Q127Hfs*7' 'R49Pfs*62' 'G42R'
     'L117Q' 'H377Pfs*196' 'Y353*' 'I264Tfs*29' 'L31Afs*8' 'T296M'
     'S342Ffs*231' 'S418Afs*149' 'G143R' 'G143V']
    Column 'nf1_mut' : 65 : ['0' 'G2334D' 'Y2285Tfs*5' 'L925*' 'G1216R' 'X751_splice' 'Q756*' 'R135G'
     'C383Lfs*13' 'L2125R' 'K1062Lfs*13' 'P927L' 'Y1678Hfs*5' 'E91*' 'P566S'
     'G631*' 'C1882*' 'X510_splice' 'V1049I' 'R1241*' 'P1358S' 'P890H'
     'X2003_splice' 'X2307_splice' 'W561Efs*3 Q2699E' 'N420S' 'P228A'
     'G312E E2447K' 'Q1399*' 'X951_splice' 'P1650S' 'Q554R' 'S575*' 'T2773I'
     'P2792=' 'A1125P' 'E2692K E291K' 'X420_splice T419A' 'S1420*' 'N45S'
     'R2083C' 'P2477A' 'L94P' 'W1952R' 'E2357*' 'Y2698*' 'D1621Y' 'Q11*'
     'R1207T' 'X69_splice' 'H1460Y' 'H1579L' 'C167Qfs*10 Q2582*' 'F1193C'
     'N1156S' 'X1526_splice E2143K' 'S2549Rfs*6' 'E2430*' 'E1720*' 'S1150*'
     'G1758V' 'V2436M' 'W1685*' 'S1100*' 'L1623P']
    Column 'cbfb_mut' : 66 : ['0' 'F44V' 'E130*' 'X55_splice' 'G121D' 'W73*' 'N63Y' 'D155Efs*11'
     'F127S' 'C107Y' 'X27_splice' 'Q45*' 'L119V' 'F153Rfs*33' 'V95E' 'Q41*'
     'I55Sfs*34' 'Y29Vfs*54' 'R35P' 'Q67H' 'X95_splice' 'R52Pfs*31 D50*'
     'N104S' 'E135K' 'P36Rfs*45' 'X56_splice' 'E39*' 'G61E' 'M101R'
     'H37Rfs*45' 'R131*' 'E54*' 'E152K' 'L138*' 'L66V' 'X176_splice' 'Q134*'
     'L97Ffs*19' 'Q117del' 'R118Kfs*17' 'F143Lfs*24' 'G51Pfs*31' 'R49Afs*40'
     'L119R' 'E126*' 'D87H R83P' 'Y29Afs*58' 'R83*' 'I102F' 'H37Qfs*52'
     'Q79Hfs*3' 'R83Pfs*34' 'G51Rfs*27' 'S72Gfs*16' 'Q133Sfs*6' 'R40H' 'E163G'
     'R90Kfs*7 R90Sfs*27' 'X94_splice' 'Q67*' 'E135V' 'A99Vfs*3' 'S72Gfs*8'
     'Y96Ifs*20' 'A56V' 'C107F']
    Column 'myh9_mut' : 66 : ['0' 'M1028I' 'X720_splice' 'R1725L' 'X164_splice' 'F643L' 'R1124C'
     'S114A' 'V577Wfs*9' 'V761D' 'K1585del' 'E1769K' 'K1793R' 'P78L' 'F426L'
     'X1520_splice' 'A1891S' 'D1273N' 'G379Vfs*4' 'A864V' 'R1770L' 'R1780G'
     'V741M' 'V1929_V1930insLS' 'S1126T' 'A363V' 'F456L' 'K940_M941insR'
     'K66N' 'P20Q' 'N470S' 'R639W' 'T1745M R1830L' 'D85Tfs*77 K79Sfs*83'
     'D507N' 'A1773T' 'N1744D' 'Q4R' 'R1226Q' 'R1268C' 'S232Y' 'R1226L'
     'G700D' 'A1692T' 'E495K G681S' 'A808S' 'A971T' 'R1342Q' 'V761Sfs*17'
     'R1912C' 'D1908Rfs*48' 'E415K' 'E1578K' 'E1535K' 'L683P' 'E1545Q'
     'A1699V' 'T1049A' 'A220V' 'Q348*' 'L1844_K1845del' 'V1285G' 'N434S'
     'L1509V' 'R1932H' 'Q466R']
    Column 'thada_mut' : 67 : ['0' 'S905F' 'S77G' 'T1032I' 'S381N' 'S1153C' 'S986T' 'D1936V' 'L1010V'
     'V1086M' 'K566E' 'I413T' 'S275N' 'W1138C' 'V637=' 'E1925K' 'G390R'
     'C1732R' 'E1809Q' 'T1085M' 'R923Q' 'Q1884R' 'F436L' 'Q1415R' 'G459R'
     'S814P' 'P842S' 'M1073I' 'S251Y' 'R987H' 'M732V' 'E1825D' 'F666L'
     'V1129M' 'Q19*' 'S1937C P1890S' 'P1294R' 'A1237S' 'H409Y' 'E1678G'
     'K1118N' 'R446L' 'S26=' 'D1081G K168R' 'P1294S' 'Y548D' 'R1250Q' 'G2V'
     'S266F' 'R987C' 'S1698P' 'H338R' 'G1405E' 'V1348I' 'S1764L' 'V1541F'
     'D405G' 'I783M' 'S77N' 'E1431Q' 'M262V' 'L739F' 'M1820I' 'E349G' 'R1905H'
     'E1825D N383S S328N' 'T1911A']
    Column 'stab2_mut' : 69 : ['0' 'R1200W' 'M1218I' 'E1388K' 'Q1922R' 'R69*' 'S2040L' 'G2018R' 'T1330N'
     'A1007T' 'T1895I' 'E984K' 'R2203C T385N' 'V1355A' 'M2385L' 'X195_splice'
     'A2139T' 'T894A' 'P237S' 'A116V' 'N629S' 'M1042V' 'D1197E' 'K1304N'
     'A1382T' 'D271E' 'V1033M' 'A1528V' 'Q1615*' 'F2387V' 'I1816M' 'V1241A'
     'T1330N G1919A T827I' 'H2457D' 'A2139T P2416R' 'S972C' 'S1450*' 'T2535M'
     'R1817Q' 'L96F' 'S529G' 'D780N' 'G2252R' 'D324E' 'R1143Q' 'C914F' 'F418L'
     'S1078Y' 'Y95S' 'C31R' 'P876A' 'P1516L' 'A1968D' 'X596_splice' 'G2491A'
     'T2456N' 'T2104M' 'P510R' 'I1705V' 'G1653S' 'T894A C222F' 'A997T' 'T894I'
     'G256E N1216Kfs*11 N335I' 'N2486K' 'M448K' 'L1616S' 'R2291Q' 'R1938W']
    Column 'col22a1_mut' : 70 : ['0' 'V80M' 'G575A' 'R74S' 'H923Y' 'Q894* A89D' 'R969W' 'P322T' 'D500H'
     'R167G' 'G774R' 'N338D' 'P715T' 'R167L' 'D381Vfs*22' 'S1355I G1246S'
     'S1284C' 'E292G' 'V519M' 'P1257L' 'P1445L' 'G1048V' 'L384P' 'G1527D'
     'D151N' 'R796*' 'P1459L R85L' 'G1210E' 'A383V' 'R785W' 'T597_G602del'
     'R352*' 'E1470K' 'D1058E' 'G1162R' 'G795A' 'D426G' 'L159P' 'P562L'
     'R1522H' 'A342T' 'P989=' 'R136C' 'G560V' 'D156E' 'D160Y' 'C436del'
     'A168T' 'R1039H' 'P1073S' 'P541A' 'M549I' 'P290L P290S' 'R362Q' 'A162T'
     'P724H' 'P512T' 'G554E' 'D686N' 'R796Q' 'L4F' 'Q1317H' 'P703Q' 'D363A'
     'D415=' 'R1365H' 'N220K' 'G1037V' 'R785=' 'M1461V']
    Column 'pten_mut' : 73 : ['0' 'K342del' 'R15S' 'N48Tfs*6' 'X70_splice' 'D92A' 'D92E' 'E235Gfs*9'
     'E299*' 'A126T' 'C136Y' 'R335*' 'X343_splice' 'L316Hfs*6' 'R130Q'
     'T277Nfs*21' 'Y27C D92H' 'Q171P' 'I300Mfs*7' 'D92N' 'Y336*' 'D24N'
     'F341Lfs*3' 'I253Yfs*45' 'R308G' 'I33del' 'Q245*' 'C136R' 'D92G' 'W111*'
     'Y16Ifs*28' 'D371N' 'K125Nfs*54 H123Qfs*10 G127Efs*7' 'G44Afs*10' 'L146*'
     'G36*' 'S10_K13del' 'K62*' 'C71F' 'V290Sfs*8' 'A86Gfs*6' 'P244Lfs*12'
     'P204Qfs*17' 'A79T' 'C304Lfs*2 V317Yfs*4' 'X267_splice' 'V317Lfs*2'
     'Y176C' 'Y76*' 'Y346D' 'Q17Ffs*8' 'Y88*' 'L220Rfs*21' 'R14S' 'A126V'
     'I122F' 'Y177*' 'S302Afs*3' 'E40*' 'I135K C71Vfs*28' 'H123L' 'D326N'
     'E242* S10Kfs*7' 'S10del' 'C105Vfs*8' 'L57*' 'C105R' 'F215_Q219del'
     'P204Qfs*17 D326Tfs*18' 'L320Ffs*25 R378Ifs*37' 'R130G' 'F243Lfs*6'
     'S370Tfs*45']
    Column 'atr_mut' : 73 : ['0' 'S129Lfs*38' 'X98_splice' 'L1903Sfs*6' 'R1929T' 'Y2046C'
     'Q555* R515L' 'E1986_P1990del' 'R2544H' 'D183H' 'D2298N' 'S860*' 'S2264L'
     'X2074_splice' 'Y2622H' 'R989C' 'T1469A' 'D2297H' 'H160R' 'R1631H' 'M82T'
     'A2253T' 'S1616A' 'X578_splice' 'H602R' 'R548K' 'R1026T' 'E91V' 'S436L'
     'A1266D' 'X878_splice' 'Q1748*' 'A823G' 'L987V' 'E969Q' 'R2459C' 'G1948R'
     'L81F' 'M197T' 'X2450_splice' 'G2398R' 'M721V' 'C1858R' 'G1847E' 'E1954K'
     'D2560N' 'H1760R' 'L2554F A1694S' 'K1320R' 'I2435V' 'T1337I' 'V157I'
     'I1753V' 'M1996T' 'Y1527C' 'S2272*' 'I219V' 'E254G' 'R1814G' 'D388H'
     'R2431G' 'H1672R' 'I1900L' 'K483N' 'D1717N' 'V1614A' 'S595L' 'I1114del'
     'R433H' 'M1175T' 'R2606Q' 'I2267V' 'R177Q']
    Column 'ncor1_mut' : 75 : ['0' 'L1463P' 'Q661*' 'S903*' 'S1562Afs*53' 'R581_R584del' 'S997C'
     'E1967Kfs*9' 'Q1602*' 'D1391*' 'I1158Nfs*35' 'I1192Lfs*52' 'T1030A'
     'V1265L' 'Q1879Ffs*22' 'Q207*' 'P1235Lfs*7' 'K469=' 'Q1384P' 'I1254M'
     'E1346Gfs*14 E1346Kfs*15' 'Q1879*' 'C811R' 'R1302*' 'R827T' 'D1956Lfs*3'
     'P1757H' 'A1972S' 'Q61*' 'E1995Q' 'T1766Vfs*76 R1762Dfs*78' 'T1968A'
     'R110C' 'E1421K' 'F436Lfs*2 V1878I' 'Q698*' 'Q1990*' 'V415G' 'S1414C'
     'R68*' 'V702I' 'R933*' 'Q1256H' 'T1766I' 'Q874H' 'V1878I' 'Q2113E S2090F'
     'L2271Hfs*5' 'M2290I' 'I253N' 'S2438G' 'X391_splice R190*' 'Y479Ifs*2'
     'S2244Qfs*49' 'V1542M' 'A1707Rfs*49' 'R1762G' 'R330W' 'K2215N' 'G1168='
     'P91L' 'P1565H' 'G1163R' 'Q120*' 'N877S' 'E2234K' 'A760P' 'E754D'
     'G2291Vfs*8' 'E249A' 'T1304Qfs*57' 'I2401T' 'S2070L' 'R564Sfs*25'
     'R1794*']
    Column 'col12a1_mut' : 76 : ['0' 'R1953H' 'T1082R' 'R265C' 'T1836M' 'T1617A' 'P2763H' 'S73L' 'R2822Q'
     'P2574H' 'V1024I' 'I1719V' 'M1933I' 'M1012T' 'D956G' 'R1834Q' 'R2905*'
     'E1555K' 'T2408M' 'T2022S' 'S1102N' 'V2286L' 'R265H R2584S' 'K1000R'
     'K636N' 'D2337N' 'M2523I' 'S2861N' 'Y2268*' 'Q2392K' 'P1818S' 'L1240V'
     'E2487Q' 'D2218H' 'F492I' 'R2938C' 'A1318T' 'D2336Y' 'V1170I' 'R1427C'
     'A592V' 'A235S' 'L1876F' 'D1623G' 'P1270L' 'L1535F' 'P2944L' 'A2240T'
     'G2027E' 'T2823R' 'E2531K' 'E2493_C2501delinsD' 'T524I' 'V1916I' 'V2350L'
     'N1538S' 'V2633A' 'E593D' 'V465D' 'T2094N' 'C2741Y' 'Y212H' 'R1924H'
     'I172T' 'E528D' 'G1383D' 'V1808M' 'V1823I' 'I248T' 'K1840M' 'L264R'
     'A2772T' 'P125Qfs*14 E122_K123del' 'G1802R' 'L2982V' 'E570K']
    Column 'notch1_mut' : 83 : ['0' 'T311A' 'Q1614_K1628del' 'N1327S' 'T1344R' 'V413M' 'V1867F' 'Q2398*'
     'T1138R' 'Q2376H' 'P1581L' 'R879Q' 'R365C' 'X1057_splice' 'G2195S'
     'P743T' 'T211A' 'G661S' 'P2128L' 'G925S' 'N280S' 'R2095C' 'G1893Afs*88'
     'C1068Y' 'V1112I' 'V1792M' 'P2514Rfs*4' 'N787H' 'R1438H'
     'R1598_V1599insA' 'P1731L' 'T701N' 'V1739M' 'L1199F' 'H1190P' 'N816D'
     'G275Afs*21' 'A2463T' 'G690R' 'P1862L P1566S' 'L2464Cfs*13' 'A2044T'
     'A1471V' 'R2327W' 'G1072S' 'E564K' 'R1107Q' 'C817G' 'S1651L'
     'P1390H E1382K' 'E1636K' 'V2536I' 'G546R' 'Q2440*' 'Q2405Rfs*17' 'L2457V'
     'T701P' 'Y813H' 'T822=' 'I430M' 'A834G' 'V2249M' 'P1530L' 'T123M'
     'X2028_splice A1943S' 'L1424S' 'W1813L' 'R2087W' 'A624T' 'G2243S'
     'H2428Qfs*77 H2428Pfs*79' 'T1344M' 'G736R' 'R176Q' 'E2515* V1721G'
     'R1598P Q2416Hfs*6' 'D1223Y' 'G2420C' 'R207H' 'S1004L'
     'G1034_G1039del Q2386R' 'A2077T' 'N1482D']
    Column 'ncor2_mut' : 83 : ['0' 'K2124Rfs*14' 'E2096*' 'E2048K' 'S456*' 'G2089S' 'R1317G' 'A688V'
     'R1583*' 'T1820Hfs*201' 'R986W' 'A723V' 'A1725T' 'E865Afs*98' 'E1431K'
     'R1434Q' 'S1838del' 'G555E' 'L112V' 'Q1870Rfs*11' 'S708L' 'P2115L'
     'H1876Y' 'Y1280C' 'H1231=' 'P1404L' 'R1847C S1970F' 'E1438K' 'R2244W'
     'Q968_R969insS' 'R1716C' 'P2018L' 'S1838_G1839insAAS' 'E381D' 'R514C'
     'R109W' 'S554*' 'P1105L' 'G576E R1810Q' 'E1448K' 'P1995H' 'L1371Cfs*8'
     'A1502V' 'I410V' 'H1696Q' 'E871K' 'R581C' 'R1863G' 'R1810W' 'V1268I'
     'E2138=' 'G1185A' 'A847T' 'Q507* L1476Sfs*17' 'S1976L' 'R344H' 'Y91C'
     'G1382D' 'I316T' 'R1254C' 'G2318E' 'E434K' 'T33M' 'R1947W' 'S1575Rfs*11'
     'R2036H' 'N2336I' 'A366T' 'R1020Q R2439Q' 'P2225L' 'R2235W' 'S864T'
     'D1495N' 'A605V' 'A847V' 'T803P E830del' 'R2175C' 'P122S'
     'P957_Q958insHP' 'T35M' 'P2105L' 'R2244Q' 'T1891M']
    Column 'col6a3_mut' : 87 : ['0' 'X633_splice' 'R1301Q' 'A978T' 'F2794V' 'A259V' 'K2272Q' 'E1130K'
     'L1213V' 'R677L' 'S989P' 'S1126C' 'L2624V' 'G2419S' 'V221M' 'R1210C'
     'S1846P' 'E1804K' 'A763D' 'D1350N' 'P2051T' 'M1820L' 'S715L' 'A2714S'
     'R935Q G2258D' 'R659C' 'V142F' 'R1149W' 'R1252C' 'P623S' 'G85R'
     'P623S I2642L' 'G2254E' 'T686P' 'A2787T' 'R2734Q' 'T910M' 'P568L' 'D410N'
     'P2088L' 'V1945L' 'R1915Q' 'A919V' 'E690K' 'R1535H' 'V2468I' 'P744L'
     'F603S' 'G714C' 'R1727Q' 'E1912K' 'V1251I' 'V1924I' 'V743M' 'D2022='
     'G2297R' 'D156Y' 'R1990W' 'R935Q' 'V1799M' 'M1992T' 'T2878A' 'R2061*'
     'R1331H' 'S1870N' 'T1140M' 'R2135G' 'D1555N' 'R2993H' 'M1820* C1825Pfs*5'
     'R2459W' 'P1021Q' 'A1502T' 'R659C F377L' 'I2719V' 'N654S' 'S3073G'
     'L624I' 'T2940M' 'E1899G' 'F1284L' 'P1218L' 'G1842V' 'I353V' 'D2617N'
     'E2072G' 'P1104L']
    Column 'lama2_mut' : 87 : ['0' 'X343_splice' 'C309W' 'E1141K' 'R2383Q' 'D2274E' 'X698_splice'
     'P579L' 'G1518C' 'R239H' 'E2756K' 'Q946H' 'Q1421*' 'G2800S' 'R499H'
     'R1588C' 'I2499T' 'Q2043R' 'D1446N' 'I2355Sfs*32' 'F2956L' 'R2231C'
     'R1499W' 'R998H' 'V1537M' 'V3066A' 'P783T' 'D2419A' 'E120K' 'I2092N'
     'Y711C' 'A2093T' 'G2941R' 'G333E' 'T2223S' 'P228R' 'N1080S' 'L1776Tfs*3'
     'T731I' 'C951F' 'G2472C' 'D1222G' 'Y240H' 'R1029Q' 'S927A' 'L1685F'
     'I3088V' 'I2684M' 'K1158R' 'T394I' 'N1801H' 'V1572=' 'Q131L' 'H1994N'
     'W739C' 'I1853R' 'E308K' 'A5T' 'P223T' 'R2383Q A2077T' 'T1495M' 'R2786H'
     'T2269M' 'C1548R' 'I1210V' 'P2823S' 'C416*' 'E1567Q' 'A763V' 'T2973K'
     'T2019I' 'G1056C' 'R2231H R1976W' 'D173N' 'D559Y' 'A293S' 'R1450Q'
     'N816=' 'P1232H' 'R1566H' 'D516E' 'L1907P' 'T780I' 'D3013A' 'P2359S'
     'R185C' 'G1824S T546I']
    Column 'arid1a_mut' : 90 : ['0' 'T1359Yfs*85' 'V1464D' 'P194L' 'Q611*' 'E2250Vfs*18' 'Q1403*'
     'E896* E1683* G838E E1019K K1021N' 'Q1142*' 'M1661V' 'Q1330*'
     'L2281Ffs*104' 'A2167Gfs*35' 'P773L N201K' 'Q1493*' 'Q1420*'
     'G1063Wfs*42' 'Q393*' 'P1583A' 'L1831V' 'Y1096H' 'Q1655*' 'A1136Rfs*25'
     'R1879Q' 'Q761*' 'K2146Nfs*54' 'R1980H' 'P533A' 'Q732*' 'K2045*'
     'P1468Lfs*13' 'Q1212*' 'P208L' 'Q944*' 'S1390G' 'P533S' 'T1359S' 'T1703N'
     'N1308S' 'T653R' 'Q507* K2025N' 'Q268*' 'S735N' 'R1869Q' 'Q492* E1774G'
     'R1287Kfs*11' 'Q1741*' 'G784V' 'Q31del' 'R1869W' 'Q268* S264L'
     'T1690Nfs*8' 'T1892I' 'V1526M' 'G1210R' 'L2238*' 'R2236Pfs*35'
     'T1666Cfs*15' 'Q501*' 'R1551H' 'M1224Cfs*13' 'A438V' 'N874S' 'Q520Sfs*99'
     'A183T' 'N935S' 'S186delinsRR' 'R1845Q'
     'Q1519* S2179Gfs*44 A2182_A2186del' 'L2241*' 'S1184* S1936Afs*20' 'Q515*'
     'P1163Nfs*29 K1161del' 'A2237V' 'P912L' 'D1286Gfs*13' 'K1928* S2113F'
     'Y1281C' 'Q505L' 'A1927P' 'R1593W' 'S1126F' 'Y212*' 'S958* X960_splice'
     'V161_A162insR' 'N2220S' 'M1673Ifs*16' 'V2041A' 'A900T' 'Y1572*']
    Column 'utrn_mut' : 91 : ['0' 'R2870Q' 'Q1853H' 'K3134_N3135insEQVQ' 'E3239Q' 'L1950F' 'M483L'
     'K3253T' 'L1778F' 'R3021H' 'W2561C' 'T546I A2472D' 'E421K' 'R2475Q'
     'E3075*' 'P2030S' 'A745T' 'S1722G' 'N553T' 'S145L' 'T164S' 'V1532G'
     'A2705T' 'K1598Ifs*13' 'D2997N' 'V235I' 'V2468A' 'Q2836H' 'P1941H'
     'L1073V' 'S3428Afs*17' 'X1422_splice' 'V776F' 'I284T' 'L2152V' 'I1113='
     'A2437T' 'D1024N A2875T' 'I529T' 'S607C D2001H' 'R2859C S1486*'
     'X2737_splice' 'T2416N' 'I754M' 'A1530T' 'E3124K' 'K1791R' 'E1679Kfs*12'
     'V1460I' 'T3308M' 'Y2943C' 'K2782E' 'D2275N' 'N611S' 'L2362F' 'D651G'
     'R3003Q' 'R2064C' 'C2602R' 'V2043G' 'G1969D T1870I' 'E670K' 'E726K'
     'D200E' 'R2859C' 'E2095D' 'K1930E' 'T1565I' 'R2443G' 'S1904C' 'K1430N'
     'E519Q' 'E320K' 'L576F' 'V2324I' 'D1462A' 'X3424_splice' 'K2400N' 'G118E'
     'Y3177C' 'D2579E' 'E518Q' 'R414=' 'T220S' 'N847D' 'R2607W' 'T2444M'
     'E421V' 'T2945A' 'R1718C' 'Q1990E']
    Column 'tbx3_mut' : 98 : ['0' 'K164I' 'N212del K293del' 'Y605Tfs*27' 'D326H' 'L209Pfs*33'
     'L81Wfs*7' 'F219Ifs*8' 'A612Lfs*16' 'W197*' 'N258Lfs*2' 'G361Rfs*14'
     'R436Tfs*3' 'S641N' 'W113* W113R' 'W113R' 'L207Tfs*18' 'Q568*' 'K118*'
     'H492Rfs*134' 'E195Nfs*13' 'L731Sfs*156 E402Dfs*230 C404Afs*228'
     'L368Ffs*7' 'D114Efs*27' 'A567Mfs*131' 'G500Lfs*133' 'H205Lfs*29 N211T'
     'K288=' 'N212del' 'F325Vfs*2' 'E384Q' 'F299Lfs*24 S31Rfs*79' 'G689D'
     'G120Afs*19' 'S707Rfs*177' 'G194Wfs*33' 'Y163*' 'Q495*' 'Y149Ffs*3'
     'D154V' 'R454H' 'T210Nfs*17' 'D295del' 'H626Q'
     'S266Nfs*11 L81Gfs*26 Y265Ifs*17' 'Q524*' 'S371I' 'F325Mfs*35'
     'G361Wfs*14' 'A418T' 'D367fs S244del' 'S589P' 'T121Pfs*13 E378Rfs*29'
     'N49Tfs*39 Y271Cfs*10' 'N308Mfs*15' 'Q590* N297del' 'L368*' 'N211T'
     'K182Efs*44 N296D' 'A59V' 'P264Lfs*18' 'G515E' 'L263Nfs*20' 'L263Pfs*3'
     'E179K' 'X219_splice' 'Q316Hfs*7 L317Rfs*8' 'A562V' 'D295N' 'V33L'
     'X591_splice' 'K288Rfs*2' 'L209H' 'S214*' 'E195*' 'F136Ifs*2'
     'E383Rfs*249' 'D287N' 'S615A' 'E327Afs*35' 'A562Dfs*71 S244F' 'H437R'
     'G509D' 'A192Rfs*35 F204Sfs*4' 'L112F' 'A411G' 'N308Kfs*19' 'F278I'
     'Y603Lfs*87 P602Lfs*89' 'K182Efs*44' 'N296D' 'G75Sfs*12' 'A192T' 'D367N'
     'Y284C' 'I724Gfs*163 L721P' 'L272Ffs*11' 'H437Qfs*2 H581Tfs*51']
    Column 'pde4dip_mut' : 100 : ['0' 'E1850A' 'A669T' 'E252Gfs*11' 'R1531W' 'Q249R' 'R1282Q' 'L2280V'
     'T232I' 'S1040F' 'H964Y E1058K' 'R1912Q' 'S2023Pfs*5' 'V1241I' 'R571H'
     'L467F' 'N530S' 'N2091K' 'R1380Q' 'A2303D' 'T1680P' 'T1184A' 'S1770R'
     'T831S' 'R2277G' 'A1324S' 'N440S' 'D2033Y' 'E658G' 'Q448R' 'Q1219R'
     'A942V' 'D517E' 'A1535T' 'M1006V' 'R2117Q' 'L353F' 'X2318_splice'
     'E1670K' 'Q1785H' 'A2328T' 'R460* A39T R1343W' 'F496V' 'R47Q' 'E2232D'
     'M2121I' 'T1839= R2117Q' 'G1495E' 'S2213R' 'V1124A' 'S1648P' 'P1395S'
     'L1516P' 'Q573P R1378Q' 'E38Q' 'L2250F' 'Q1003R' 'G750A' 'G1725A'
     'S1606P' 'E18del' 'P1685R' 'Q584*' 'P1720S' 'L290V' 'P607L' 'E769G K373R'
     'H441Y' 'D1416N' 'M2121V' 'H588R' 'S1885C' 'E563G' 'L2325*' 'A312E'
     'S2249F' 'A2328V' 'S1283T' 'K17R' 'E503G' 'D2118Y' 'S2045R' 'S1237L'
     'M1306V' 'L1501V' 'T1839=' 'E1024K' 'R419L' 'R478H' 'A2146G' 'R516Q'
     'A1057V' 'Q2306*' 'R460Q' 'Y164Lfs*3' 'S1127I' 'P993L' 'R2145T' 'A1916S'
     'K1507_T1509del']
    Column 'birc6_mut' : 102 : ['0' 'A432Tfs*14' 'S295L' 'D3134H S490C' 'V926L' 'G661V' 'N2757S' 'G4833D'
     'V1047I' 'R3872T' 'T3128N' 'G1603R' 'Q2016* S3650*' 'T2864A'
     'X420_splice' 'S2476C' 'N3598T' 'R1581G' 'L4327V' 'L3532V' 'P2047L'
     'R3934C' 'L3525R' 'E187G' 'G1865R' 'I4744M' 'L3166=' 'F3717L' 'T3128S'
     'P1671H' 'R88H' 'S3044G' 'P4812S' 'E3273K' 'L4797V' 'V904I' 'P1707T'
     'S1370P' 'V709Cfs*33' 'E499D' 'R835W' 'P1773L' 'I1817V' 'V1716G' 'E975A'
     'C3476R' 'M2411V' 'I3212V' 'M3250V' 'S4151T' 'R1037W' 'S3469G' 'V4764F'
     'M4560I' 'Q3997L' 'H2868Y' 'R2291H' 'S1399N' 'E3898K Q2974E' 'I2261M'
     'N1746S' 'S1413R' 'P628L' 'A2597T' 'Q908*' 'V4098E' 'S3656L' 'V333I'
     'C3371R' 'P4271L' 'R1406Q L1025V' 'R4218C' 'Q2455*' 'P4016A' 'S393L'
     'G1231E' 'I3653N' 'K408N' 'R267L' 'Q1064*' 'N1868I' 'S3652N' 'S4494I'
     'V2960L' 'P4683S' 'R1398Q' 'D307E' 'R4000C' 'G1256V' 'A1664_A1666del'
     'A4830G' 'E4835Q' 'E4030G' 'R267H' 'L745V' 'R1406*' 'H1881Y' 'T2551M'
     'H226Y' 'H3574Q' 'H3161Y' 'N2532S']
    Column 'tg_mut' : 104 : ['0' 'F2321Y' 'L1230P' 'G77S' 'R88W' 'R1270H' 'R1952Q' 'N1349I' 'D1838G'
     'V1618M' 'E645Q' 'D1672G' 'Q503*' 'R912W' 'G550D' 'F935Vfs*3' 'L603V'
     'A993T' 'W1553C' 'R964W' 'D1385E' 'R2044L' 'Q331H' 'M346T' 'T411M'
     'D1401Y' 'I2722V' 'R1398H' 'I166T' 'P1969L' 'C1473S' 'R152H' 'H583R'
     'Q2244E R740G' 'D1513Y' 'K2649N' 'V73M' 'R1081Q' 'V1664M' 'P612T'
     'N2706S' 'A1308V' 'T1621M' 'E1373Q' 'R1967C Q2033*' 'G767R' 'R1283L'
     'H1509=' 'T1238K' 'G1736S' 'R2173Q' 'S913T' 'V591M' 'L1894F' 'E442G'
     'L1604F E2179Q' 'R1371Q P1278S' 'E1054D' 'E2038K' 'T798A' 'Q2629*'
     'G1670S' 'E940A' 'D2001N' 'Q2266R' 'P1623R' 'R1530Q' 'R1691C' 'A1583T'
     'G1269R' 'G2618S' 'E2550K' 'V2502I' 'T728M' 'S2311R' 'T716P' 'G634R'
     'R1423C' 'W637L' 'S2311G' 'R1829W' 'W1050L' 'S887I' 'S2723L'
     'A2180_T2181insHP' 'L2090P' 'A1209T' 'G1138R' 'E1133K' 'L2488F' 'A2296T'
     'C1459=' 'X1606_splice' 'Q1069E' 'A1311V' 'F693L' 'G77S C1473*' 'G815E'
     'P1106S' 'H2486L' 'S18L' 'L2547Q' 'K441E' 'A2401V']
    Column 'herc2_mut' : 109 : ['0' 'E3449K' 'D3456_I3457del' 'S4677C R3161K' 'E1206K' 'T1098M' 'W36C'
     'R4427Q' 'M4189L' 'S810G' 'V3064_G3066del' 'V3724L' 'K17T' 'P1159S'
     'R1438C' 'R3882H' 'R3906C' 'E384K' 'Y1485C' 'S1318L' 'H355L' 'H4640R'
     'I4799V' 'Q2245L' 'K1605I' 'L1805Q' 'L3946F' 'H361=' 'N4553T'
     'G1870R A4807T' 'K761R' 'L98P' 'A3506P' 'S3487L' 'A2536T' 'V3314Rfs*46'
     'V3303M' 'V1828A' 'V3667L' 'D1909N' 'H270Y' 'E2467Q' 'I2944V' 'R2126C'
     'I2679V' 'I4091T' 'K2737Q' 'P3419L' 'R402H' 'P410L' 'R4293Q' 'D4267E'
     'G279Efs*25' 'Q1952P' 'P3708A' 'S3475F' 'K1849R' 'K1220N' 'A1799T'
     'L1346Cfs*60' 'T2232A' 'R2151C X483_splice' 'G2676A' 'S2694L' 'K3382N'
     'Q4744=' 'N478D' 'S2940R' 'D108H' 'S2471P' 'N4287S' 'N1682S' 'S2506P'
     'V3013L' 'T2873I V3661I' 'M3144T E3858K R1202K' 'S4233T' 'I3790V' 'L208V'
     'S2637del' 'A4253T' 'A915dup' 'H982R' 'M2777V' 'R3313H' 'L4132Q D2194Y'
     'S4372L' 'I91L' 'T405M' 'A2757V' 'R2218C' 'V4409I' 'N4553T G4300S'
     'R4412G' 'F1238L' 'A335T H4640R' 'M2053I' 'P90A' 'A3571V' 'A947G' 'D631G'
     'R4422H' 'D2901N' 'V2982L' 'V2795*' 'T3331M' 'S2481F H361= L1346Cfs*60'
     'T4672M' 'P1888S']
    Column 'akap9_mut' : 109 : ['0' 'W3655C' 'D2313N' 'Q3375K' 'E1342Q' 'E1550K' 'Y3814F' 'I1453V'
     'N3207S' 'E2849K' 'E1702K E1702V' 'S1028N' 'K3704R' 'E1051*' 'Q1397R'
     'R3742W' 'I826V' 'M2065I' 'S144C' 'I1643L' 'Q3894H' 'L2543P' 'G1043S'
     'A1454T' 'D3871N' 'L264P' 'Q2591H' 'N3256K' 'E932K' 'E3188G' 'S982C'
     'P2098S' 'N3757S' 'L1384* S2707_A2712del' 'D3372E' 'S3328Gfs*19'
     'I2287Yfs*6' 'K1157E' 'E888K' 'I2455V' 'L1270F' 'T1683M' 'V183I R182S'
     'R1463K' 'E147D' 'G2912E' 'A2552S E744K' 'C1144R' 'E2004D' 'L1529S Q215R'
     'S915Cfs*3 K911Vfs*11' 'R3712Q' 'E744Q' 'E332A' 'D204N' 'P2887R' 'I445T'
     'S1376T' 'E3500K' 'D1706G' 'X3536_splice' 'L1260P' 'V2629A'
     'M2002I M225I' 'E1820D' 'A1909T' 'G3744W' 'C870Y' 'S540*' 'L3408I'
     'R466Q' 'V3412A' 'L1953del' 'S1641F' 'R3783Q' 'Q2730R' 'X2944_splice'
     'M3612T' 'S816P' 'R3294Q' 'V1319I' 'R3038C' 'M3743I' 'N375T' 'H3695Y'
     'I3126T R3787Q' 'P2581S' 'R1110T' 'T3315A' 'I2038V' 'M2231T' 'S1812*'
     'V1449E' 'K563M' 'K386N' 'E744K' 'D1711H' 'K2201N' 'D2893H' 'R3233H'
     'E2403G' 'E3008K' 'E1236D' 'I331T' 'T938A' 'I107V' 'Q2093*' 'Q1351R'
     'F3857L']
    Column 'dnah5_mut' : 125 : ['0' 'G2021R' 'R4592*' 'L4454R' 'Y4536C' 'T2695S' 'S1661Y'
     'S180Tfs*16 E2410Q' 'R4127C' 'R827C' 'L3291S' 'E3509K' 'E3293A'
     'V1048Gfs*7' 'A1258S' 'T924N' 'C3063*' 'V1038M' 'N2673D' 'E4516D'
     'A3884S' 'E1756G' 'N2673S' 'E2758A' 'G2364A' 'L123F' 'M4245T' 'P2552L'
     'Q3005*' 'R2511W' 'M2106V' 'E2288K' 'N1105K' 'P1603T' 'S2062Y' 'R4071H'
     'T3346A' 'A1212G' 'H1343Y' 'F4392C' 'C1453F' 'Y4259H' 'D4594N' 'R1995*'
     'R3000Q' 'A4125V' 'R827H' 'S321L' 'I4115V' 'R1961=' 'R3909*' 'L3826F'
     'S1721*' 'E1813G' 'X2230_splice S1879C' 'K657R' 'D506H' 'E1887G'
     'P3571_T3572insLL' 'H4123Y' 'S2050A' 'L572W' 'P135A' 'Q2112Lfs*10'
     'R3197Q' 'R2946H R1805C' 'N1005Y' 'D3136A' 'A3251P' 'E3549G' 'D586Y'
     'V209I' 'S906T' 'V3030F' 'F1851S' 'L364=' 'F2077S'
     'A4012S X4012_splice X4012_splice' 'K3119E' 'D356E' 'N3985S' 'T2270N'
     'N1420D' 'S2809L D1852N I1758M' 'D3134N' 'I518T' 'A2278T' 'R3620Q'
     'D995G' 'T1875M' 'L4404F' 'R3553W' 'R3077L' 'I2830T' 'D1029V' 'G4542D'
     'S3861R' 'S13N' 'M3347I' 'M2706T E1266K' 'M555V' 'M507T' 'I4V' 'T133S'
     'V1274A' 'R2509H' 'E1278D' 'T417S P1361R' 'N1784H' 'N422T' 'K4558E'
     'L628V' 'G2710S' 'Y3600C P1603T' 'Y2917C E1083V' 'G4455D'
     'T3410M R994W E1083V' 'R2183H' 'H2380D' 'Y3133*' 'E3376A' 'T238M I4117V'
     'K1060M' 'R2416H' 'Q2577E Q1374E']
    Column 'gata3_mut' : 128 : ['0' 'A318T' 'S413Qfs*94' 'S407Afs*99' 'X308_splice' 'M356*' 'K358E'
     'X349_splice' '*444Lfs*63' 'N331Efs*21' 'R352*' 'V439Sfs*36 T440_A441del'
     'R329Efs*23' 'Y345*' 'C317Dfs*30' 'W328Efs*23' 'T355Dfs*16' 'Y345Tfs*10'
     'N319Efs*33' 'X350_splice' 'S212A' 'K358del' 'N351Tfs*4' 'R329Kfs*23'
     'H200Y' 'H399Qfs*108' 'S437Kfs*40' 'R364G' 'L327Tfs*28' 'P425Afs*60'
     'Y344*' 'L354Rfs*47 K358Pfs*9' 'S401Yfs*101' 'T315S' 'S381Ffs*12'
     'E359Afs*44' 'X308_splice R329Gfs*26' 'F430Lfs*77' 'S401Vfs*106' 'Y344C'
     'N331Ifs*21' 'E262V' 'M293K' 'L396Pfs*117' 'D160E' 'A332Qfs*19'
     'K302Sfs*53' 'P425Afs*82' 'L347R' 'P408Lfs*98' 'G431Wfs*76' 'R366Pfs*5'
     'M438Nfs*38' 'F409Lfs*98' 'N331Kfs*40' 'N392Rfs*112' 'M293K M293I'
     'G431Lfs*45' 'D335Gfs*21' 'N351Kfs*10' 'L354Dfs*16' 'M368Ifs*2'
     'M400Vfs*106' 'R352Kfs*19' 'P432Tfs*75' 'W328Lfs*25' 'R329Gfs*17'
     'S407Lfs*98' 'L428Vfs*78' 'T315Rfs*40' 'M293R' 'L343Afs*9' 'S369Rfs*3'
     'X260_splice' 'E359*' 'L354*' 'H15del' 'Y344Lfs*9' 'H434Rfs*66' 'R364K'
     'D335Gfs*17' 'P77Yfs*227' 'P408Afs*99' 'Y290Ffs*5' 'N319Lfs*32' 'R366Q'
     'N331Cfs*20' 'W328Lfs*29' 'P191L' 'K357N' 'P353_L354insPDYEEGRHPD'
     'H423Afs*67' 'H434Pfs*73' 'I122Sfs*73' 'A395Vfs*106' 'A332Dfs*20' 'M356T'
     'V337Cfs*15' 'M356V' 'M293K R305L' 'V132Rfs*171' 'R366G' 'G431Wfs*46'
     'F409Sfs*7 P408Sfs*8' 'G360Dfs*8' 'H433Nfs*43' 'W328*' 'L347Afs*5'
     'K358R' 'N351Kfs*19' 'K181Rfs*121' 'C85Y' 'T355A' 'R364T D160E'
     'S426Ifs*81' 'G360Rfs*11' 'S404Afs*99' 'T420M' 'G242S' 'A441Rfs*66'
     'S426Pfs*79' 'A395Rfs*120' 'H348Sfs*4' 'Y290Lfs*14' 'R305P' 'Q56*'
     'M356Lfs*35' 'S404Kfs*104 L94Pfs*117']
    Column 'dnah2_mut' : 129 : ['0' 'V2429I' 'A2327T' 'V2429F' 'R2334Q' 'R837C R2793Q' 'G1266R' 'S3826P'
     'N1201Kfs*45' 'I475T' 'R4056C' 'T1263M' 'R3278Q' 'C4383S' 'R3676H'
     'D3184Afs*34' 'D1971E' 'P169L' 'D3355N' 'R556H' 'R1912C' 'Y4386*' 'H920R'
     'V928G' 'M2389V' 'V3522A' 'S905Cfs*7' 'A3562V' 'T2822N' 'R2503H' 'I3395M'
     'I1862T' 'C411F' 'K1424R' 'D2826del' 'R2773C' 'R2077C' 'D4131Y' 'R2255C'
     'R1486T' 'L3880F H4114Y' 'P1552S' 'E152D' 'T2423I' 'E2663Q' 'A322V'
     'S4380C' 'G4340V' 'I325M' 'G165S' 'W1240C' 'R1197P' 'K510* T471S'
     'K1276R' 'V2581M' 'T2060R' 'E233G' 'T219K' 'S1898T' 'D2160V' 'D829G'
     'Y1960Lfs*14' 'V2462I' 'N1176H V3670I' 'W2917R' 'R1320W' 'R1040K'
     'N1488K' 'R3527Q' 'R3482H' 'X2900_splice' 'K405R' 'R3461*' 'V661I'
     'I2879T' 'P39L' 'A3877T E1724*' 'R1978H' 'D2671G' 'Q2861H D1084N' 'Y807C'
     'K1684del' 'I4043S' 'R3834G' 'I686Mfs*34' 'Y4171C R2564H' 'E3680K'
     'D327=' 'K3363N P1467T' 'E3016D' 'G2535W' 'R1673Q' 'R254W'
     'V4261M I3616M' 'R963W' 'C1949W' 'X3412_splice' 'R2523*' 'S3826='
     'F3317C' 'A2107T' 'R837C' 'E2370Q' 'D813Y' 'R3527Q Q2069E' 'R2749W'
     'R24W' 'R3834*' 'I2763T' 'N4301=' 'I1709T' 'K2688R' 'R2803H' 'I3416T'
     'L1833P' 'R530W' 'Q1517H' 'T1263M T728M' 'V3620M' 'P78H' 'R3465W'
     'R1046C' 'E4156D' 'H716P' 'F1334Y' 'M3858V' 'I1095T' 'Y3765H' 'R3923C']
    Column 'kmt2d_mut' : 129 : ['0' 'Q4118H' 'L1094V' 'Q3793*' 'S4414T' 'R2072C' 'R4229W' 'Q773R'
     'G4427A' 'G1811V' 'A4965T' 'V2338I' 'H350Q' 'R3536H' 'E1136D' 'R4238H'
     'Q2170E' 'T2571I A2713V' 'P3671A' 'Q3939E' 'A3318T' 'A4594P' 'P2193L'
     'T2137P' 'R65H' 'A2583D' 'E1254K' 'P4283R' 'P3794S' 'G4278V'
     'I5232V Q4165R' 'D1552A' 'A2620T' 'R1313Q' 'Q3905L' 'A5187T' 'R5120H'
     'S3614T S3614L' 'P702S' 'P271R' 'Q1583*' 'A4496S' 'Q3724_Q3725insCS'
     'Q3783E' 'K3140Rfs*2' 'A222V' 'R487W' 'L4715F' 'G1725R' 'P790A' 'Q4228E'
     'P647T' 'A2657V' 'H3361R' 'V1792I' 'Q791* E1254K M1575I' 'E739A' 'P4520L'
     'S1901C' 'F2566L' 'D2769N' 'P2781L' 'G1235C' 'R5533Q' 'C1024R' 'S4297P'
     'R2041C' 'F2536S' 'Q4315R' 'F2837S' 'P4186L' 'R2789W' 'R2217C N2254K'
     'P2108L' 'Q3899K' 'X1928_splice' 'A3615T' 'R4288Q' 'T1974M' 'R2687*'
     'G4146W' 'P3490L' 'R845Q' 'G1622A' 'S2795F' 'G2492E' 'T944I' 'R2535C'
     'P634S' 'V1670I' 'A2713T' 'P2753A' 'S2342_P2343insRA' 'P638R'
     'P2896Lfs*14 S753C' 'R2235K' 'P2145L' 'V4934A' 'P3116S' 'H4132D' 'R2001L'
     'P4175Q' 'R2860H P469L' 'E1080Q' 'Y5206*' 'S1401_C1403del' 'P1964L'
     'A4708S' 'I5168V' 'M1166V' 'V5184L' 'P750L' 'P710R' 'P665L' 'I5424M'
     'P4346S' 'T3188M' 'S337L' 'Q3271H' 'G2213D' 'G3710R' 'N2517S' 'L3566R'
     'E1813K' 'N3067S' 'A2983S P2775S' 'M2833L' 'T1246M' 'P2931A']
    Column 'ryr2_mut' : 132 : ['0' 'E4434*' 'H630Y' 'R2920*' 'L2218F' 'P4409A' 'R2530T' 'P3652S'
     'S1155T' 'G1696C' 'V1579M' 'G1015R' 'I2396T' 'R1699C' 'R1585C' 'R1303H'
     'T1737S' 'P1857L' 'S1295G' 'L3362P' 'I4197M' 'A4216S' 'T1107M' 'S2814F'
     'T4113S' 'A2334S' 'G1324A' 'R3567H' 'R2267H' 'E701K' 'L1630F' 'E2790*'
     'V4768I' 'R1089C' 'A522S' 'A3330V' 'R2198H' 'H3572N' 'R1119H'
     'P1323T T3098A' 'V3219M' 'M4923L' 'H2819Y' 'E243K' 'G786V' 'X3853_splice'
     'S1429*' 'T858M' 'S3437*' 'G2310W' 'R3190Q' 'E3504K' 'V342A' 'G1696D'
     'R2803Q' 'I784M' 'G2284S' 'Q2692P' 'R272C T2116A' 'T1399K Y4250C'
     'N1551S' 'T1863M' 'R2424K' 'K103M' 'R3458Q' 'T2504M' 'L1334V' 'E3709K'
     'R1392K' 'R2979C' 'E3625G' 'T1276I' 'D4374E' 'X3646_splice' 'K4223del'
     'R485W' 'I1432L' 'R1500C' 'S268Y' 'Q859E' 'E4123K D1454N Q3855*' 'V873M'
     'T1228N' 'F1553L' 'G1116D L2218H' 'G1497R' 'R3510H' 'L722F' 'A4203V'
     'H956Y' 'A3490S' 'R3227H' 'R1100W' 'P1624T C2572G' 'A2632V' 'X563_splice'
     'A3194S' 'I1480M' 'S1638T' 'S4526del' 'N2517S' 'E4912D' 'S1967L' 'V2154L'
     'A1365V' 'Y819H' 'L3137F' 'N3865Y' 'V3148M Q4638E' 'R3397C' 'A4051V'
     'E4064D' 'W526R' 'E879Q' 'G3225S' 'I1822M' 'R1482H' 'S1678N' 'T25Rfs*69'
     'S1402F' 'H464Q' 'C2559F' 'M895T' 'L4026F' 'N658S' 'H956_E958del'
     'P1580S' 'E2415D' 'E899*' 'N2386K' 'R2931C' 'S3592F P3579S']
    Column 'ush2a_mut' : 134 : ['0' 'P196S' 'D3333G' 'G4838R' 'D112G' 'P1145Q' 'X2109_splice'
     'X1663_splice' 'S1457L' 'E404K' 'P1060H' 'H2160D' 'X2219_splice' 'A4153V'
     'R3626T' 'C3295Y' 'L1989V' 'Q1914*' 'R1962T' 'H1728Y S5189*' 'D2942N'
     'R1578C' 'R3999H' 'W1084C' 'T2016K' 'R2175C' 'R3205H' 'G2313S' 'G3291S'
     'G3485A' 'E1314G' 'I4052L' 'R4299S' 'V2412L' 'Q220*' 'R5119Q' 'T2897A'
     'G428E' 'S2191I' 'R929K' 'R1653*' 'A2946V' 'S4593L' 'D5103N' 'M2681I'
     'X3191_splice' 'G813E' 'C3358Y' 'S3851N' 'S4165C' 'R4493C' 'E3311del'
     'C4375R' 'N1270S' 'L476F' 'T1390R' 'I3510T' 'T4558I' 'E2958K' 'V1816G'
     'E2242K' 'G4794S' 'N674S' 'V4805I' 'R63*' 'D411E' 'T5015I' 'S2498R'
     'R2557T' 'V4044L' 'G679R' 'E4264K' 'R2001Pfs*8' 'A3975T' 'P2821S' 'V345I'
     'P4537S' 'H2203Y' 'V3003A' 'V2438M' 'V1702M' 'N228S' 'S5060P' 'H132N'
     'G4785R' 'P1319T' 'E4914K' 'W1487R' 'P1076S' 'T530del' 'E2054Kfs*10'
     'T4979N' 'E3254K' 'Q2741R' 'E3027K' 'L439H' 'P2502L' 'N839S' 'V480I'
     'F4311S' 'K4578E' 'E2601K' 'S3367C' 'N4856S C518S' 'T96A' 'R671K'
     'G3921V' 'E2233D' 'D987N' 'T648A' 'Q677H' 'R1135S' 'G4106W' 'K2695R'
     'A4740D' 'Q3839P' 'T1325I' 'E4784K' 'Y4417C' 'R4192C' 'R4935Q A2929V'
     'D2738N' 'A4714S' 'Y2105C' 'I2189V' 'N760S' 'Q1566R' 'X2532_splice'
     'R2509W' 'V4523A' 'D993V' 'R4843K' 'W2693*' 'P321L']
    Column 'cdh1_mut' : 140 : ['0' 'G500Wfs*37' 'R732Q' 'Q23*' 'P744Qfs*26' 'T457Dfs*7' 'E781*' 'L355*'
     'D254V' 'Q610*' 'X522_splice' 'R527*' 'R796Pfs*11' 'M316Ifs*4'
     'L658Ffs*5' 'V157F' 'X55_splice' 'E463Q' 'G194_P201del' 'A634V'
     'T467Pfs*14 L466Sfs*15' 'E336*' 'T115Nfs*53' 'F626Sfs*35' 'D59Ifs*24'
     'V202Cfs*7' 'K664*' 'S133Lfs*82' 'R124Pfs*44' 'K86R' 'L582Dfs*4' 'F833S'
     'L442Wfs*13' 'P385Rfs*7' 'Y37Pfs*14' 'R154Gfs*62' 'F601Lfs*2' 'T515I'
     'F375Lfs*18' 'Y101Tfs*16' 'Y296Mfs*59 D292Afs*62' 'E745Rfs*3'
     'V473Rfs*10' 'R732Gfs*38' 'R6Pfs*50' 'P620Lfs*11' 'Q677Lfs*7' 'W156*'
     'T748Pfs*22' 'R108*' 'D288N' 'S180F' 'L742Tfs*6' 'Q641*' 'X379_splice'
     'E512Dfs*16' 'F39Lfs*17' 'F57Lfs*26' 'E58*' 'X722_splice' 'N458I'
     'I192Sfs*23' 'F32Lfs*24' 'I807Mfs*9' 'L355Vfs*2' 'N613Tfs*4'
     'N431Kfs*6 V430del' 'N240Kfs*4' 'W4*' 'Y835* F833V' 'E138*' 'T820Yfs*2'
     'A719Lfs*3' '*3*' 'Y37Hfs*19' 'A408Gfs*11' 'G134*' 'Q449*' 'N166_E167del'
     'X721_splice' 'L705*' 'D257*' 'P160Sfs*54' 'A634T' 'G278R' 'N803Ifs*13'
     'I485Sfs*37' 'P260*' 'E739Dfs*31' 'Y663*' 'I650Yfs*13' 'V17Gfs*41'
     'D402V' 'D183Tfs*32' 'D349V' 'D155Lfs*12' 'Q307*' 'R492Kfs*45'
     'D819Gfs*3' 'G324_V328del' 'X130_splice' 'L798I' 'R598Q' 'T318Hfs*3'
     'R48Efs*14' 'E739Kfs*32' 'T578Nfs*10' 'Y228*' 'D198Efs*18' 'N613Mfs*16'
     'X11_splice' 'S232Lfs*12' 'E336=' 'Q503*' 'D819Tfs*25' 'H233Qfs*11'
     'E497Rfs*25' 'R749Pfs*24' 'P260T' 'E283* M282I' 'N166Kfs*47' 'Q673Lfs*5'
     'E604*' 'Q765=' 'E494Kfs*28' 'S649Ffs*2' 'E534Rfs*23' 'S649Yfs*13'
     'X230_splice' 'C686*' 'C686Vfs*2' 'E702Gfs*46' 'Q351Sfs*7' 'S36Kfs*23'
     'Q511*' 'V384Gfs*3' 'S337Ffs*12' 'E283Tfs*4 S280A' 'A411Gfs*8'
     'W156Lfs*12']
    Column 'ahnak_mut' : 153 : ['0' 'V5509_T5515del' 'D4727H D4853H' 'D950V' 'D3562A' 'D4725G' 'D3247N'
     'K2493E' 'M1465I' 'V462I' 'L3100V' 'D4487N' 'V4771I' 'G481R' 'D2889H'
     'D4337N' 'N5455K' 'D4997V K4041R' 'E3455K' 'A5570V' 'G3331V'
     'P3279Q D4691N' 'G264D' 'G5496E' 'G4235A' 'A3982V' 'S511F' 'R3924Q'
     'H2447P' 'P3284T' 'K3946E R5779H' 'G3012D' 'P1090S' 'M4785I' 'P949R'
     'R5779H' 'D5419N' 'L4112V G2655V' 'Q5646* G5592V' 'A4238V' 'P2521R'
     'D3585H' 'G2128A G1933A' 'E1633Q E1401Q' 'G4284V' 'I4293T' 'L2105F'
     'S4908L G2655V' 'A4702V' 'N5167D G3682A' 'I785T' 'G5586E' 'L3354I'
     'A1432T' 'S3836*' 'P5600H' 'M1857I M939L' 'A389T' 'N2071S' 'A2498V'
     'N5607K' 'I4726V K4448T' 'G467R' 'G5496E P5127S' 'E1230Q' 'S5190C'
     'G3528V' 'P2800Q' 'E5758Q' 'S660L' 'D4808N' 'V3795A' 'K3530R' 'M1387T'
     'M4711L' 'G1399S' 'K1640T' 'S115=' 'G5675del' 'G2655V' 'I4044T' 'G3617A'
     'T126I' 'I1689M' 'T4999I' 'M1982I' 'D3651H' 'P3279Q R3924Q D4691N'
     'R5446W' 'K935R' 'I3996V' 'K4710N' 'I395L' 'K4166R' 'K1333N'
     'R5779H G346A' 'S210L' 'D5277N' 'D3971H' 'G5592S' 'V906M' 'V4219I'
     'T161A' 'Q3142R K433R' 'G1669E' 'V3415L' 'V5806M' 'K4067E' 'P4663L'
     'I3563V' 'V2932I' 'P2216S' 'P5795L' 'D3171G' 'S4789N' 'E2677*' 'E4698K'
     'V441I' 'M3942I' 'K2875I' 'P2772S' 'D1707G' 'D4990N' 'P4584R' 'E3993G'
     'V771M' 'G5496E V2539I' 'D3312N' 'E5132K' 'K1024E' 'P2261L L1905F'
     'P4127L' 'P1127L' 'K2952R' 'M1352L' 'P3943A' 'D1291Y' 'N2190D N2192H'
     'V3062I' 'D4585G' 'I404T' 'K3946E' 'S2670P' 'M4316T' 'V4210L' 'A5326V'
     'G4039D' 'M1131I' 'V4921I' 'G365V' 'P3957S' 'M4131L E595G' 'R5779C']
    Column 'dnah11_mut' : 154 : ['0' 'P4178T' 'A1768Gfs*8' 'T529S' 'R4437H' 'L2612F H1438Q' 'L1326H'
     'M1096I' 'H3814Q' 'A3388T' 'R2189*' 'K1774*' 'F2771Vfs*2' 'Q646*'
     'S3023N' 'Q3723*' 'W2255R' 'R410K' 'R1836*' 'E580Q' 'Q1298H' 'R3491H'
     'T1428A' 'M1578T' 'C2386Y' 'R2891W' 'T4170S' 'P1626L' 'R2002* Q2427E'
     'R60C' 'I749N' 'R2362I' 'D3938H' 'H1352L' 'P232L' 'R2432Q S1488F'
     'S2963Y' 'R383W' 'P3925L' 'I2785V' 'P4110T' 'E236K' 'K1327T' 'D3039H'
     'T3163A' 'A3136V' 'N998S' 'Y4281*' 'R2128W' 'M635V' 'G411R' 'I1124Lfs*13'
     'T1804A' 'G2325S' 'D1667N' 'A25P' 'P2390A' 'R4136C' 'P4211L S1097R'
     'Q2660H G4190D' 'P2394A' 'K428N R2491P' 'P4211L' 'P4421L' 'I2217V'
     'Q1401R' 'L3543F' 'Y2405N' 'A2039V' 'R3567S' 'G2858S' 'E975Q' 'D1662V'
     'D2937Y' 'L1607F' 'S1831T' 'Y970C' 'Q1014E' 'E1425A' 'M446I' 'L3120I'
     'R1233G' 'S312N' 'T3460K' 'L3327M' 'R2040H' 'F4325C' 'Y3420S' 'F3784L'
     'K4415Q' 'R1436Q V1952E' 'P4456H' 'E38D' 'A2306T' 'Q2660H' 'N4122S'
     'R1865Q' 'P4201S' 'D1389N' 'V3750G' 'E3703Q' 'R2891W L514I' 'A860V'
     'F2631I' 'Q947E' 'A1968V' 'R2243*' 'A3614D' 'F3355S' 'F484L' 'T677S'
     'R1408S' 'Y687C' 'E2150* E42K' 'E506Q' 'H2956Y' 'R2189Q' 'K936T' 'A45T'
     'G110R' 'C3704R' 'N501S' 'A1634G' 'M948I' 'C1651R' 'L2160F' 'E3751K'
     'P4034A' 'I2675F' 'D3461E' 'M3788T' 'C847R' 'I243F' 'R2082P' 'P2198L'
     'R3130K' 'K2352T' 'L2387W' 'Q1779* E3017D' 'M1130V' 'N2819S' 'T2812A'
     'T801M' 'E3135K' 'E3695A' 'T4444S' 'I3831V' 'V30M' 'P4183L' 'H3766D'
     'Y1629H' 'L4262P' 'E2883*' 'E4173K']
    Column 'pik3ca_mut' : 160 : ['0' 'H1047R' 'E542K' 'Q546H G1049R' 'E545K' 'N345K E81K' 'H1047L E726K'
     'H1047L' 'E545Q' 'N345K' 'L452Kfs*4 E453Dfs*7' 'N345K N1044K'
     'E365K C420R' 'E545K H1047R' 'E542K E726K' 'E453_L455del' 'G451_D454del'
     'E110del' 'Q546K' 'H1047R E453K' 'R88Q' 'H1047R P104L' 'H1047R E726K'
     'M1043V' 'Q546P' 'N1068Kfs*5' 'H1047R R108H' 'K111E' 'H1047R G118D'
     'H1047R H1048R' 'E545G' 'E542K N345K' 'E545K G320A' 'E545K S509Y' 'E418K'
     'E545K G914R' 'H1047R L10_P17del' 'C420R' 'P449S' 'E545K E726K'
     'H1047R E81K' 'Q546R' 'H1047R D1029H H1048R' 'E545K M1043V' 'P449T'
     'V105del K148N' 'A1066Cfs*7' 'H1047R T727K' 'E545A' 'H1047R E80K' 'E726K'
     'H1047L E385K' 'H1047R K111E' 'E542K T727K' 'M1043I' 'H1047R P471L'
     'E726K P449_L452del' 'G118D' 'N345K M1043I' 'Y1021Hfs*9' 'P447_L455del'
     'Q546H' 'Q546R E453K' 'E542K Y1021H' 'R108del' 'M1043V E726K'
     'E545K D725N' 'H1047R E365K' '*1069Lfs*5' 'E453_G460delinsD' 'H1047Y'
     'E542K D1045N Q1064H' 'R88Q H1047R' 'H450_I459del' 'F909L' 'H1047L P449T'
     'G1049R' 'N345K S161R' 'P471L' 'E542K E970K' 'K111del' 'G106V'
     'H1047R P471A' 'N345K F83C' 'L113del' 'R115L' 'P471_C472insML' 'N1044K'
     'N345K E726K' 'E453K' 'E545K P104R' 'E545K M1004I' 'E542K M1043I'
     'Y1021H V105del' 'K724del' 'E970K M1043I' 'L113Sfs*32 K111Dfs*16'
     'H450_P458del H1065Y Q1064H' 'E81K D1017H' 'H1047R E726K E453Q'
     'H1047R P471L R108H' 'S629C' 'V344G' 'Q546P *1069Wext*4' 'N380S' 'E365K'
     'H419_P421del' 'H1047R E542A' 'H1047L C420R' 'K111E G320A' 'E726K N1044K'
     'D454N' 'H1047Y N345K' 'L334_R335insQNKNSLCNLRECKYSR' 'H1047R I459T'
     'H1047R I354F' 'E545K E542K' 'Y1021C' 'L293V' 'N345K N114S'
     'E545K D1017H' 'E545K M1043I' 'Y361C' 'P104T' 'K111E M1043I'
     'E110_R115delinsG' 'G118D T957P' 'R88Q C420R' 'H1047R G106R' 'E545D'
     'P539R Q546P' 'R93L' 'E110_I112delinsD' 'H1047R E81A' 'V146I'
     'H1047R P104R' 'H1047Q' 'E545K E542K H1047R' 'H1047R E110del Y1021C'
     'H1047R N345K' 'E545A G1050S' 'H1047R I69N' 'H1047R R93W' 'C420R E970K'
     'G1007R' 'R93W' 'H1047R K111N' 'E542K T1025S' 'H1047Y G118D'
     'E545K E542K E726K D725N' 'G414R' 'Y1021H' 'H1047R G1007R' 'P104L'
     'P449_L452del' 'N345K T727K' 'E103_V105del' 'N345I' 'A1035T' 'W11C']
    Column 'map3k1_mut' : 194 : ['0' 'S266Y' 'I1413Nfs*7' 'S1282Ffs*2 S924*' 'K1272Nfs*3' 'S11L'
     'Q1273Tfs*11' 'F1149Lfs*23' 'R483Kfs*5' 'A1327Gfs*11 D693Efs*33'
     'X385_splice S493Ffs*65' 'A1327Gfs*11 R249Pfs*53' 'S810* Q345E' 'S640*'
     'Y1276Lfs*10' 'S928Lfs*9 M1442V' 'R678Efs*19' 'K1024*' 'G102R'
     'H393Qfs*3' 'G209R' 'N1456S' 'L821Qfs*10 C1257del' 'X727_splice' 'Y553*'
     'R364Pfs*21' 'A1332_H1333ins*' 'G1008Afs*21 S1256del' 'D1084N'
     'K381Rfs*55 I284Kfs*12' 'M1081Ifs*4' 'R580Kfs*11 T1114Rfs*17'
     'V412Tfs*12 C355Y' 'D1040* K1041Nfs*41' 'L670*' 'S1256del' 'D1431G'
     'L765Ffs*7' 'S699Nfs*22' 'L1477Wfs*43' 'Q1259* R1496K' 'E1137*'
     'L1354Nfs*24 D1215Efs*31' 'R855C' 'R464Tfs*19' 'Y544Mfs*13' 'I776Cfs*4'
     'I1413V' 'L915Ffs*7 S989Lfs*93' 'R273Sfs*27' 'R339W' 'K1316Efs*8' 'Q525*'
     'V863A' 'S704*' 'Y1258*' 'K1041Nfs*41' 'Y1359*' 'R162H'
     'R1482* D221Rfs*4' 'D452Efs*30 S984*' 'S1434N' 'S1330L F800Lfs*22'
     'K1446Hfs*14 A1445Kfs*18 E1184Kfs*6 A1445Vfs*20' 'Q280*'
     'L1291Efs*4 D630Rfs*18 I1439F' 'L1410Hfs*8' 'G330*' 'G172E' 'P1053Afs*4'
     'P938T' 'E862* Y1237C' 'R364W' 'V719Efs*4' 'A726Kfs*14' 'R481K' 'M811V'
     'G343Wfs*42 S297*' 'F1149Lfs*23 X656_splice' 'T1241I' 'D1084G' 'Q700*'
     'Q519* M1442Wfs*19' 'L319Tfs*7 S281Wfs*19' 'A240V'
     'K1041Nfs*41 T1275Lfs*7' 'R763Cfs*35' 'K167E' 'Q562* Y317C'
     'E839Rfs*24 L885Ffs*19' 'Q1406*' 'L1122Ifs*16 K1272N' 'I487M'
     'X475_splice' 'L572* N1374S' 'F327Sfs*2 R364W' 'R1487Vfs*2 L359del'
     'X1222_splice T1148* Q1221del' 'K1234_D1240del' 'Q1406* X345_splice'
     'Q1028Nfs*54' 'L73M' 'P774R' 'E1187A' 'Y1276* D1388G'
     'R273Sfs*27 S1330Ifs*8' 'P550Lfs*7 C1488Tfs*9'
     'X1223_splice L1489_P1498del' 'L755Sfs*9' 'S1108Rfs*3 L877Ffs*50'
     'F1149* K1371E' 'L78P' 'M225V' 'X385_splice' 'L1321P' 'I322V'
     'Q624Rfs*32 P666Lfs*27' 'L78P M641V' 'Q409*' 'V873I'
     'R763Cfs*35 V650Cfs*6' 'Q965* S413*' 'W1243C' 'I474Ffs*13 L755Vfs*3'
     'W560*' 'R60del' 'A1194V' 'E265Ifs*35 L1354Tfs*9' 'A1396Vfs*21 Y317C'
     'C355Y' 'F1029Sfs*53 T457Qfs*30' 'Q1199*' 'A671V' 'E478*' 'H832Q'
     'L515Efs*41' 'E581Q' 'Q1199* I761Mfs*38' 'S1077Qfs*5 N1374S'
     'S1472Ifs*51' 'S1077* R364Q' 'Q345fs' 'Q345*' 'L838Rfs*24 W1449Mfs*15'
     'S422*' 'I1249Dfs*24 Q345E' 'W197Lfs*11' 'S431* M1193Hfs*19'
     'K1119Nfs*4 R763Cfs*35' 'X1419_splice' 'P15R' 'L676Tfs*21' 'V569A'
     'P253Sfs*51 I1307del' 'S1256del R364del' 'R248* I435Wfs*39' 'R532Q'
     'V1277Ifs*3' 'Q519*' 'R307Pfs*3' 'S427Ffs*5 G343delinsVR'
     'I723Yfs*2 H1303del' 'L1353Vfs*12 R1031Kfs*4' 'E235*'
     'Q1207* S1087Rfs*31' 'X346_splice G1401Wfs*19' 'L319Tfs*7 I1307delinsNF'
     'R273Sfs*27 V863Gfs*11' 'E1404Rfs*16' 'R364W L319del'
     'L1489* D1222Gfs*19' 'T1145Nfs*6' 'S242L' 'S626Mfs*11 C1257W' 'M852T'
     'X655_splice D510Ifs*47' 'L972Yfs*7' 'A1260Vfs*9 S371Qfs*10' 'T542Nfs*17'
     'X789_splice' 'R273Sfs*27 Q1406Rfs*12' 'E1294Kfs*13 I1249Dfs*24'
     'R249Pfs*52 R248Pfs*56' 'R1121* C966Vfs*38' 'N1302Efs*7 D510Gfs*31'
     'Q1020*' 'R763Kfs*9' 'M1297Ifs*2 R1296*' 'R1385Efs*37 N1305D'
     'V361Dfs*23' 'Y1276*' 'H1367Sfs*12 L1006Dfs*74' 'T542A' 'R1482*']
    Column 'syne1_mut' : 200 : ['0' 'A5378S' 'T1669P' 'L255P' 'I7809L' 'Q3260*' 'G7840E' 'A1871E'
     'K5068E' 'M6920I' 'S7786R' 'V3596M' 'R5942C' 'R6913C E2413= A2913T'
     'P222L' 'E1744K' 'D7325Y' 'X857_splice K6989N' 'L928S' 'D7260H' 'V1460I'
     'G1304A' 'H7489R' 'D6565N' 'E5872D' 'F2320L H728L Q1395L' 'L106F'
     'R8495H' 'V7754I' 'P6744H' 'Y7741C' 'L8788I' 'E1179A' 'H7939Y' 'R648Q'
     'D8584A' 'V5950L' 'E1988K' 'R5432Q' 'E5534A' 'P4844T' 'S3382=' 'L1904W'
     'E3165D' 'I8418F' 'G5173R' 'M7986V' 'R8738C' 'A421V' 'T2787M'
     'R6577Q T8368I' 'R3624G' 'T3320M R1132G' 'R5325G' 'D4637N' 'M824I'
     'P283T' 'P6911S' 'X314_splice' 'V4700F' 'V4831L' 'S5840L E3169Q' 'K7074R'
     'K3209*' 'T8720S' 'I8163T' 'S4886G' 'T2787M G7008R' 'L6338V' 'H7903Y'
     'A2974S' 'R6913Afs*8' 'D8448N' 'K6985Vfs*14' 'I5727T' 'Q702L' 'S2242T'
     'M8596V D3902E' 'E4141Q' 'E1456*' 'R1091W' 'Y2474C' 'Q5484H'
     'R1344Q I2386V' 'R3492H' 'E1179K G4975E Q8752*' 'D3516N' 'A1710D'
     'S1879F' 'N588H' 'E2861V T3740A' 'L4221F' 'G7638D' 'R8117W' 'V7887M'
     'A2789V' 'I5982T I5698V' 'R4324C' 'R7549C' 'R170W' 'D2163Y' 'E8051Q'
     'I7557V' 'S289T' 'Q8476R K8436M' 'L6237*' 'V230A' 'R2368H' 'A8330T'
     'L2185I' 'D2049V' 'T2359N' 'V7481del' 'F2538L S8688*' 'G1533R' 'I2316V'
     'S6289L' 'L8000S' 'E1350K' 'M7469V' 'R8651H' 'E1958A Q448R'
     'H499Y T6690=' 'K7126R' 'R5623C' 'R6577Q' 'M5117T' 'D4637N E1179A'
     'M2832I' 'F489Y' 'F7301L' 'A6035S' 'T2540M' 'C802Y'
     'K5408N E5212K E3017K L2249F Q1336H S6466P S2433*' 'N7143K' 'E2917K'
     'G7628_A7635del' 'R9W' 'C4995Y' 'Q3940H' 'L4557Q' 'D2716G' 'E4519K'
     'L125F' 'E2032Q' 'F7357S R961W' 'L7266F' 'R2537S' 'W36C' 'R8468H'
     'M8596V' 'T3320M' 'Q2747H' 'S5423N' 'L1605R' 'W6776C R4741H' 'E5826K'
     'H8408R' 'R444W D264G' 'W1139*' 'N6939Kfs*10' 'E8155K E6199del' 'E4526K'
     'R4834Q' 'R5880L' 'N1172I' 'S6045F' 'E2627K R85P D381A' 'R3979S' 'L1839F'
     'W7241R' 'R8782Q' 'E55K' 'M6783L' 'G6611E' 'G5288A' 'A1216V' 'R8293Q'
     'R5662S' 'S1679T' 'I129M' 'N2364S' 'A7827G' 'K5312E' 'M3123I'
     'K3127E M6190V' 'G8378D' 'L8331V' 'R8064C' 'I466V' 'G8363E' 'V4493D'
     'K1987E' 'D3177G' 'V4706I' 'S6062L' 'E1193D' 'R4997S' 'A1216G']
    Column 'kmt2c_mut' : 222 : ['0' 'M1974Ifs*32' 'K1777Lfs*21' 'S3531Cfs*34' 'V1257Dfs*17'
     'R4533* L4157*' 'V2581Lfs*2' 'Q2348*' 'L1984Yfs*6' 'R190*' 'T657Nfs*18'
     'E2379Q' 'P1838R' 'Y460*' 'E78Nfs*17' 'G1239*' 'Q3545*' 'S3213*'
     'G2041Afs*10 M940T' 'M1819T' 'R841Q' 'S1182*' 'R1690T' 'R4145C' 'C302R'
     'T3725Efs*21' 'K191Tfs*28' 'T408Rfs*15' 'Q3476Pfs*19' 'E2715*' 'Q2128P'
     'E4676K' 'I2229Ffs*10' 'R1092* H2489Qfs*31' 'X1597_splice' 'E537Afs*8'
     'D599Efs*15' 'R841W' 'P4028Hfs*6' 'Q2161*' 'R897*' 'S3331Vfs*30' 'H1424='
     'R526Vfs*10 P4630*' 'E64*' 'T3017Vfs*14' 'W1049*' 'R41C' 'A2254T'
     'X1694_splice' 'K4659N' 'S1840Lfs*2' 'V3532L' 'V2621M' 'T2433P' 'C710*'
     'G4354Nfs*14' 'L804V' 'A4837T' 'R904*' 'S1820C' 'L4454Afs*20'
     'S708Hfs*10' 'Q666Sfs*3' 'R1092*' 'S708Yfs*10' 'E3726Rfs*10 D2861Rfs*4'
     'S1415F' 'Q668Afs*7 R2226Kfs*8' 'R841W G3130V' 'Q2128*' 'S2914*' 'C960F'
     'I1030Kfs*40' 'I129= G2329R' 'W1002C' 'K3683*' 'K3178Sfs*70' 'G826Vfs*28'
     'Q2325*' 'K4758Qfs*11' 'C1081Lfs*37' 'K3806N S46P' 'I1706Kfs*2'
     'E3874del' 'P12S' 'P2202T' 'Q419*' 'Q2618Sfs*29' 'R3421Kfs*20' 'L3037del'
     'E1324Sfs*6' 'P2468S' 'E2838*' 'P2538Lfs*24' 'P2600L' 'G4865E'
     'D775Rfs*76' 'W1639*' 'P2103R S4300P D481H' 'P4041Lfs*42' 'Q3068*'
     'L1583V' 'R894Q' 'G1462R' 'P3555T' 'Q2186*' 'L4079V E4451Q' 'X490_splice'
     'D4425A' 'S4300P' 'V3744L' 'G2282R' 'V2987M' 'Y3699Mfs*6 V2322A R2610Q'
     'R526L' 'X993_splice' 'C1060Wfs*10' 'S1416L' 'G568S' 'E1260Kfs*43 L804V'
     'V2322A R2610Q' 'W4587* P1472L' 'Q2404Rfs*43'
     'T2365Kfs*21 S3530Ffs*4 S3497Pfs*14 T3017K' 'A3424V' 'H4833Qfs*2' 'S836F'
     'S1712*' 'C4479F' 'D958Y' 'M546I' 'S1799L' 'N3347S P792S'
     'S1200* S2362* L4245V Q1314E' 'L4245Hfs*23' 'G3135Efs*21' 'R3853W'
     'Q3035*' 'D2765H' 'N4686S' 'D738Gfs*3' 'S3371*' 'S3020F' 'A4748T'
     'Q2096Hfs*5' 'P2356Lfs*9' 'E1750Dfs*27' 'E532D' 'L3823Wfs*22' 'C4462W'
     'X4092_splice' 'L4144V' 'S773L T2999A' 'P4134L' 'Q448* Q569* L602F'
     'Q3310P' 'T4437Rfs*11' 'S1085C' 'S1459*' 'E3985*' 'Y1898*' 'H985Q'
     'H2205Ifs*34' 'S3208Ffs*2' 'S1291I' 'P813T P3555T' 'C1106R' 'P3644Qfs*2'
     'S321N' 'L4136Sfs*24' 'L804V R2603I' 'Q3396Kfs*24 F2349Lfs*14'
     'X3125_splice' 'R490T' 'S2127F' 'M1895V' 'I2932*' 'P3712S' 'X1321_splice'
     'P2292_S2293del' 'A4857S' 'S2353F' 'Y1139C' 'E654*' 'G3829S'
     'Q2220* D795N E3745Q' 'S772*' 'P468A' 'L602del' 'G4012V' 'S1889A'
     'T4795P' 'R2497C' 'Q2096*' 'L4157*' 'E114* D1699G' 'E936K' 'T3624P'
     'A1526S' 'Y3593H' 'E3801*' 'C4474Y' 'Y1348*' 'K2702*' 'R4478*' 'I745V'
     'N2929*' 'V2142L' 'I4628T' 'L325Cfs*30' 'K2044Rfs*34' 'C4493R' 'E1333*'
     'R3507*' 'Q364*' 'Q3233*' 'L1773Pfs*2' 'R4139*' 'Q2354Hfs*11'
     'P2502Lfs*13' 'S1745Ifs*4']
    Column 'ahnak2_mut' : 248 : ['0' 'E5575K' 'E1183*' 'V2061L' 'I5553T' 'E2173Q' 'P3581L' 'R4512H'
     'A196D' 'G2726S' 'A2472V' 'V3631M' 'T3428A' 'S1341C' 'G812A' 'F3973L'
     'A2628V' 'P5615L A3652G' 'L3064M' 'F5496S' 'E5776G S5639N K4228R'
     '*5796Sext*46' 'L4206V V2423I' 'D2030Y D2195Y' 'D4460E' 'E660Q K4060N'
     'Q1745E' 'K1657R' 'V1122M' 'P1508L' 'S4593R' 'L2130R' 'D4251E' 'S4697L'
     'V856L' 'S124G' 'A3652G A3759V M3475I' 'A2834V' 'L395S' 'A1514V R3490K'
     'K1867Q' 'D4065G D4331E' 'G2457R' 'A3335V' 'D3341N' 'G3903V' 'Q1553H'
     'D653N' 'V4167M D1978Y' 'A123T' 'V1628I' 'G3370R' 'E1678Q' 'D2970E'
     'S3651W' 'M1778R' 'A4230T' 'D2099Y' 'G5068S' 'D3749E' 'S3603R A1115T'
     'E816*' 'V1887E' 'R2794Q' 'P29S' 'V3769M V2352M L2206P' 'A2379P' 'I3822T'
     'V3342M P2651H' 'A878T' 'P3526L' 'V1186L D4331E' 'D2021N' 'E2008K' 'A74P'
     'E1776D A1779T' 'V2061L A1779T' 'A2043V P2040L' 'V2495A' 'V2061L A2834V'
     'Q1745E P2321R' 'A4013T' 'G400S E825A' 'E4038D' 'D3442H' 'E5738G'
     'T3095M' 'L3177M' 'V5320I' 'D4123N'
     'G5225Vfs*32 A5228Sfs*3 A5223_T5224insI G5334* A5229Efs*29'
     'V2061L V2230A P1397L K2289E E2229G' 'A1650V'
     'E2063K S1185L R5671S K997R' 'S3651L D3953N' 'S269R' 'A1653D E227G'
     'E3493Q' 'G400S' 'V1816M' 'R247G P315L T4793A' 'H2134Q H2134R Q2136E'
     'V2176L V3503A' 'D995N' 'V2061L P2850S' 'V2061L A2623T' 'G1473A' 'K4228R'
     'P2180S' 'V1928I' 'E5417Q' 'K1992N' 'R628C D1549G' 'G1277C' 'A1115T'
     'L4206V K4208E R513Q G4211S' 'D1920A' 'A2623T' 'V856L S2006T'
     'V2061L G1555R' 'P2225H H3050Q G2302E' 'S3152L A1520E' 'G2462V' 'D3859N'
     'S1832L' 'V2061L P1200S' 'V2061L G1473A' 'P2040S A2009V' 'E1611K'
     'H1235P' 'P806L' 'V2176L' 'Q1863K' 'P3377L V2061L'
     'G3224E L2416R E3378Q G2399E' 'R3649G' 'G2396S' 'E5291K' 'L2731P'
     'G2457R R2959Q' 'V3546M' 'G400S K1618E' 'S2835L G5071E' 'D2681N K2317R'
     'S5515L' 'D3742E' 'K3307E' 'T2693N' 'P5095S' 'D1682Y'
     'V2061L P2161L P5573S P1530L' 'P5615L' 'G4309R' 'W2464C' 'I2007T'
     'R3241C' 'S5302A' 'G1473A P2850S' 'A1115V' 'V2061L T3994S' 'G3709A'
     'A1514V' 'M1761I S4897R' 'G1473A K1922R' 'V1197M V2061L' 'A1672V'
     'E2443K' 'A1520E' 'M2357V' 'A1837T' 'T3263M T4508N' 'G1009R' 'E4318K'
     'V2899L P1545S' 'V1129M S5114I' 'A860E' 'L2222P' 'V1268I E1267D R1269K'
     'A3659S' 'E3433G' 'K437N' 'L2239V V2219M' 'V2061L V2877M S1142R'
     'D1535H E4043V D3020H' 'G5226* K2893R' 'V1186L' 'K1657R S2175L S2175T'
     'M4337T' 'V2061L A2834V V1459M' 'D4395E' 'V1394M D3341N P1200S' 'F3148L'
     'S2509C' 'V2061L P1380S L3542P V4328A' 'K997R E1843Q' 'V2061L D2878E'
     'V2061L V3209M' 'E72_D73insLTTINH E72Vfs*3' 'V1197M'
     'G400S E825A I4071L K4063E V4064M' 'H4678Vfs*45' 'P3392S' 'D2257V'
     'V4002M' 'A1158T' 'D4676H' 'P1136T' 'S3511C'
     'R4279W P2225H H3050Q G2302E K1915N' 'S2835L' 'K3472R' 'A3123T'
     'G3484R Q5219*' 'V3342M' 'T97I' 'M1778T' 'D4453V' 'S923C' 'P4106T'
     'V3535G' 'E379D' 'S4097C' 'P389R' 'Q3230H' 'I3906V'
     'L1254F L1572F V1197L' 'Q661K' 'T305M' 'M2609V M2119V' 'D2099Y R319K'
     'V1289M' 'L2326P' 'G4612R' 'V1846L F1737L C4223S' 'V3762L'
     'V4041M I1182S' 'V2384M D4130E' 'D2441N' 'T3098M L2676P E2675A' 'R5502L'
     'P1381L' 'V4310A' 'P4262S' 'D3680E' 'E3009K' 'D4340N' 'G746C' 'V3102M']
    Column 'muc16_mut' : 298 : ['0' 'R5550S' 'P6040R' 'E2017V' 'E3861*' 'R8636I' 'S248Y' 'P6073L'
     'A10511T' 'E5401K' 'S9115*' 'G4788S' 'T7649I' 'T11614M' 'A2971G' 'A9813V'
     'P8280S' 'S10047del' 'M6087I' 'E7296G V651M' 'G4575W' 'E1761D' 'A4577T'
     'I4280V T3821S' 'T8057R' 'I3067M' 'E8130D' 'A6331T' 'I2673V' 'V9550F'
     'P8S' 'P1819S' 'P8872L S4782L' 'I5233M' 'S10118P' 'A9501D K10803E'
     'E6441*' 'M193V' 'H7943R' 'R6274P' 'N9264T' 'T4494I' 'E9012Q' 'V2415I'
     'M6048T' 'W2883*' 'S4969T K4202N' 'L9762H' 'F2892S' 'T6599S' 'E8069G'
     'A10997V' 'R9708G' 'P10581L' 'V11607I' 'R8606C' 'M10430V' 'K10803E'
     'A2125G A1786P' 'N3226S L6678P' 'Q7218*' 'H1964Q N2586K S4859C' 'G9584A'
     'R5086C' 'P8376R' 'G11051*' 'S4799N' 'N4735T' 'T1984I' 'A2734T S3365P'
     'I9653V' 'D4992G' 'R1911*' 'A5423T S2730C' 'P6235T' 'P5602L'
     'T9078A G4400V' 'V1078I' 'S1228L' 'M11191V' 'P11593L S1480G' 'S3050P'
     'A6519E' 'S11903C' 'T5849A' 'M8192I R8247T E8177D' 'V11212I R8949S'
     'L7102F' 'L4309I' 'V8260M' 'T4907N' 'P3568L R6274P' 'S10189del' 'R3682G'
     'A2649P' 'E4253V' 'R9725I' 'S11287G' 'Q4733*' 'P113S T7510S' 'S6804del'
     'P5555L' 'E546K' 'K10017I' 'T5450I' 'S656T' 'S9327F' 'S5959F S6036C'
     'T7149A' 'M11542T' 'S7195P I7310T' 'M4501I T8997P' 'S10404R'
     'L2929V T6425A' 'H3261R' 'V10835L S134delinsRPG' 'A10976P' 'E52*'
     'S3443T' 'D902A' 'T11421I' 'S2743*' 'V4711L' 'H8229Q' 'T824A'
     'G6450R Q2103R' 'A5106G' 'E3930K A8196S' 'P10388A' 'A5423T' 'P4570T'
     'A8076G' 'T3392I' 'E3871K' 'E10676Q' 'A1146D' 'T6595S' 'E8874Q' 'P7711H'
     'M6638I' 'T3577I' 'S11638Y' 'R1911Q' 'M11019I' 'A8196S Q7237P' 'S248A'
     'D4070E' 'T6920I' 'L7829M' 'G9R' 'T9009N'
     'P6161L K6604T Q5733K G6450D E6872K V6053I T5197A' 'V5913M' 'A8196T'
     'M1483V' 'S9455R' 'P8273S' 'S8277* G9964W' 'T7779I Q5012K' 'S7747R'
     'S11840P' 'G10108E T7734K' 'S2395I' 'N6001S' 'Q526*' 'A4564T'
     'P5328S T9681N' 'T10989A' 'T8743R' 'S9276N' 'D902A P10907L' 'T11047P'
     'P5623S' 'T2312I' 'M6048T A6810P' 'T4052S P11017T' 'T3567S' 'A6225T'
     'T9940I' 'A2401S' 'T718I' 'R885K' 'R6630K' 'M5859I' 'D902A T1778I'
     'L6514F' 'S2952L' 'P1158del' 'M8382I' 'A4705V' 'V10405D' 'T11587M'
     'E3103K E9516K V6249L R4665T' 'T5242I' 'A3670S' 'M6048T A6810P D902A'
     'S2952L S2980T' 'A9141D' 'T5787I' 'P5328S T9681N V1675L L440P' 'S2952P'
     'I2140F T5029R' 'T10277I' 'I1618T A3533V' 'R10296Q' 'V4927L'
     'M6811V L6835H' 'M451I' 'A2696V' 'G619R' 'V4020D' 'S5929F P10004S' 'G80W'
     'L3124Cfs*41' 'P10699S' 'T4052S' 'T7684I' 'G10929E'
     'S6933Tfs*6 S6933Kfs*22' 'E4605Q' 'S6379L' 'S2369P' 'I1618T' 'P5244T'
     'T1924I' 'S4805N I347V' 'S4969T' 'L11564W' 'T7924M' 'G8303R' 'A4228S'
     'S7258I' 'E8447A' 'S8998F' 'S5929F I6629M' 'L1281V G613Efs*28 S97F'
     'S7491T' 'A8196S' 'L4701S' 'S3454P' 'M5906I' 'T7625I' 'S134T' 'T5593N'
     'S3318L' 'S2951R' 'Q6470E I9555V' 'P3818S' 'P3126S' 'S767L T4712S'
     'K9025N' 'P3045S' 'N11919K T5718I S9527G' 'T3107I' 'S3483R' 'V7378E'
     'T8523S' 'T8284I' 'S5530C' 'T5700S T5621I' 'P3214A' 'S5030N' 'T7928N'
     'T8328N' 'V605F' 'V3127F' 'T5812_E5813insL' 'S870L' 'E5858*' 'S3139C'
     'T9179N' 'V5565I Q3306K' 'T8779M G10745R M331I P4458S' 'N139S S3888C'
     'A11385Qfs*10' 'I7030Tfs*33' 'M7960K' 'E5792del' 'T7763K' 'T7023R'
     'T11075S' 'M7508V H7767R' 'S2253Y' 'T7850S' 'S4355R P5555S' 'S767L'
     'S202C' 'S5929F P10004S I9653V' 'V9854L' 'A9110S' 'S6720R' 'S8326N'
     'S4908L' 'T1023K' 'S2028C' 'P9259A' 'E7573D' 'A10542V']
    Column 'tp53_mut' : 343 : ['0' 'H178P' 'S241F' 'P67Qfs*56' 'C242R' 'C135R' 'S303Efs*3' 'R273C'
     'G245S' 'R175H' 'P177R' 'C277F' 'Q317Sfs*28' 'Q192*' 'K132N' 'G266Rfs*74'
     'Y163C' 'S106Rfs*41 F109_R110del' 'H214R' 'R282W' 'R110P' 'G154Afs*16'
     'X225_splice' 'H193R' 'R196*' 'G245D' 'D281H' 'C135W' 'R248Q' 'V157F'
     'V197G' 'I255del' 'R280S' 'N239D' 'A159V' 'Y205S' 'R273H' 'N131del'
     'S241Y' 'R306*' 'R248Q F270S' 'P250L' 'I195Yfs*14' 'H193L' 'G266E'
     'Y220C' 'X224_splice' 'P191Lfs*56' 'P151S' 'R213Dfs*34' 'X261_splice'
     'E285K' 'R248G' 'Q136H' 'X332_splice' 'E285*' 'Y234H' 'A74Sfs*71'
     'S20Qfs*24' 'D208V' 'R337L' 'E349Gfs*30' 'H115Afs*34' 'H179R'
     'D148Hfs*31' 'D148Pfs*21' 'G245del' 'T102Pfs*21' 'E171Gfs*3'
     'L194_I195insSIL' 'C141R X126_splice' 'Q165*' 'S166*' 'I195T' 'R337C'
     'S90Pfs*33' 'G245V' 'Q136*' 'F338Rfs*8' 'Y107*' 'C238R' 'L111P' 'P278S'
     'R110Pfs*39' 'P27L' 'X331_splice' 'R248W' 'C275Y' 'Q104*' 'C242S' 'Y236C'
     'H214Lfs*33' 'L194R' 'P151H' 'Y126C' 'R249S' 'E287*' 'Y234C' 'F134L'
     'R280T' 'V272G' 'T304Nfs*42' 'R248Q R175H' 'V216L' 'C141Y' 'D281G'
     'C238*' 'E271Gfs*74' 'R213*' 'V218Hfs*5' 'G244S' 'N131Cfs*27' 'L344R'
     'G199V' 'T155N' 'R342*' 'K139Nfs*9' 'V197E' 'L111Ffs*40' 'G245C' 'Y220S'
     'I232T' 'S241C' 'I162delinsRL I162_Y163insC I162M' 'Y234N' 'T155Pfs*23'
     'E294*' 'R267P' 'R110Lfs*13' 'V157Tfs*26' 'X126_splice' 'P152Rfs*18'
     'R181C' 'H178Pfs*3' 'S127F' 'R267G' 'C124Lfs*25' 'N239S' 'E339Gfs*6'
     'R342Efs*3' 'N239*' 'L111Wfs*12' 'A138Pfs*32' 'N239_S240insT' 'P278T'
     'L137Q' 'V272M' 'D49Mfs*4' 'I255Sfs*90' 'P278R' 'R342P' 'X187_splice'
     'R333Vfs*12' 'P191Lfs*53' 'R249M' 'A69Vfs*54' 'C229Yfs*10' 'G262V'
     'C238G' 'Q52Lfs*68' 'W53* E51_Q52del' 'D393Tfs*29' 'Y126N' 'M340Ifs*7'
     'Q331Rfs*14' 'L257Q' 'I162Tfs*14' 'R110H' 'N200Ifs*47' 'M246*' 'E180*'
     'G244C' 'E285* E271K' 'V274L' 'H214_E221del' 'H179Q H178Q' 'V217Gfs*29'
     'N268Lfs*75' 'R282Gfs*63' 'H178Pfs*2' 'Q317*' 'R209Kfs*6' 'D281A' 'P151T'
     'W146*' 'V122Cfs*27' 'R280T E326Q' 'P153Afs*28' 'A276P' '*394Tfs*76'
     'Q331*' 'H193Qfs*53' 'L257P' 'I255F' 'E271K' 'P318Afs*19' 'P128Lfs*42'
     'X125_splice' 'X307_splice' 'T125K' 'W91*' 'C176Y' 'C124*' 'E11Q'
     'I50Mfs*73' 'R273G' 'R158L' 'G154S' 'E349* L348F' 'I195Tfs*52' 'Q144*'
     'R273P' 'C238S' 'V272L' 'P390Lfs*32' 'C242Y' 'S260Pfs*85' 'I255Nfs*9'
     'E258*' 'H179Y' 'C238Y' 'V157_R158del' 'F134C' 'X10_splice' 'R273C R342*'
     'G266V' 'G108Vfs*15' 'S166Hfs*4' 'R174Sfs*67' 'S183*' 'A74Pfs*49' 'L194P'
     'C275F' 'N239I' 'V173M' 'F134V' 'R273L' 'P223Afs*2' 'M237I' 'G108Vfs*13'
     'S185Tfs*62' 'V173L' 'R280K' 'K132E' 'S127F G325E' 'N131I' 'Q52Pfs*5'
     'L111Q' 'S149Pfs*21' 'S314*' 'C242Afs*5' 'G262_N263del' 'M246R'
     'P34Vfs*12' 'H193Y' 'C176S' 'C141*' 'E204*' 'T125Vfs*23' 'S215G' 'V173G'
     'I195Sfs*52' 'E198*' 'L111Afs*11' 'M246V' 'H179L' 'F54Kfs*67' 'K120E'
     'A83Pfs*35' 'C135F' 'R249G' 'S106Rfs*41' 'E298*' 'G262Efs*9' 'V197Gfs*50'
     'A159D' 'G374Afs*43' 'C275Lfs*70' 'E171*' 'P278S P278L' 'Y107_F109del'
     'I255T' 'R280G' 'R282Pfs*62' 'V216M' 'P301Qfs*44' '-125fs' 'W91* P92T'
     'Y205_T211del' 'L45Cfs*78' 'P190T' 'F270L' 'G334V' 'C242F' 'C124Afs*46'
     'C135Afs*35' 'R175G' 'S215Cfs*6' 'G302Rfs*4' 'P152L D259Y' 'E62*'
     'K305Sfs*40' 'R158Pfs*12' 'E51Lfs*73' 'A159P' 'E287Ifs*63' 'A84_S90del'
     'I254Sfs*91' 'P322Hfs*23' 'T125=' 'L265Gfs*34' 'Y205N' 'R337H'
     'N345_L348delinsM' 'Q317R' 'E224D' 'M44Cfs*79' 'E349_G356del' 'Y236S'
     'R110L' 'Q167*' 'P177_C182del' 'N239_S240del' 'E349*' 'G154V' 'I50*'
     'P151A' 'E51*' 'T102Ifs*46' 'H179D' 'K291*' 'K132N E62*' 'A83Gfs*66'
     'F113del' 'L194Pfs*13' 'G325*' 'D352Y' 'E258Q' 'E171G' 'L330R'
     'E349* L348F L348S E349Wfs*22 E349Tfs*32' 'T211A' 'I255S']
    

<span style="font-size:16px"> Above we see that we have columns in our dataset whose number of unique values are as low as 2,3 and columns whose unique values are as high as 343 </span>.

Also, some values are easy to understand(given in plain English).
Here, we will use <b>OrdinalEncoder()</b> to convert features into numeric since we can clearly see an order in the observed unique values. 
Eg. "positive/negative" , "High/Medium/Low", etc

<span style="color:blue;">According to theory, Ordinal Encoder works well when the categories have a meaningful order.</span>

However, for the rest of the features,we see alpha-numeric characters which are hard to interpret. Also, the number of unique values per column can be as high as 343. Here, we will be using <b>Feature Hashing method</b>

<span style="color:blue;">According to theory, Feature hashing takes into account high dimensionality and cardinality in features. It is specially useful when the number of unique values in each column are high.</span>


```python
from sklearn.preprocessing import OrdinalEncoder


#For Ordinal encoding
col_1=['type_of_breast_surgery','cancer_type','er_status_measured_by_ihc','er_status','her2_status',
       'inferred_menopausal_state','pr_status','cellularity','primary_tumor_laterality','death_from_cancer',
       'her2_status_measured_by_snp6','3-gene_classifier_subtype','cancer_type_detailed','pam50_+_claudin-low_subtype']

X=df[col_1]

encoder=OrdinalEncoder()

# Fit and transform the selected columns
X_encoded = encoder.fit_transform(X)

# Replace the original columns in your DataFrame with the encoded values
for i, column in enumerate(col_1):
    df[column] = X_encoded[:, i]
```


```python
df[col_1].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>type_of_breast_surgery</th>
      <th>cancer_type</th>
      <th>er_status_measured_by_ihc</th>
      <th>er_status</th>
      <th>her2_status</th>
      <th>inferred_menopausal_state</th>
      <th>pr_status</th>
      <th>cellularity</th>
      <th>primary_tumor_laterality</th>
      <th>death_from_cancer</th>
      <th>her2_status_measured_by_snp6</th>
      <th>3-gene_classifier_subtype</th>
      <th>cancer_type_detailed</th>
      <th>pam50_+_claudin-low_subtype</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>6.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>4.0</td>
      <td>1.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>4.0</td>
      <td>4.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>4.0</td>
      <td>3.0</td>
    </tr>
  </tbody>
</table>
</div>



For the rest of the columns,
The range of no. of unique values in a different column lie between 2 to 343. The dataset has high cardinality as well as high dimensionality.Also as it is clear that rest of the features being alpha-numeric terms are not interpretable in the context.
Normal feature hashing might lead to information loss due to collisions as different categorical values might map to the same hash bucket. 
Given the unclarity on the domain knowledge of features and to retain as much information as possible, therefore to avoid collision of features, I will be using <b><span style="color:blue;">Grouped feature hashing </span></b> here.

<b><span style="font-size:18px">Grouped Feature Hashing</span></b>

In combined feature hashing, multiple related categorical features are combined or concatenated before hashing. This helps preserve some inter-feature relationships and can reduce the likelihood of collisions compared to normal feature hashing.

<b>Advantages:</b>

1. Reduced Collisions: Combining related features can reduce the chances of collisions.
2. Preserves Some Information: By combining related features, it preserves some of the inter-feature relationships.





```python
col_2=df[cat_cols].drop(df[col_1],axis=1)

col_2.info()

#col_2 has total 177 columns

# Combining all columns into a single categorical feature

col_2['combined_categorical'] = col_2.apply(lambda row: '_'.join(row.astype(str)), axis=1)

```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1904 entries, 0 to 1903
    Columns: 177 entries, tumor_other_histologic_subtype to siah1_mut
    dtypes: object(177)
    memory usage: 2.6+ MB
    


```python
from sklearn.feature_extraction import FeatureHasher

# Initialize the FeatureHasher
hasher = FeatureHasher(n_features=10, input_type='string')

# Apply feature hashing to the combined_categorical column
hashed_features = hasher.transform(col_2['combined_categorical'].str.split('_'))

# Convert the hashed features to a dense array
hashed_features_array = hashed_features.toarray()

# Create a DataFrame from the hashed features
hashed_features_df = pd.DataFrame(hashed_features_array, columns=[f'feature_{i}' for i in range(10)])

# Reset the index of col_2 and hashed_features_df
col_2.reset_index(drop=True, inplace=True)
hashed_features_df.reset_index(drop=True, inplace=True)

# Concatenate the DataFrames hashed_features_df with the principal data df to create new data for analysis
#col_2 = pd.concat([col_2, hashed_features_df], axis=1)
df_1 = pd.concat([df, hashed_features_df], axis=1)

```

I will first drop all the unwanted columns present in col_2 so that i can reduce the number of features and proceed with analysis. 


```python
# Preparing a list of non numeric columns for which i have created combined category so they can be removed from analysis
col_2_columns=col_2.columns.tolist()
print(col_2_columns)

''' Removing 'combined_categorical' column from col_2_columns since it is not present in original df dataframe and 
    we are using it to drop cols from df '''

col_2_columns.remove('combined_categorical')
```

    ['tumor_other_histologic_subtype', 'integrative_cluster', 'oncotree_code', 'tumor_stage', 'pik3ca_mut', 'tp53_mut', 'muc16_mut', 'ahnak2_mut', 'kmt2c_mut', 'syne1_mut', 'gata3_mut', 'map3k1_mut', 'ahnak_mut', 'dnah11_mut', 'cdh1_mut', 'dnah2_mut', 'kmt2d_mut', 'ush2a_mut', 'ryr2_mut', 'dnah5_mut', 'herc2_mut', 'pde4dip_mut', 'akap9_mut', 'tg_mut', 'birc6_mut', 'utrn_mut', 'tbx3_mut', 'col6a3_mut', 'arid1a_mut', 'lama2_mut', 'notch1_mut', 'cbfb_mut', 'ncor2_mut', 'col12a1_mut', 'col22a1_mut', 'pten_mut', 'akt1_mut', 'atr_mut', 'thada_mut', 'ncor1_mut', 'stab2_mut', 'myh9_mut', 'runx1_mut', 'nf1_mut', 'map2k4_mut', 'ros1_mut', 'lamb3_mut', 'arid1b_mut', 'erbb2_mut', 'sf3b1_mut', 'shank2_mut', 'ep300_mut', 'ptprd_mut', 'usp9x_mut', 'setd2_mut', 'setd1a_mut', 'thsd7a_mut', 'afdn_mut', 'erbb3_mut', 'rb1_mut', 'myo1a_mut', 'alk_mut', 'fanca_mut', 'adgra2_mut', 'ubr5_mut', 'pik3r1_mut', 'myo3a_mut', 'asxl2_mut', 'apc_mut', 'ctcf_mut', 'asxl1_mut', 'fancd2_mut', 'taf1_mut', 'kdm6a_mut', 'ctnna3_mut', 'brca1_mut', 'ptprm_mut', 'foxo3_mut', 'usp28_mut', 'gldc_mut', 'brca2_mut', 'cacna2d3_mut', 'arid2_mut', 'aff2_mut', 'lifr_mut', 'sbno1_mut', 'kdm3a_mut', 'ncoa3_mut', 'bap1_mut', 'l1cam_mut', 'pbrm1_mut', 'chd1_mut', 'jak1_mut', 'setdb1_mut', 'fam20c_mut', 'arid5b_mut', 'egfr_mut', 'map3k10_mut', 'smarcc2_mut', 'erbb4_mut', 'npnt_mut', 'nek1_mut', 'agmo_mut', 'zfp36l1_mut', 'smad4_mut', 'sik1_mut', 'casp8_mut', 'prkcq_mut', 'smarcc1_mut', 'palld_mut', 'dcaf4l2_mut', 'bcas3_mut', 'cdkn1b_mut', 'gps2_mut', 'men1_mut', 'stk11_mut', 'sik2_mut', 'ptpn22_mut', 'brip1_mut', 'flt3_mut', 'nrg3_mut', 'fbxw7_mut', 'ttyh1_mut', 'taf4b_mut', 'or6a2_mut', 'map3k13_mut', 'hdac9_mut', 'prkacg_mut', 'rpgr_mut', 'large1_mut', 'foxp1_mut', 'clk3_mut', 'prkcz_mut', 'lipi_mut', 'ppp2r2a_mut', 'prkce_mut', 'gh1_mut', 'gpr32_mut', 'kras_mut', 'nf2_mut', 'chek2_mut', 'ldlrap1_mut', 'clrn2_mut', 'acvrl1_mut', 'agtr2_mut', 'cdkn2a_mut', 'ctnna1_mut', 'magea8_mut', 'prr16_mut', 'dtwd2_mut', 'akt2_mut', 'braf_mut', 'foxo1_mut', 'nt5e_mut', 'ccnd3_mut', 'nr3c1_mut', 'prkg1_mut', 'tbl1xr1_mut', 'frmd3_mut', 'smad2_mut', 'sgcd_mut', 'spaca1_mut', 'rasgef1b_mut', 'hist1h2bc_mut', 'nr2f1_mut', 'klrg1_mut', 'mbl2_mut', 'mtap_mut', 'ppp2cb_mut', 'smarcd1_mut', 'nras_mut', 'ndfip1_mut', 'hras_mut', 'prps2_mut', 'smarcb1_mut', 'stmn2_mut', 'siah1_mut', 'combined_categorical']
    


```python
#creating new dataframe with all numeric values
df_1=df_1.drop(col_2_columns,axis=1)

```


```python
#Creating a list of all the columns for future use

df_1cols=df_1.columns.tolist()
```


```python
pd.set_option('display.max_rows', None)
df_1.dtypes.sort_values(ascending=True)
```




    overall_survival                   int64
    radio_therapy                      int64
    lymph_nodes_examined_positive      int64
    chemotherapy                       int64
    hormone_therapy                    int64
    cohort                             int64
    asxl2                            float64
    bap1                             float64
    bcas3                            float64
    birc6                            float64
    age_at_diagnosis                 float64
    asxl1                            float64
    chd1                             float64
    clk3                             float64
    clrn2                            float64
    col12a1                          float64
    col22a1                          float64
    col6a3                           float64
    cacna2d3                         float64
    ccnd3                            float64
    arid2                            float64
    ctcf                             float64
    apc                              float64
    alk                              float64
    akap9                            float64
    ahnak2                           float64
    ahnak                            float64
    agtr2                            float64
    agmo                             float64
    aff2                             float64
    afdn                             float64
    adgra2                           float64
    twist1                           float64
    tubb4b                           float64
    tubb4a                           float64
    arid5b                           float64
    ctnna1                           float64
    dnah5                            float64
    dnah11                           float64
    map3k13                          float64
    map3k10                          float64
    magea8                           float64
    lipi                             float64
    lifr                             float64
    ldlrap1                          float64
    large1                           float64
    lamb3                            float64
    lama2                            float64
    l1cam                            float64
    klrg1                            float64
    kdm6a                            float64
    kdm3a                            float64
    hist1h2bc                        float64
    herc2                            float64
    hdac9                            float64
    gps2                             float64
    gpr32                            float64
    gldc                             float64
    gh1                              float64
    frmd3                            float64
    foxp1                            float64
    flt3                             float64
    fancd2                           float64
    fanca                            float64
    fam20c                           float64
    dtwd2                            float64
    tubb1                            float64
    dnah2                            float64
    ctnna3                           float64
    slco1b3                          float64
    map4                             float64
    mapt                             float64
    tgfbr2                           float64
    tgfbr1                           float64
    tgfb3                            float64
    tgfb2                            float64
    tgfb1                            float64
    tert                             float64
    terc                             float64
    sptbn1                           float64
    smad9                            float64
    smad7                            float64
    smad6                            float64
    smad5                            float64
    smad4                            float64
    tgfbr3                           float64
    smad3                            float64
    smad1                            float64
    slc19a1                          float64
    rptor                            float64
    rps6kb2                          float64
    rps6kb1                          float64
    rps6ka2                          float64
    rps6ka1                          float64
    rps6                             float64
    rictor                           float64
    rheb                             float64
    rassf1                           float64
    raf1                             float64
    rad51                            float64
    smad2                            float64
    tsc1                             float64
    tsc2                             float64
    vegfa                            float64
    men1                             float64
    map2                             float64
    fn1                              float64
    fgf2                             float64
    cyp3a4                           float64
    cyp2c8                           float64
    bmf                              float64
    bbc3                             float64
    abcc10                           float64
    abcc1                            float64
    abcb11                           float64
    abcb1                            float64
    tbx3                             float64
    runx1                            float64
    ros1                             float64
    ptprd                            float64
    pde4dip                          float64
    ncor1                            float64
    myh9                             float64
    kmt2d                            float64
    kmt2c                            float64
    gata3                            float64
    cbfb                             float64
    arid1b                           float64
    arid1a                           float64
    zfyve9                           float64
    wwox                             float64
    wfdc2                            float64
    vegfb                            float64
    nr1i2                            float64
    mtap                             float64
    myo3a                            float64
    myo1a                            float64
    hsd3b7                           float64
    hsd3b2                           float64
    hsd3b1                           float64
    hsd17b8                          float64
    hsd17b7                          float64
    hsd17b6                          float64
    hsd17b4                          float64
    hsd17b3                          float64
    hsd17b2                          float64
    hsd17b14                         float64
    hsd17b13                         float64
    hsd17b12                         float64
    hsd17b11                         float64
    mecom                            float64
    hsd17b10                         float64
    hes6                             float64
    ddc                              float64
    cyp3a7                           float64
    cyp3a5                           float64
    cyp3a43                          float64
    cyp21a2                          float64
    cyp19a1                          float64
    cyp17a1                          float64
    cyp11b2                          float64
    cyp11a1                          float64
    cyb5a                            float64
    cdkn2c                           float64
    cdk8                             float64
    hsd17b1                          float64
    met                              float64
    ncoa2                            float64
    nrip1                            float64
    feature_7                        float64
    feature_6                        float64
    feature_5                        float64
    feature_4                        float64
    feature_3                        float64
    feature_2                        float64
    feature_1                        float64
    feature_0                        float64
    ugt2b7                           float64
    ugt2b17                          float64
    ugt2b15                          float64
    tulp4                            float64
    tnk2                             float64
    star                             float64
    st7                              float64
    srd5a3                           float64
    srd5a2                           float64
    srd5a1                           float64
    spry2                            float64
    sox9                             float64
    slc29a1                          float64
    shbg                             float64
    serpini1                         float64
    sdc4                             float64
    rdh5                             float64
    ran                              float64
    prkd1                            float64
    prkci                            float64
    pik3r3                           float64
    bche                             float64
    muc16                            float64
    ar                               float64
    akr1c4                           float64
    sbno1                            float64
    ryr2                             float64
    rpgr                             float64
    rasgef1b                         float64
    ptprm                            float64
    ptpn22                           float64
    prr16                            float64
    prps2                            float64
    prkg1                            float64
    prkcz                            float64
    prkcq                            float64
    prkce                            float64
    prkacg                           float64
    setd1a                           float64
    ppp2r2a                          float64
    pbrm1                            float64
    palld                            float64
    or6a2                            float64
    nt5e                             float64
    nrg3                             float64
    nras                             float64
    nr3c1                            float64
    nr2f1                            float64
    npnt                             float64
    nf2                              float64
    nek1                             float64
    ncoa3                            float64
    rab25                            float64
    ppp2cb                           float64
    setd2                            float64
    setdb1                           float64
    sf3b1                            float64
    akr1c3                           float64
    akr1c2                           float64
    akr1c1                           float64
    ackr3                            float64
    zfp36l1                          float64
    utrn                             float64
    usp9x                            float64
    ush2a                            float64
    ubr5                             float64
    ttyh1                            float64
    thsd7a                           float64
    thada                            float64
    tg                               float64
    tbl1xr1                          float64
    taf4b                            float64
    taf1                             float64
    syne1                            float64
    stmn2                            float64
    stab2                            float64
    spaca1                           float64
    smarcd1                          float64
    smarcc2                          float64
    smarcc1                          float64
    smarcb1                          float64
    sik2                             float64
    sik1                             float64
    siah1                            float64
    shank2                           float64
    sgcd                             float64
    akt3                             float64
    ptk2                             float64
    pik3r1                           float64
    pik3r2                           float64
    fbxw7                            float64
    ep300                            float64
    dtx4                             float64
    dtx3                             float64
    dtx2                             float64
    dtx1                             float64
    dll4                             float64
    dll3                             float64
    dll1                             float64
    cul1                             float64
    ctbp2                            float64
    ctbp1                            float64
    cir1                             float64
    hdac1                            float64
    arrdc1                           float64
    aph1a                            float64
    adam17                           float64
    adam10                           float64
    tp53bp1                          float64
    mdm2                             float64
    stat5b                           float64
    stat5a                           float64
    stat3                            float64
    stat2                            float64
    stat1                            float64
    jak2                             float64
    jak1                             float64
    src                              float64
    aph1b                            float64
    hdac2                            float64
    hes1                             float64
    hes5                             float64
    hey1                             float64
    hes7                             float64
    hes4                             float64
    hes2                             float64
    spen                             float64
    snw1                             float64
    rfng                             float64
    rbpjl                            float64
    rbpj                             float64
    psenen                           float64
    psen2                            float64
    psen1                            float64
    numbl                            float64
    numb                             float64
    nrarp                            float64
    notch3                           float64
    notch2                           float64
    notch1                           float64
    ncstn                            float64
    ncor2                            float64
    maml3                            float64
    maml2                            float64
    maml1                            float64
    lfng                             float64
    kdm5a                            float64
    jag2                             float64
    jag1                             float64
    itch                             float64
    heyl                             float64
    e2f8                             float64
    hey2                             float64
    e2f7                             float64
    e2f5                             float64
    nbn                              float64
    chek2                            float64
    cdh1                             float64
    atm                              float64
    tp53                             float64
    pten                             float64
    palb2                            float64
    brca2                            float64
    brca1                            float64
    death_from_cancer                float64
    tumor_size                       float64
    3-gene_classifier_subtype        float64
    pr_status                        float64
    nf1                              float64
    overall_survival_months          float64
    mutation_count                   float64
    primary_tumor_laterality         float64
    inferred_menopausal_state        float64
    her2_status                      float64
    her2_status_measured_by_snp6     float64
    neoplasm_histologic_grade        float64
    er_status                        float64
    er_status_measured_by_ihc        float64
    pam50_+_claudin-low_subtype      float64
    cellularity                      float64
    cancer_type_detailed             float64
    cancer_type                      float64
    type_of_breast_surgery           float64
    nottingham_prognostic_index      float64
    stk11                            float64
    bard1                            float64
    mlh1                             float64
    e2f4                             float64
    e2f3                             float64
    e2f2                             float64
    e2f1                             float64
    cdkn1b                           float64
    cdkn1a                           float64
    myc                              float64
    cdkn2b                           float64
    cdkn2a                           float64
    ccnd2                            float64
    cdk6                             float64
    cdk4                             float64
    ccnd1                            float64
    cdc25a                           float64
    cdk2                             float64
    ccne1                            float64
    cdk1                             float64
    ccnb1                            float64
    ccna1                            float64
    rbl2                             float64
    rbl1                             float64
    rb1                              float64
    rad50                            float64
    rad51d                           float64
    rad51c                           float64
    epcam                            float64
    pms2                             float64
    msh6                             float64
    msh2                             float64
    e2f6                             float64
    plagl1                           float64
    acvr1                            float64
    acvr1c                           float64
    mlst8                            float64
    mdc1                             float64
    mapk9                            float64
    mapk8                            float64
    mapk7                            float64
    mapk6                            float64
    mapk4                            float64
    mapk3                            float64
    mapk14                           float64
    mapk12                           float64
    mapk1                            float64
    map3k5                           float64
    map3k4                           float64
    mmp1                             float64
    map3k3                           float64
    map2k5                           float64
    map2k4                           float64
    map2k3                           float64
    map2k2                           float64
    map2k1                           float64
    kras                             float64
    kit                              float64
    kdr                              float64
    izumo1r                          float64
    itgb3                            float64
    itgav                            float64
    inhbc                            float64
    inhba                            float64
    map3k1                           float64
    mmp10                            float64
    mmp11                            float64
    mmp12                            float64
    feature_8                        float64
    pik3ca                           float64
    peg3                             float64
    pdpk1                            float64
    pdgfrb                           float64
    pdgfra                           float64
    pdgfb                            float64
    pdgfa                            float64
    opcml                            float64
    nfkb2                            float64
    nfkb1                            float64
    mtor                             float64
    mmp9                             float64
    mmp7                             float64
    mmp3                             float64
    mmp28                            float64
    mmp27                            float64
    mmp26                            float64
    mmp25                            float64
    mmp24                            float64
    mmp23b                           float64
    mmp21                            float64
    mmp2                             float64
    mmp19                            float64
    mmp17                            float64
    mmp16                            float64
    mmp15                            float64
    mmp14                            float64
    mmp13                            float64
    inha                             float64
    acvr1b                           float64
    igf1r                            float64
    hras                             float64
    casp6                            float64
    casp3                            float64
    casp10                           float64
    braf                             float64
    bmpr2                            float64
    bmpr1b                           float64
    bmpr1a                           float64
    bmp7                             float64
    bmp6                             float64
    bmp5                             float64
    bmp4                             float64
    bmp3                             float64
    bmp2                             float64
    casp7                            float64
    bmp15                            float64
    bcl2l1                           float64
    bcl2                             float64
    bad                              float64
    aurka                            float64
    atr                              float64
    arl11                            float64
    apaf1                            float64
    akt2                             float64
    akt1s1                           float64
    akt1                             float64
    acvrl1                           float64
    acvr2b                           float64
    acvr2a                           float64
    bmp10                            float64
    casp8                            float64
    casp9                            float64
    chek1                            float64
    hla-g                            float64
    hif1a                            float64
    gsk3b                            float64
    gdf2                             float64
    gdf11                            float64
    foxo3                            float64
    foxo1                            float64
    folr3                            float64
    folr2                            float64
    folr1                            float64
    fgfr1                            float64
    fgf1                             float64
    fas                              float64
    erbb4                            float64
    erbb3                            float64
    erbb2                            float64
    eif5a2                           float64
    eif4ebp1                         float64
    eif4e                            float64
    egfr                             float64
    dph1                             float64
    dlec1                            float64
    diras3                           float64
    dab2                             float64
    cxcr2                            float64
    cxcr1                            float64
    cxcl8                            float64
    csf1r                            float64
    csf1                             float64
    igf1                             float64
    feature_9                        float64
    dtype: object




```python
df_1.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1904 entries, 0 to 1903
    Columns: 525 entries, age_at_diagnosis to feature_9
    dtypes: float64(519), int64(6)
    memory usage: 7.6 MB
    

Now we have all the data as float or integer,
there are total 525 features reduced from 692. I will now perform <b>Principal Component Analysis</b> so that we can reduce dimensionality.

<b><span style="font-size:20px">Principal Component Analysis</span></b>

PCA is a dimensionality reduction technique that has four main parts: feature covariance, eigen decomposition, principal component transformation, and choosing components in terms of explained variance.

It aims to reduce the dimensionality of a dataset while preserving as much of the original variability (information) as possible. PCA accomplishes this by transforming the original features into a new set of uncorrelated features called principal components.



```python
# Extract features (X) from the DataFrame
X = df_1.values

# Performing preprocessing and standardization

from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
```


```python
# Create a PCA instance
pca = PCA()

# Fit PCA to the data
pca.fit(X_scaled)


# Explained variance ratio
explained_variance = pca.explained_variance_ratio_
```


```python
'''Visualize explained variance: You can visualize the explained variance to understand how much information is retained
by each principal component. This will help you identify which components are more important in explaining the variance 
in your data.'''


import matplotlib.pyplot as plt

plt.plot(range(1, len(explained_variance) + 1), explained_variance, marker='o', linestyle='-')
plt.xlabel('Number of Principal Components')
plt.ylabel('Explained Variance Ratio')
plt.title('Explained Variance Ratio vs. Number of Principal Components')
plt.show()
```


    
![png](output_39_0.png)
    



```python
#Checking the distribution of components in PC
loadings = pca.components_
print(loadings)
```

    [[ 0.02665281  0.00844252 -0.00644421 ...  0.00187095  0.00725048
       0.03508609]
     [-0.04543772 -0.00116501  0.00425383 ... -0.04387328  0.00881842
       0.02143923]
     [ 0.03392087 -0.00112854 -0.00587648 ... -0.01661253  0.00599012
      -0.00272213]
     ...
     [-0.00741197  0.01722504  0.00701119 ... -0.01114762  0.00352875
       0.12362868]
     [ 0.00266568 -0.00070986  0.00046906 ... -0.00197824 -0.00850965
       0.00806869]
     [-0.01366188  0.00313901  0.0022357  ... -0.0098737   0.00607674
      -0.00672277]]
    

By looking at the graph showing <span style="color:blue;">explained_variance_ratio_ </span> and having a glance at the pca.components above, we can understand that first principal component (PC) in my PCA analysis explains only around 8% of the variance which further falls with higher PC's.
<span style="color:red;">PC is not capturing a significant amount of information or variability in my dataset.</span>

<span style="color:red;">Here I have to note, that there is missing Domain knowledge for a lot of features in my dataset which is highly dimensional.</span> 

However, the possible reasons for this can be:
1. data may not have a clear linear structure
2. Some datasets naturally have low variance in the first PC due to their inherent characteristics.
3. Low data quality or noisy dataLow data quality or noisy data
4. Irrelevant or redundant features in your dataset

Now firstly, I will be checking linearity in the data structure. If the data is not linear, I will use another method like Kernel PCA for reducing dimensionality.If that is not the case, then I will remove outliers and perform PCA again.



```python
# Assuming df is your high-dimensional dataset
correlation_matrix = df_1.corr()

import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize=(10, 8))
sns.heatmap(correlation_matrix, cmap='coolwarm', annot=False)
plt.show()
```


    
![png](output_42_0.png)
    


Above correlation heatmap, though it shows less to no correlation among variables due to it's blue colour. However,it is not much relaible. Our data still has very high dimensionality, and heatmapes thus fail to capture all features correctly.
Here, we will try running PCA again assumning that there is non-linear relationship among variables.
As pointed above, if it does not give desired results, we will try dropping variables and reducing outliers.

<b><span style="font-size:20px">Kernel PCA</b></span>


```python
#Kernel PCA

from sklearn.decomposition import KernelPCA

# Performing Kernel PCA with a radial basis function (RBF) kernel

# Defining a range of gamma values to visualize

gamma_values = [0.1, 1.0, 10.0]

plt.figure(figsize=(12, 4))
for i, gamma in enumerate(gamma_values):
    kernel_pca = KernelPCA(kernel='rbf', gamma=gamma)
    X_kernel_pca = kernel_pca.fit_transform(X_scaled)
    
    plt.subplot(1, len(gamma_values), i + 1)
    plt.scatter(X_kernel_pca[:, 0], X_kernel_pca[:, 1], c='r', marker='.', alpha=0.5)
    plt.title(f"Gamma = {gamma}")

plt.show()
```


    
![png](output_45_0.png)
    


<span style="color:red;">Here above I do not see any trend or relationship for any value of Gamma. Thus I will not proceed with idea of non-linear relationship among features.</span>
However, now I will try adjusting for outliers before performing "PCA".
The main reason behind weak relation can be high dimensionality. Absence of feature description further prevents us to drop variables and improve analysis.


```python
#Given the high number of features, we will now use the Z-score method to drop outliers

from scipy import stats
z_scores = np.abs(stats.zscore(X))
threshold = 3                        #Most common value for threshhold
outliers = np.where(z_scores > threshold)

# to remove outliers
X_no_outliers = X[(z_scores < threshold).all(axis=1)]

# Create a boolean mask to identify rows containing outliers
outliers_mask = (z_scores > threshold).any(axis=1)

# Remove rows containing outliers from the original DataFrame
df_1_cleaned = df_1[~outliers_mask]
```


```python
#Again Running PCA on this new datasedt after standardization

# Performing preprocessing and standardization

X_no_outliers_scaled = scaler.fit_transform(X_no_outliers)

# Fit PCA to the data
pca.fit(X_no_outliers_scaled)

# Explained variance ratio
explained_variance = pca.explained_variance_ratio_
```


```python
plt.plot(range(1, len(explained_variance) + 1), explained_variance, marker='o', linestyle='-')
plt.xlabel('Number of Principal Components')
plt.ylabel('Explained Variance Ratio')
plt.title('Explained Variance Ratio vs. Number of Principal Components')
plt.show()
```


    
![png](output_49_0.png)
    


<span style="color:red;">Even after removing outliers there is no change in variance explained by our PC, we will be proceeding  with the same.</span>


```python
# Plotting cumulative explained variance
cumulative_variance = np.cumsum(explained_variance)
plt.plot(cumulative_variance)
plt.xlabel('Number of Components')
plt.ylabel('Cumulative Explained Variance')
plt.title('Cumulative Explained Variance vs. Number of Components')
plt.grid(True)

# Finding the elbow point (where the curve starts to flatten)
def find_elbow_point(variance):
    for i in range(1, len(variance)):
        if variance[i] - variance[i - 1] < 0.01: 
            return i

elbow_index = find_elbow_point(cumulative_variance)
elbow_variance = cumulative_variance[elbow_index]

# Highlighting the elbow point on the plot

plt.axvline(x=elbow_index, color='red', linestyle='--', label=f'Elbow Point ({elbow_index} components, {elbow_variance:.2f} explained variance)')
plt.legend()

plt.show()

# The elbow_index contains the optimal number of components
print(f'Optimal number of components: {elbow_index}')





```


    
![png](output_51_0.png)
    


    Optimal number of components: 18
    


```python
# Choose the number of components 
n_components = 18

# Transform the data
X_pca = pca.transform(X_no_outliers_scaled)[:, :n_components]
```


```python
# Viewing X_pca array to get an idea of the principal components 
print(X_pca)
```

    [[  2.01029247  -8.07183372  -3.68524909 ...  -1.43959649  -2.68304324
        2.28382105]
     [-11.62904792   0.65217645  -1.98660485 ...   1.07876181   0.19990191
        0.59217499]
     [ -4.50940016  -6.30170923  -4.52379734 ...   2.51616771   2.63815867
        2.68852902]
     ...
     [-11.96107581   4.82278975  -3.98820745 ...  -1.08092422   3.58449392
       -1.69796496]
     [ -5.06264643 -15.57194061   0.12253427 ...   1.52911158  -0.7867444
       -0.4911363 ]
     [-12.83143549   0.83961316  -1.69937271 ...  -1.07423446  -0.37907846
        1.08660111]]
    

<span style="color:Blue">After performing PCA, I am left with 18 principal components stored in X_pca which i will be using to create unsupervised models.</span>

<b><span style="font-size:20px"> Feature Importance</span></b>

Since I have already created PCA, it will not be possible for me to use methods like decision tree or other supervised learnign to extract important features later.
Here, I am finding all the features which are important in creation of first 11 PC.
According to theory and we have seen in explained variance ratio graph above, the first few PC are more important in representing the variance in original features. 
Thus, we will only check top most features in explaining the top 11 PC. 


```python
np.random.seed(0)


train_features = np.random.rand(15,525)

model = PCA(n_components=11).fit(train_features)
X_pc = model.transform(train_features)

# number of components
n_pcs= model.components_.shape[0]

# get the index of the most important feature on EACH component
# LIST COMPREHENSION HERE
most_important = [np.abs(model.components_[i]).argmax() for i in range(n_pcs)]

initial_feature_names = df_1cols
# get the names
most_important_names = [initial_feature_names[most_important[i]] for i in range(n_pcs)]

# LIST COMPREHENSION HERE AGAIN
dic = {'PC{}'.format(i+1): most_important_names[i] for i in range(n_pcs)}

# build the dataframe
data = pd.DataFrame(dic.items(), columns=['Principal Component', 'Most Important Feature'])

print(data)
```

       Principal Component    Most Important Feature
    0                  PC1                     ccnd3
    1                  PC2  primary_tumor_laterality
    2                  PC3                    spaca1
    3                  PC4                     maml2
    4                  PC5                      numb
    5                  PC6                    pik3r2
    6                  PC7                    map2k1
    7                  PC8                     bmp10
    8                  PC9                     foxp1
    9                 PC10                     mapk9
    10                PC11                    stat5b
    


```python
Important_features=['ccnd3','primary_tumor_laterality','spaca1','maml2','numb','pik3r2','map2k1','bmp10','foxp1','mapk9','stat5b']
```

<b><span style="font-size:24px"> Clustering</span></b>

Now I have my dataset ready, I want to perform clustering methods on the same. I will try 2-3 different clustering methods and check which one works best.
Starting with K-means

<b><span style="font-size:20px">K-means clustering</span></b>

this unsupervised technique aims to minimize the Within-Cluster Sum of Squares (WCSS) and consequently maximize the Between-Cluster Sum of Squares (BCSS).
Here, I am using elbow method to find the optimal K value.
One can also use gap static, Silhouette score,Calinski Harabasz score or Davies Bouldin score to find the optimal K-value.
However, I have used elbow method as it is most commomnly used method


```python

from sklearn.cluster import KMeans

# Using the Elbow Method to find the optimal K

wcss = []  # Within-Cluster Sum of Squares

for i in range(1, 11):
    kmeans = KMeans(n_clusters=i, init='k-means++', random_state=42)
    kmeans.fit(X_pca)
    wcss.append(kmeans.inertia_)

# Plotting the Elbow Method graph
plt.plot(range(1, 11), wcss, marker='o', linestyle='--')
plt.xlabel('Number of Clusters (K)')
plt.ylabel('WCSS')
plt.title('Elbow Method')

# Finding the elbow point
elbow_point = None
for k in range(1, len(wcss)):
    reduction_rate = (wcss[k - 1] - wcss[k]) / wcss[k - 1]  # Calculate the rate of reduction
    if reduction_rate > 0.1:  
        elbow_point = k
        break

# Highlighting the elbow point on the graph
if elbow_point is not None:
    plt.scatter(elbow_point + 1, wcss[elbow_point], c='red', marker='o', s=100, label=f'Elbow Point (K={elbow_point + 1})')

plt.legend()
plt.show()

```

    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1436: UserWarning: KMeans is known to have a memory leak on Windows with MKL, when there are less chunks than available threads. You can avoid it by setting the environment variable OMP_NUM_THREADS=1.
      warnings.warn(
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1436: UserWarning: KMeans is known to have a memory leak on Windows with MKL, when there are less chunks than available threads. You can avoid it by setting the environment variable OMP_NUM_THREADS=1.
      warnings.warn(
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1436: UserWarning: KMeans is known to have a memory leak on Windows with MKL, when there are less chunks than available threads. You can avoid it by setting the environment variable OMP_NUM_THREADS=1.
      warnings.warn(
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1436: UserWarning: KMeans is known to have a memory leak on Windows with MKL, when there are less chunks than available threads. You can avoid it by setting the environment variable OMP_NUM_THREADS=1.
      warnings.warn(
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1436: UserWarning: KMeans is known to have a memory leak on Windows with MKL, when there are less chunks than available threads. You can avoid it by setting the environment variable OMP_NUM_THREADS=1.
      warnings.warn(
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1436: UserWarning: KMeans is known to have a memory leak on Windows with MKL, when there are less chunks than available threads. You can avoid it by setting the environment variable OMP_NUM_THREADS=1.
      warnings.warn(
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1436: UserWarning: KMeans is known to have a memory leak on Windows with MKL, when there are less chunks than available threads. You can avoid it by setting the environment variable OMP_NUM_THREADS=1.
      warnings.warn(
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1436: UserWarning: KMeans is known to have a memory leak on Windows with MKL, when there are less chunks than available threads. You can avoid it by setting the environment variable OMP_NUM_THREADS=1.
      warnings.warn(
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1436: UserWarning: KMeans is known to have a memory leak on Windows with MKL, when there are less chunks than available threads. You can avoid it by setting the environment variable OMP_NUM_THREADS=1.
      warnings.warn(
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1436: UserWarning: KMeans is known to have a memory leak on Windows with MKL, when there are less chunks than available threads. You can avoid it by setting the environment variable OMP_NUM_THREADS=1.
      warnings.warn(
    


    
![png](output_59_1.png)
    



```python
# K-means clustering
# Create and fit a K-Means clustering model

kmeans = KMeans(n_clusters=2, random_state=42)
kmeans.fit(X_pca)
```

    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    C:\Users\HP\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1436: UserWarning: KMeans is known to have a memory leak on Windows with MKL, when there are less chunks than available threads. You can avoid it by setting the environment variable OMP_NUM_THREADS=1.
      warnings.warn(
    




<style>#sk-container-id-1 {color: black;}#sk-container-id-1 pre{padding: 0;}#sk-container-id-1 div.sk-toggleable {background-color: white;}#sk-container-id-1 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-1 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-1 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-1 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-1 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-1 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-1 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-1 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-1 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-1 div.sk-item {position: relative;z-index: 1;}#sk-container-id-1 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-1 div.sk-item::before, #sk-container-id-1 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-1 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-1 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-1 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-1 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-1 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-1 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-1 div.sk-label-container {text-align: center;}#sk-container-id-1 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-1 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>KMeans(n_clusters=2, random_state=42)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label sk-toggleable__label-arrow">KMeans</label><div class="sk-toggleable__content"><pre>KMeans(n_clusters=2, random_state=42)</pre></div></div></div></div></div>




```python
cluster_labels = kmeans.predict(X_pca)

# Add cluster labels to your DataFrame
df_1_cleaned['Cluster'] = cluster_labels

#defining centroids
centroids = kmeans.cluster_centers_

```

    C:\Users\HP\AppData\Local\Temp\ipykernel_12052\467322821.py:4: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df_1_cleaned['Cluster'] = cluster_labels
    


```python
#visualizing cluster
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=cluster_labels, cmap='viridis')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.title('K-Means Clustering')

# Plot the centroids as distinct points
plt.scatter(centroids[:, 0], centroids[:, 1], c='red', marker='X', s=200, label='Centroids')

plt.title('K-Means Clustering with Centroids')
plt.legend()
plt.grid(True)

plt.show()

```


    
![png](output_62_0.png)
    


The plot above shows that my 2 clusters formed in a 2 dimensional space between PC 1 and PC 2 have clear cluster formation with quite distant centroids. Also, there is clear differenec between the points in the first and the second cluster showing negligible overlap between the two clusters.

However, since we have 18 PC's in our analysis. We will further deep dive to see relevance of different features


```python
feature_names_pca = [f'PC{i+1}' for i in range(X_pca.shape[1])]  # Example: PC1, PC2, ..., PC13
cluster_centers_df = pd.DataFrame(centroids, columns=feature_names_pca)

# Find the index (cluster) with the highest centroid value for each feature
key_features = cluster_centers_df.idxmax(axis=0)

# Find the maximum centroid value for each feature
max_centroid_value = cluster_centers_df.max(axis=0)

# Display key features and their corresponding centroids
key_features_and_centroids = pd.DataFrame({'Key Feature': key_features, 'Max Centroid Value': max_centroid_value})
print(key_features_and_centroids)

```

          Key Feature  Max Centroid Value
    PC1             1            4.709924
    PC2             1            0.898229
    PC3             0            0.140065
    PC4             1            0.165717
    PC5             0            0.021830
    PC6             1            0.111418
    PC7             1            0.032494
    PC8             1            0.102908
    PC9             0            0.149569
    PC10            1            0.188261
    PC11            0            0.335364
    PC12            0            0.182540
    PC13            1            0.210028
    PC14            1            0.039354
    PC15            1            0.016607
    PC16            0            0.099625
    PC17            0            0.159992
    PC18            1            0.030510
    

This above table gives us the key features and their corresponding maximum centroid values for each of the 13 principal components (PCs) resulting from PCA.

1. Key Feature: This column represents the principal component (PC) in which the maximum centroid value occurs. The "PC1,"        "PC2,"   etc., labels indicate which PC is associated with the maximum centroid value for each feature.

2. Max Centroid Value: This column represents the maximum centroid value for each feature among the clusters. It indicates the importance or influence of each feature in distinguishing clusters. A higher maximum centroid value for a feature suggests that the feature is more important in defining the separation between clusters.

<span style="color:red;">
Interpreting the example output:
</span>

1. For "PC1," the maximum centroid value is approximately 4.709, and it occurs in Cluster 1. This suggests that "PC1" plays a significant role in distinguishing Cluster 1 from Cluster 0. Features associated with "PC1" i.e "ccnd3" contribute most to the separation between these clusters.

2. For "PC2," the maximum centroid value is approximately 0.89, and it occurs in Cluster 1. This indicates that "PC2" i.e "primary_tumor_laterality" is also a key feature in Cluster 1.


3. For "PC11," it is the maximum centroid value in Cluster 0 (approximately 0.33). This indicates that it plays the most important role in distinguishing Cluster 0 from Cluster 1. Thus, "stat5b" is the most important feature in cluster 0.

4. For the remaining PCs, the maximum centroid values are relatively low. This suggests that these PCs have less influence in distinguishing the clusters compared to "PC1," "PC2," and "PC11."


In summary, the output helps you identify the key features (principal components) that are most important in separating clusters in your data. Features associated with PCs that have higher maximum centroid values are more influential in cluster separation, while those with lower maximum centroid values have less influence.




```python
#Checking for important PC in the 2 clusters graphically

from pandas.plotting import parallel_coordinates
# Create a DataFrame containing the principal components and the 'cluster' column
df_pca_clustered = pd.DataFrame(X_pca, columns=[f'PC{i+1}' for i in range(X_pca.shape[1])])
# Add cluster labels to the DataFrame
df_pca_clustered['Cluster'] = cluster_labels

# Get unique cluster labels
unique_clusters = df_pca_clustered['Cluster'].unique()


#Normalize the PC columns if needed
#df_pca_clustered.iloc[:, :-1] = (df_pca_clustered.iloc[:, :-1] - df_pca_clustered.iloc[:, :-1].mean()) / df_pca_clustered.iloc[:, :-1].std()

# Create parallel coordinates plots for each cluster
plt.figure(figsize=(12, 6))

for cluster_label in unique_clusters:
    subset = df_pca_clustered[df_pca_clustered['Cluster'] == cluster_label]
    
# Reorder columns to have 'Cluster' as the first column
    cols = ['Cluster'] + [col for col in subset.columns if col != 'Cluster']
    subset = subset[cols]    
    
    # Create a separate figure for each cluster
    plt.figure(figsize=(8, 6))
    parallel_coordinates(subset,'Cluster', colormap='viridis')
    plt.xlabel('Principal Components')
    plt.ylabel('Standardized Values')
    plt.title('Parallel Coordinates Plot of PCA Components for Cluster {cluster_label}')
    plt.show()
    


```


    <Figure size 1200x600 with 0 Axes>



    
![png](output_66_1.png)
    



    
![png](output_66_2.png)
    


We have seen the importance of different PC on the centroid of the two clusters and the creation of the two clusters.
Now I want to check the importance of each variable in the original dataset df_1 on the same.

<b><span style="font-size:20px">Feature Value</span></b>

As seen above.finding feature importance after performing Principal Component Analysis (PCA) and then applying K-means clustering can be a bit tricky because PCA transforms the original features into a set of orthogonal components, and these components are linear combinations of the original features. Therefore, traditional methods for feature importance like feature importance scores from decision trees or linear regression coefficients don't directly apply to PCA-transformed data.

Now that we have important features with us as found above,we will find a way to get values for the same. 
To get some insights into feature values in the context of PCA and K-means we are examining the loadings of the original features onto the principal components. 



```python
# Since we already have important features, our task is to find Feature Values for Kmeans 
# Group data by cluster and calculate statistics for important features
cluster_stats = df_1_cleaned.groupby('Cluster')[Important_features].agg(['mean', 'std'])
cluster_stats_df = pd.DataFrame(cluster_stats)
cluster_stats_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="2" halign="left">ccnd3</th>
      <th colspan="2" halign="left">primary_tumor_laterality</th>
      <th colspan="2" halign="left">spaca1</th>
      <th colspan="2" halign="left">maml2</th>
      <th colspan="2" halign="left">numb</th>
      <th>...</th>
      <th colspan="2" halign="left">map2k1</th>
      <th colspan="2" halign="left">bmp10</th>
      <th colspan="2" halign="left">foxp1</th>
      <th colspan="2" halign="left">mapk9</th>
      <th colspan="2" halign="left">stat5b</th>
    </tr>
    <tr>
      <th></th>
      <th>mean</th>
      <th>std</th>
      <th>mean</th>
      <th>std</th>
      <th>mean</th>
      <th>std</th>
      <th>mean</th>
      <th>std</th>
      <th>mean</th>
      <th>std</th>
      <th>...</th>
      <th>mean</th>
      <th>std</th>
      <th>mean</th>
      <th>std</th>
      <th>mean</th>
      <th>std</th>
      <th>mean</th>
      <th>std</th>
      <th>mean</th>
      <th>std</th>
    </tr>
    <tr>
      <th>Cluster</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-0.279978</td>
      <td>0.853344</td>
      <td>0.918699</td>
      <td>0.971677</td>
      <td>-0.064147</td>
      <td>0.931534</td>
      <td>-0.009212</td>
      <td>0.738764</td>
      <td>-0.022337</td>
      <td>0.682309</td>
      <td>...</td>
      <td>0.03646</td>
      <td>0.631221</td>
      <td>-0.129477</td>
      <td>0.975585</td>
      <td>0.082562</td>
      <td>0.687960</td>
      <td>0.303018</td>
      <td>0.733178</td>
      <td>0.013752</td>
      <td>0.765535</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-0.063544</td>
      <td>0.789672</td>
      <td>0.878788</td>
      <td>0.980966</td>
      <td>-0.048634</td>
      <td>0.901321</td>
      <td>-0.025038</td>
      <td>0.759525</td>
      <td>0.350862</td>
      <td>0.761294</td>
      <td>...</td>
      <td>-0.42010</td>
      <td>0.671011</td>
      <td>-0.059948</td>
      <td>0.959931</td>
      <td>-0.065448</td>
      <td>0.798141</td>
      <td>0.057735</td>
      <td>0.724318</td>
      <td>0.390084</td>
      <td>0.710639</td>
    </tr>
  </tbody>
</table>
<p>2 rows × 22 columns</p>
</div>



Above graph showing spread of different principal components along dataframe can be referred to find distribution of each important feature in both clusters. 
Here, we see while some values has positive impact on clusters, some have negative. The standard deviation is also important factor in our analysis.

<span style="color:red;">Eg, PC1 and therefore 'ccnd3' which was an important feature to determine cluster 1 has a higher absolute mean in case of cluster 0 with high standard seviation compared to cluster 1. As evident from the graph also, PC1 shows more positive standardised value for cluster 1 than for cluster 0.</span>




```python
# Evaluating the quality of the clustering results using silhouette score and  Davies-Bouldin index

from sklearn.metrics import silhouette_score
from sklearn.metrics import davies_bouldin_score

silhouette_avg = silhouette_score(X_pca, cluster_labels)
# Print the silhouette score
print("Silhouette Score:", silhouette_avg)



davies_bouldin = davies_bouldin_score(X_pca, cluster_labels)
# Print the Davies-Bouldin index
print("Davies-Bouldin Index:", davies_bouldin)

```

    Silhouette Score: 0.1026986518023082
    Davies-Bouldin Index: 2.7835847917755343
    

<span style="color:Blue;"> Here, we see that we have a </span> <span style="color:Black;"><b>relatively low Silhouette Score</b></span> <span style="color:Blue;">since Silhouette Score range between [-1,1], that means objects in our clusters are relatively close to the decision boundary between clusters.</span>
    
<span style="color:Blue;">The Davies-Bouldin Index measures the average similarity between each cluster with the cluster that is most similar to it.
A </span> <b><span style="color:Black;">Davies-Bouldin Index</span></b> <span style="color:Blue;">of approximately 2.78 indicates that the clusters might not be very well-separated or distinct. It suggests that there might be some similarity or overlap between clusters.
</span>

However, there is also a huge dimensionality in our dataset here. There is no clear clustert in our dataset and this might be the reason for the same.


Now, we will try other methods of Clustering to see if they perform better for oyr dataset.

<b><span style="font-size:20px">Hierarchical Clustering</span></b>



```python
# Hierarchical clustering
from scipy.cluster.hierarchy import linkage, dendrogram, fcluster

linkage_matrix = linkage(X_pca, method='ward')

# Create a figure with two subplots: dendrogram and elbow plot
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(18, 6))

# Create the dendrogram subplot
dendrogram(linkage_matrix, labels=range(len(X_pca)), orientation='top', distance_sort='descending', show_leaf_counts=True, leaf_font_size=12, above_threshold_color='gray', ax=ax1)
ax1.set_xlabel("Data Points")
ax1.set_ylabel("Distance")
ax1.set_title("Hierarchical Clustering Dendrogram")
ax1.tick_params(axis='x', rotation=45)

# Create the elbow plot subplot
wcss_values = []
max_clusters = 10  # Adjust this based on your dataset

for i in range(1, max_clusters + 1):
    cluster_labels = fcluster(linkage_matrix, i, criterion='maxclust')
    wcss = sum(((X_pca[cluster_labels == j] - X_pca[cluster_labels == j].mean()) ** 2).sum() for j in range(1, i + 1))
    wcss_values.append(wcss)

ax2.plot(range(1, max_clusters + 1), wcss_values, marker='o', linestyle='-', color='b')
ax2.set_title('Elbow Method')
ax2.set_xlabel('Number of Clusters')
ax2.set_ylabel('Within-Cluster Sum of Squares (WCSS)')
ax2.grid(True)

# Display the combined figure with both subplots
plt.tight_layout()
plt.show()

```


    
![png](output_72_0.png)
    



```python
#According to elbow method, we should use 2 clusters here.

# Specify the desired number of clusters
num_clusters = 2  

# Assign cluster labels based on the desired number of clusters
cluster_labels = fcluster(linkage_matrix, num_clusters, criterion='maxclust')

```


```python
#Evaluating the method
silhouette_avg = silhouette_score(X_pca, cluster_labels)
# Print the silhouette score
print("Silhouette Score:", silhouette_avg)



davies_bouldin = davies_bouldin_score(X_pca, cluster_labels)
# Print the Davies-Bouldin index
print("Davies-Bouldin Index:", davies_bouldin)
```

    Silhouette Score: 0.0845968336210903
    Davies-Bouldin Index: 2.9881102828383144
    

We see from the graph and the Silhouette Score and Davies-Bouldin Index that this method does not perform clusering very well. We will further proceed with another methods:

<b><scan style="font-size:20px"> DBSCAN Method </scan></b>



```python
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler

# Define ranges for min_samples and eps
min_samples_range = range(1, 36)  # Adjust as needed
eps_range = np.linspace(0.1, 2.0, num=20) 


# Store the number of clusters for each combination of min_samples and eps
num_clusters = np.zeros((len(min_samples_range), len(eps_range)))


for i, min_samples in enumerate(min_samples_range):
    for j, eps in enumerate(eps_range):
        dbscan = DBSCAN(eps=eps, min_samples=min_samples)
        dbscan.fit(X_pca)
        cluster_labels = dbscan.labels_
        num_clusters[i, j] = len(set(cluster_labels)) - (1 if -1 in cluster_labels else 0)

# Plot the number of clusters for different combinations of min_samples and eps
plt.figure(figsize=(10, 6))
for i, min_samples in enumerate(min_samples_range):
    plt.plot(eps_range, num_clusters[i, :], label=f"min_samples={min_samples}")

plt.title('Grid Search for min_samples and eps in DBSCAN')
plt.xlabel('eps')
plt.ylabel('Number of Clusters')
plt.legend()
plt.grid(True)
plt.show()

```


    
![png](output_76_0.png)
    


The graph above visualize how the number of clusters changes for different combinations of min_samples and eps. We see that the numberf of cluster remains 0 for a vast values of eps. Further, I tried running DBSCAN for many different values of min_samples but our output remain the same as we will see. 


```python
# DBSCAN clustering
# Since DBSCAN is robust to outliers,I will be using X_pca for my analysis
from sklearn.cluster import DBSCAN

dbscan = DBSCAN(eps=0.1, min_samples=5)

# Fit the DBSCAN model to the data
dbscan.fit(X_pca)

# Get the cluster labels (-1 indicates noise/outliers)
cluster_labels = dbscan.labels_

# Print the cluster labels for each data point
print("Cluster Labels:")
print(cluster_labels)

# Get the number of clusters (excluding noise)
num_clusters = len(set(cluster_labels)) - (1 if -1 in cluster_labels else 0)
print(f"Number of Clusters: {num_clusters}")
```

    Cluster Labels:
    [-1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1
     -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1
     -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1
     -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1
     -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1
     -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1
     -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1
     -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1
     -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1
     -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1
     -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1]
    Number of Clusters: 0
    

We see that DBSCAN didn't identify any clusters in our data. I have tried running this for multiple values of esp and min_samples but i get the same result.
This result suggests that the data may not have clear density-based clusters. Since my data is alreadt standardized and treated for missing an outlier values. The possible reason can be high dimensionality.

To varify the distribution further, I have used another method:

<b><span styel="font-size:22px">t-SNE method</span></b>


```python
#t-SNE method
from sklearn.manifold import TSNE

# Create a t-SNE instance
tsne = TSNE(n_components=3, random_state=42)

# Apply t-SNE to your data
tsne_result = tsne.fit_transform(X_pca)

# Check the dimensions of tsne_result and cluster_labels
print(len(tsne_result))

# Create a scatter plot of the t-SNE results with different colors for clusters
plt.figure(figsize=(8, 6))
plt.scatter(tsne_result[:, 0], tsne_result[:, 1], c=cluster_labels, cmap='viridis', marker='o', s=50, alpha=0.5)
plt.xlabel('t-SNE Dimension 1')
plt.ylabel('t-SNE Dimension 2')
plt.title('t-SNE Clustering')
plt.colorbar(label='Cluster Label')  # Add a colorbar to indicate cluster labels
plt.grid(True)

# Display the plot
plt.show()
```

    255
    


    
![png](output_80_1.png)
    


The plot above shows scattered data points and no clear clusters. This indicates the data may not have any well-defined or inherent clusters thus making it challenging to find meaningful clusters using unsupervised clustering techniques.

High-dimensional data often exhibits increased sparsity and complexity, making it difficult to visualize and identify clusters in lower dimensions. t-SNE is a dimensionality reduction technique that aims to preserve local relationships, but in high dimensions, it can still lead to scattered points.

<b><span style="font-size:24px">Conclusion</span></b>

In this analysis, we began with a very high Dimensional dataset with 692 different features. We treated missing values and Encoded categorial features and reduced these to 525 different features. However, they are still very high for analysis.
To solve this, we employed Principal Component Analysis (PCA) which created 18 different Principal Components which were nothing but a linear combination of our features.

Now since we did not have any target variable, to understand our dataset further, we utilized 4 different Clustering methods.

The below table shows performance in respect to each one of them:

<style>
    table {
        font-size: 24px;
    }
</style>

| Clustering Method | Silhouette Score | Davies-Bouldin Index |
|-------------------|------------------|------------------    |
| KMeans            | 0.103            | 2.78                 |
| Hierarchical      | 0.085            | 2.98                 |
| DBSCAN            | na               | na                   |    
| t-SNE             | na               | na                   |


Clearly, all the methods could not perform clustering very well even when the data was standardized and there were no outliers. This has to do with the the inherent properties of dataset and high dimensionality. However, Kmeans has performed the best among them all with higher Silhouette Score and lower Davies-Bouldin Index.

DBSCAN failed to find any clusters. t-SNE confirmed how scattered the dataset was.

From KMeans we have also identified the Important features and their values.

ccnd3, primary_tumor_laterality, stat5b are very important in defining clusters. 
Apart from them, 'spaca1','maml2','numb','pik3r2','map2k1','bmp10','foxp1','mapk9' are all important features.

Their feature values can be assesed from dataframe cluster_stats_df.







<b><span style="font-size:24px">Reference</span></b>

1) [Analyze the Results of a K-means Clustering by Llewelyn Fernandes](https://openclassrooms.com/en/courses/5869986-perform-an-exploratory-data-analysis/6177861-analyze-the-results-of-a-k-means-clustering)

2) [Interpretable K-Means: Clusters Feature Importances by Yousef Alghofaili](https://towardsdatascience.com/interpretable-k-means-clusters-feature-importances-7e516eeb8d3c#7e14)

3) [PCA clearly explained —When, Why, How to use it and feature importance: A guide in Python by Serafeim Loukas, PhD](https://towardsdatascience.com/pca-clearly-explained-how-when-why-to-use-it-and-feature-importance-a-guide-in-python-7c274582c37e#:~:text=The%20importance%20of%20each%20feature,higher%20magnitude%20%E2%80%94%20higher%20importance)

4) [Feature Extraction using Principal Component Analysis — A Simplified Visual Demo by Kai Zhao](https://towardsdatascience.com/feature-extraction-using-principal-component-analysis-a-simplified-visual-demo-e5592ced100a)

5) [K-means, DBSCAN, GMM, Agglomerative clustering — Mastering the popular models in a segmentation problem
 by Indraneel Dutta Baruah](https://medium.com/towards-data-science/k-means-dbscan-gmm-agglomerative-clustering-mastering-the-popular-models-in-a-segmentation-c891a3818e29)

